/**
 * Dados de exemplo mínimos para o MockAdapter.
 *
 * O objetivo é permitir que os 4 módulos renderizem algo sensato em dev.
 * Para demos reais, injete datasets maiores via `new MockAdapter({ benchmark: ... })`.
 */

import type { BenchmarkDataset } from './DataAdapter';
import type { QuoteListItem } from '../shared/types';

export const DEFAULT_MOCK_BENCHMARK: BenchmarkDataset = {
  opportunities: [
    { opportunity_id: 'OPP-2024-001', title: 'Enauta — Petrobras SEEP', client: 'Enauta', project_domain: 'ROV Subsea' },
    { opportunity_id: 'OPP-2024-002', title: 'Constellation — Survey Campaign', client: 'Constellation', project_domain: 'Survey' },
    { opportunity_id: 'OPP-2024-003', title: 'OneSubsea — Cleaning Tools', client: 'OneSubsea', project_domain: 'Tooling' },
  ],
  cost: [
    {
      opportunity_id: 'OPP-2024-001', et_text: 'MBES Head', group: 'ROV SUBSEA - MBES Spread',
      description: 'Sonardyne Sprint-Mapper multibeam head', pn: '1234567',
      category_final: 'Survey Equipment', type_raw: 'purchase(cap)', unit_price: 185000, quantity: 1, currency: 'USD',
    },
    {
      opportunity_id: 'OPP-2024-001', et_text: 'MBES Head', group: 'ROV SUBSEA - MBES Spread',
      description: 'Sonardyne Sprint-Mapper multibeam head', pn: '1234567',
      category_final: 'Survey Equipment', type_raw: 'day rate(ope)', unit_price: 1250, quantity: 90, currency: 'USD',
    },
    {
      opportunity_id: 'OPP-2024-002', et_text: 'USBL Transducer', group: 'Positioning',
      description: 'Ranger 2 USBL transducer', pn: '2345678',
      category_final: 'Acoustic Positioning (USBL/LBL)', type_raw: 'rental(ope)', unit_price: 850, quantity: 60, currency: 'USD',
    },
    {
      opportunity_id: 'OPP-2024-003', et_text: 'Cleaning Tool', group: 'ROV Tooling',
      description: 'Rotary brush cleaning tool 6"', pn: '3456789',
      category_final: 'ROV Tooling', type_raw: 'in house', unit_price: 0, quantity: 1, currency: 'USD',
    },
  ],
  labor: [
    { opportunity_id: 'OPP-2024-001', role: 'ROV Pilot', phase: 'Offshore', hours: 480, rate: 95 },
    { opportunity_id: 'OPP-2024-001', role: 'Survey Engineer', phase: 'Offshore', hours: 240, rate: 110 },
    { opportunity_id: 'OPP-2024-002', role: 'Survey Engineer', phase: 'Onshore', hours: 80, rate: 110 },
  ],
};

export const DEFAULT_MOCK_SUPPLY: Array<Record<string, unknown>> = [
  {
    Item: '0001234567', description: 'Sonardyne Sprint-Mapper',
    qty_on_hand: 2, qty_available: 1, unit_cost_usd: 168000, avg_cost_usd: 172000, repl_cost_usd: 180000,
    last_price_paid: 175000, vendor_name: 'Sonardyne Intl', lead_time_days: 45,
  },
  {
    Item: '0002345678', description: 'Ranger 2 USBL transducer',
    qty_on_hand: 4, qty_available: 3, unit_cost_usd: 42000, avg_cost_usd: 44500, repl_cost_usd: 46000,
    last_price_paid: 45000, vendor_name: 'Sonardyne Intl', lead_time_days: 60,
  },
];

export const DEFAULT_MOCK_QUOTES: QuoteListItem[] = [
  {
    id: 1, quoteNumber: 'Q-2026-0001', quoteDate: '2026-05-14', validUntil: '2026-08-14',
    supplier: 'Sonardyne International', supplierCountry: 'UK',
    customer: 'Oceaneering BR', reference: 'REQ-2026-0011', project: 'Constellation Survey',
    incoterms: 'DAP Rio', paymentTerms: 'NET 30',
    itemType: 'Sale', productCode: '2345678', description: 'Ranger 2 USBL transducer',
    quantity: 1, uom: 'EA', unitPrice: 45000, rate: null, ratePeriod: '', currency: 'USD',
    lineTotal: 45000, startDate: '', endDate: '', days: null, leadTimeDays: 60,
    sourceFile: 'sonardyne_q2026-0001.pdf', supplierId: '', modified: '2026-05-14T10:00:00Z',
  },
];
