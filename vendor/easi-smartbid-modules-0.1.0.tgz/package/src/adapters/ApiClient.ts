/**
 * ApiClient — fachada estática que preserva a superfície original do EASI SPFx.
 *
 * Os arquivos das páginas portadas (`Suppliers`, `BidComparator`, `BidPresentation`,
 * `PriceHistory`) continuam chamando `ApiClient.getBenchmarkDataset()` etc. sem
 * saber que por baixo está o `SmartBidDataAdapter` configurado pelo host.
 *
 * Uso no host (bootstrap):
 *
 *   import { configureSmartBidModules } from '@easi/smartbid-modules';
 *   configureSmartBidModules({ adapter: new PnPAdapter(sp) });
 */

import type { SmartBidDataAdapter, BenchmarkDataset } from './DataAdapter';
import type { QuoteListItem } from '../shared/types';

let currentAdapter: SmartBidDataAdapter | undefined;

/** Injeta a implementação de dados que os módulos vão consumir. */
export function configureSmartBidModules(config: { adapter: SmartBidDataAdapter }): void {
  currentAdapter = config.adapter;
}

/** Recupera o adapter atual (para código que quer consumir diretamente). */
export function getSmartBidAdapter(): SmartBidDataAdapter {
  if (!currentAdapter) {
    throw new Error(
      '@easi/smartbid-modules: adapter não configurado. Chame `configureSmartBidModules({ adapter })` no bootstrap ou envolva a árvore com <SmartBidModulesProvider adapter={...}>.'
    );
  }
  return currentAdapter;
}

/** Fachada estática compatível com o `ApiClient` original do repo `easi-spfx`. */
export class ApiClient {
  // ── Datasets ────────────────────────────────────────────────────────────────
  static async getBenchmarkDataset(): Promise<BenchmarkDataset> {
    return getSmartBidAdapter().getBenchmarkDataset();
  }

  static async getSupplyIndex(): Promise<Array<Record<string, unknown>>> {
    return getSmartBidAdapter().getSupplyIndex();
  }

  static async getCostElementsRaw(): Promise<Array<Record<string, unknown>>> {
    return getSmartBidAdapter().getCostElementsRaw();
  }

  static async getOpportunitiesRaw(): Promise<Array<Record<string, unknown>>> {
    return getSmartBidAdapter().getOpportunitiesRaw();
  }

  // ── Suppliers / Quotes (opcionais) ─────────────────────────────────────────
  static isQuotesStoreConfigured(): boolean {
    const a = currentAdapter;
    return !!(a && a.isQuotesStoreConfigured && a.isQuotesStoreConfigured() && a.listQuotes);
  }

  static async listQuotes(): Promise<QuoteListItem[]> {
    const a = getSmartBidAdapter();
    if (!a.listQuotes) throw new Error('Adapter não implementa listQuotes().');
    return a.listQuotes();
  }

  static isQuotesUploadConfigured(): boolean {
    const a = currentAdapter;
    return !!(a && a.isQuotesUploadConfigured && a.isQuotesUploadConfigured() && a.uploadQuoteDocument);
  }

  static async uploadQuoteDocument(file: File): Promise<void> {
    const a = getSmartBidAdapter();
    if (!a.uploadQuoteDocument) throw new Error('Adapter não implementa uploadQuoteDocument().');
    return a.uploadQuoteDocument(file);
  }
}
