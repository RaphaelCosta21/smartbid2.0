/**
 * Interface `SmartBidDataAdapter` — contrato de dados dos módulos.
 *
 * O host (SMART BID 2.0) implementa esta interface contra sua camada de dados
 * (PnPjs → SharePoint Lists, REST, backend próprio, XLSX etc.) e injeta a
 * instância via `configureSmartBidModules({ adapter })` no bootstrap do app,
 * ou via `<SmartBidModulesProvider adapter={...}>` para consumo por Context.
 *
 * Métodos marcados como opcionais são usados apenas por módulos específicos —
 * a ausência apenas desabilita features (upload de cotação, listagem de quotes
 * do SharePoint, etc.) sem quebrar o resto.
 */

import type { QuoteListItem } from '../shared/types';

/** Payload retornado pelo endpoint de dataset consolidado (equivalente ao antigo `getBenchmarkDataset`). */
export interface BenchmarkDataset {
  /** Linhas cru de Cost_Element (colunas: unit_price, quantity, type_raw, category_final, pn, description, currency, premisses, group, opportunity_id, et_text, ...). */
  cost: Array<Record<string, unknown>>;
  /** Linhas cru de Opportunity. */
  opportunities: Array<Record<string, unknown>>;
  /** Linhas cru de Labor_Element. */
  labor: Array<Record<string, unknown>>;
}

export interface SmartBidDataAdapter {
  // ── Datasets brutos (usados por Price History / BID Presentation / BID Comparator) ──
  getBenchmarkDataset(): Promise<BenchmarkDataset>;
  getSupplyIndex(): Promise<Array<Record<string, unknown>>>;
  getCostElementsRaw(): Promise<Array<Record<string, unknown>>>;
  getOpportunitiesRaw(): Promise<Array<Record<string, unknown>>>;

  // ── Cotações (usados apenas pelo módulo Suppliers) ─────────────────────────
  /** `true` se o adapter suporta leitura da lista de quotes (habilita a aba de importação em Suppliers). */
  isQuotesStoreConfigured?(): boolean;
  listQuotes?(): Promise<QuoteListItem[]>;

  /** `true` se o adapter aceita upload de arquivo (PDF/imagem) para a pasta de entrada do fluxo. */
  isQuotesUploadConfigured?(): boolean;
  uploadQuoteDocument?(file: File): Promise<void>;
}
