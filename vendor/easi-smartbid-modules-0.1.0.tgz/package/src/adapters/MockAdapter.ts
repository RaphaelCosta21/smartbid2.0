/**
 * MockAdapter — implementação de referência do `SmartBidDataAdapter` para dev.
 *
 * Permite que o SMART BID 2.0 rode os módulos EASI antes de existir integração
 * com PnPjs / SharePoint Lists. Aceita datasets injetados no construtor, ou
 * carrega os defaults embutidos (pequenos, apenas para demo).
 */

import type { BenchmarkDataset, SmartBidDataAdapter } from './DataAdapter';
import type { QuoteListItem } from '../shared/types';
import {
  DEFAULT_MOCK_BENCHMARK,
  DEFAULT_MOCK_SUPPLY,
  DEFAULT_MOCK_QUOTES,
} from './mockData';

export interface MockAdapterOptions {
  benchmark?: BenchmarkDataset;
  supply?: Array<Record<string, unknown>>;
  quotes?: QuoteListItem[];
  /** Atraso artificial em ms para simular latência de rede. Padrão 150. */
  latencyMs?: number;
}

export class MockAdapter implements SmartBidDataAdapter {
  private benchmark: BenchmarkDataset;
  private supply: Array<Record<string, unknown>>;
  private quotes: QuoteListItem[];
  private latency: number;

  constructor(opts: MockAdapterOptions = {}) {
    this.benchmark = opts.benchmark ?? DEFAULT_MOCK_BENCHMARK;
    this.supply = opts.supply ?? DEFAULT_MOCK_SUPPLY;
    this.quotes = opts.quotes ?? DEFAULT_MOCK_QUOTES;
    this.latency = opts.latencyMs ?? 150;
  }

  private async wait<T>(v: T): Promise<T> {
    if (this.latency > 0) await new Promise((r) => setTimeout(r, this.latency));
    return v;
  }

  async getBenchmarkDataset(): Promise<BenchmarkDataset> {
    return this.wait(this.benchmark);
  }

  async getSupplyIndex(): Promise<Array<Record<string, unknown>>> {
    return this.wait(this.supply);
  }

  async getCostElementsRaw(): Promise<Array<Record<string, unknown>>> {
    return this.wait(this.benchmark.cost);
  }

  async getOpportunitiesRaw(): Promise<Array<Record<string, unknown>>> {
    return this.wait(this.benchmark.opportunities);
  }

  isQuotesStoreConfigured(): boolean {
    return true;
  }

  async listQuotes(): Promise<QuoteListItem[]> {
    return this.wait(this.quotes);
  }

  isQuotesUploadConfigured(): boolean {
    return true;
  }

  async uploadQuoteDocument(file: File): Promise<void> {
    // eslint-disable-next-line no-console
    console.log('[MockAdapter] uploadQuoteDocument (no-op):', file.name, file.size);
    await this.wait(undefined);
  }
}
