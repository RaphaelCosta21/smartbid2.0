import * as React from 'react';
import { createContext, useCallback, useContext, useMemo, useRef, useState } from 'react';

export type ToastKind = 'success' | 'error' | 'info';

interface ToastItem {
  id: number;
  kind: ToastKind;
  message: string;
}

interface ToastContextValue {
  /** Show a transient toast. Returns the toast id. */
  notify: (message: string, kind?: ToastKind) => number;
  success: (message: string) => number;
  error: (message: string) => number;
  info: (message: string) => number;
}

const ToastContext = createContext<ToastContextValue | undefined>(undefined);

const KIND_STYLES: Record<ToastKind, string> = {
  success: 'border-l-green text-light',
  error: 'border-l-red-500 text-light',
  info: 'border-l-gold text-light'
};

const DEFAULT_DURATION = 3500;

/** Provides toast notifications to any descendant via {@link useToast}. */
export const ToastProvider: React.FC<{ children?: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const nextId = useRef(1);

  const dismiss = useCallback((id: number): void => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const notify = useCallback(
    (message: string, kind: ToastKind = 'info'): number => {
      const id = nextId.current++;
      setToasts((prev) => [...prev, { id, kind, message }]);
      window.setTimeout(() => dismiss(id), DEFAULT_DURATION);
      return id;
    },
    [dismiss]
  );

  const value = useMemo<ToastContextValue>(
    () => ({
      notify,
      success: (m) => notify(m, 'success'),
      error: (m) => notify(m, 'error'),
      info: (m) => notify(m, 'info')
    }),
    [notify]
  );

  return (
    <ToastContext.Provider value={value}>
      {children}
      <div className="absolute bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm">
        {toasts.map((t) => (
          <div
            key={t.id}
            role="status"
            onClick={() => dismiss(t.id)}
            className={
              'easi-toast cursor-pointer bg-black/90 border border-border border-l-4 ' +
              'px-4 py-3 text-sm shadow-lg ' +
              KIND_STYLES[t.kind]
            }
          >
            {t.message}
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
};

/** Access the toast API. Safe no-op fallback if used outside a provider. */
export const useToast = (): ToastContextValue => {
  const ctx = useContext(ToastContext);
  if (ctx) {
    return ctx;
  }
  const noop = (): number => 0;
  return { notify: noop, success: noop, error: noop, info: noop };
};
