import * as React from 'react';

export interface IEmptyStateProps {
  title?: string;
  description?: string;
  /** Optional call-to-action (e.g. a button). */
  action?: React.ReactNode;
  className?: string;
}

/** Consistent empty-state placeholder. */
export const EmptyState: React.FC<IEmptyStateProps> = ({
  title = 'Nothing here yet',
  description,
  action,
  className
}) => (
  <div
    className={'flex flex-col items-center justify-center text-center gap-2 py-12 px-6 ' + (className || '')}
  >
    <p className="text-sm font-semibold text-light">{title}</p>
    {description && <p className="text-xs text-muted max-w-md">{description}</p>}
    {action && <div className="mt-3">{action}</div>}
  </div>
);
