import * as React from 'react';

export interface ILoadingProps {
  /** Optional message shown under the spinner. */
  label?: string;
  /** Spinner diameter in pixels. */
  size?: number;
  /** Extra classes for the wrapper (e.g. height). */
  className?: string;
}

/** Branded (gold) loading indicator. Fills its parent without relying on 100vh. */
export const Loading: React.FC<ILoadingProps> = ({ label = 'Loading…', size = 32, className }) => (
  <div
    className={'flex flex-col items-center justify-center gap-3 py-16 ' + (className || '')}
    role="status"
    aria-live="polite"
  >
    <span
      className="easi-spinner"
      style={{ width: size, height: size, borderWidth: Math.max(2, Math.round(size / 10)) }}
    />
    {label && <span className="text-xs uppercase tracking-widest text-muted font-mono">{label}</span>}
  </div>
);
