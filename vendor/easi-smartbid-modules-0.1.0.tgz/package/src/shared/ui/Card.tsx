import * as React from 'react';

export interface ICardProps {
  /** Optional eyebrow/section label (uppercase, muted). */
  eyebrow?: string;
  /** Optional card title. */
  title?: React.ReactNode;
  /** Optional actions rendered on the right of the header. */
  actions?: React.ReactNode;
  /** Extra classes for the outer card. */
  className?: string;
  /** Extra classes for the body wrapper. */
  bodyClassName?: string;
  /** Adds a colored top accent border. */
  accent?: boolean;
  children?: React.ReactNode;
}

/** Standard surface card used across all EASI pages. */
export const Card: React.FC<ICardProps> = ({
  eyebrow,
  title,
  actions,
  className,
  bodyClassName,
  accent,
  children
}) => (
  <div
    className={
      'bg-surface border border-border rounded-none ' +
      (accent ? 'border-t-2 border-t-steel ' : '') +
      (className || '')
    }
  >
    {(eyebrow || title || actions) && (
      <div className="flex items-start justify-between gap-3 px-5 pt-4 pb-3 border-b border-border">
        <div className="min-w-0">
          {eyebrow && (
            <p className="text-xs uppercase tracking-widest text-muted font-mono">{eyebrow}</p>
          )}
          {title && <div className="text-light font-semibold mt-1 truncate">{title}</div>}
        </div>
        {actions && <div className="shrink-0 flex items-center gap-2">{actions}</div>}
      </div>
    )}
    <div className={'p-5 ' + (bodyClassName || '')}>{children}</div>
  </div>
);

export interface IMetricCardProps {
  label: string;
  value: React.ReactNode;
  hint?: string;
}

/** Compact KPI card used in metric grids. */
export const MetricCard: React.FC<IMetricCardProps> = ({ label, value, hint }) => (
  <div className="bg-surface border border-border border-t-2 border-t-steel p-4 rounded-none">
    <div className="text-xs uppercase tracking-widest text-muted font-mono">{label}</div>
    <div className="text-2xl font-mono font-semibold text-light mt-2">{value}</div>
    {hint && <div className="text-xs text-muted mt-1">{hint}</div>}
  </div>
);
