// Botões no padrão SMART BID 2.0 (ref.: BomCostsPage.module.scss .newBtn / .filterBtn).

export const BTN_PRIMARY =
  'inline-flex items-center justify-center gap-1.5 h-9 px-4 rounded-lg bg-teal text-white text-[13px] font-semibold leading-none transition hover:brightness-110 hover:-translate-y-px disabled:opacity-50 disabled:hover:translate-y-0 disabled:hover:brightness-100';

export const BTN_GHOST =
  'inline-flex items-center justify-center gap-1.5 h-9 px-4 rounded-lg border border-border text-muted text-[13px] font-semibold leading-none transition hover:border-teal hover:text-teal disabled:opacity-50';

export const BTN_SMALL =
  'inline-flex items-center justify-center h-8 px-3 rounded-md border border-border text-muted text-xs font-medium transition hover:border-teal hover:text-teal';

export const BTN_ICON =
  'inline-flex items-center justify-center w-8 h-8 rounded-md border border-border text-light text-sm transition hover:border-teal hover:text-teal';

export const BTN_LINK = 'text-xs font-semibold text-teal hover:underline';

export const TAB_ROW = 'flex flex-wrap gap-1';

export const tabCls = (active: boolean): string =>
  `px-3.5 py-1.5 rounded-md border text-xs font-medium transition whitespace-nowrap ${
    active ? 'bg-teal border-teal text-white' : 'border-border text-muted hover:border-teal hover:text-teal'
  }`;

export const chipCls = (active: boolean): string =>
  `px-2.5 py-1 rounded-md border text-[11px] font-medium transition ${
    active ? 'bg-teal border-teal text-white' : 'border-border text-muted hover:border-teal hover:text-teal'
  }`;
