import * as React from 'react';

export interface IErrorStateProps {
  /** Error message to display. */
  message: string;
  /** Optional title above the message. */
  title?: string;
  /** Optional retry handler; renders a retry button when provided. */
  onRetry?: () => void;
  className?: string;
}

/** Consistent, branded error panel. */
export const ErrorState: React.FC<IErrorStateProps> = ({
  message,
  title = 'Something went wrong',
  onRetry,
  className
}) => (
  <div
    role="alert"
    className={
      'flex flex-col items-center justify-center text-center gap-3 py-12 px-6 ' +
      'bg-surface border border-border border-t-2 border-t-red-500/70 rounded-none ' +
      (className || '')
    }
  >
    <p className="text-sm font-semibold text-light">{title}</p>
    <p className="text-xs text-muted max-w-md break-words">{message}</p>
    {onRetry && (
      <button
        type="button"
        onClick={onRetry}
        className="mt-1 px-4 py-2 text-xs uppercase tracking-widest font-mono text-gold border border-gold/40 rounded hover:bg-gold/10 transition"
      >
        Retry
      </button>
    )}
  </div>
);
