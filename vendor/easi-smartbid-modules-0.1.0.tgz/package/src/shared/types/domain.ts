/**
 * Tipos de domínio compartilhados entre módulos EASI portados.
 *
 * Origem: `src/webparts/easi/core/types.ts` do repo `easi-spfx`. Mantidos
 * intencionalmente idênticos para que os módulos possam ser copiados sem
 * ajustes de tipagem.
 */

export interface CostElement {
  id: string;
  description: string;
  unit_price_median: number;
  pricing_model: string;
  opportunity_id: string;
  category_final: string;
  bid_count: number;
  occurrence_count: number;
  et_text?: string;
  group?: string;
  pn?: string;
  category_method?: string;
  category_embed_score?: number;
  category_status?: string;
}

export interface Opportunity {
  opportunity_id: string;
  title: string;
  project?: string;
  client?: string;
  project_domain?: string;
}

export interface ClassificationResult {
  category: string;
  score: number;
  confidence: 'high' | 'medium' | 'low';
  ambiguous: boolean;
  runner_up?: string;
  runner_up_score?: number;
  method?: string;
}

/**
 * Uma linha da lista SharePoint "EASI - QUOTES" (uma linha por item cotado).
 * Espelha o shape original do `services/quotesStore.ts` sem depender de
 * `@microsoft/sp-http`.
 */
export interface QuoteListItem {
  id: number;
  quoteNumber: string;
  quoteDate: string;
  validUntil: string;
  supplier: string;
  supplierCountry: string;
  customer: string;
  reference: string;
  project: string;
  incoterms: string;
  paymentTerms: string;
  itemType: string;
  productCode: string;
  description: string;
  quantity: number | null;
  uom: string;
  unitPrice: number | null;
  rate: number | null;
  ratePeriod: string;
  currency: string;
  lineTotal: number | null;
  startDate: string;
  endDate: string;
  days: number | null;
  leadTimeDays: number | null;
  sourceFile: string;
  supplierId: string;
  modified: string;
}
