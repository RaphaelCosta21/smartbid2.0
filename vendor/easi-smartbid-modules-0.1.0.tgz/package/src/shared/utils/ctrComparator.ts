/**
 * ctrComparator.ts
 *
 * Client-side port of exemplos py/ctr_comparator.py — compares a new CTR
 * against one or more historical CTRs (already ingested in DATA.xlsx).
 *
 * Item matching mirrors the Python engine: exact (uppercased) part number, then
 * token-sort fuzzy on the normalized description. There is no embedding model in
 * the browser, so fuzzy uses the shared token-sort ratio from itemResolver.
 */

import { normalizeDesc, tokenSortRatio } from './itemResolver';

// ── PN helpers (ctr_comparator uses a lighter PN rule than item_resolver) ──────
const CTR_INVALID_PNS = new Set(['NA', 'N/A', 'TBD', 'TBC', 'N/D', '-', '', '0', 'NONE', 'NULL']);

function ctrNormalizePn(pn: unknown): string {
  if (pn === null || pn === undefined || pn === '') return '';
  return String(pn).trim().toUpperCase();
}

function ctrIsValidPn(pn: string): boolean {
  return !CTR_INVALID_PNS.has(pn.toUpperCase()) && pn.length >= 3;
}

function num(v: unknown, fallback = 0): number {
  if (v === null || v === undefined || v === '') return fallback;
  const n = typeof v === 'number' ? v : parseFloat(String(v));
  return Number.isFinite(n) ? n : fallback;
}

function txt(v: unknown): string {
  if (v === null || v === undefined) return '';
  return String(v).trim();
}

// ── Types ─────────────────────────────────────────────────────────────────────
export interface CtrItem {
  description: string;
  pn: string;
  category: string;
  pricingModel: string;
  unitPrice: number;
  quantity: number;
  currency: string;
  oppId: string;
  etText: string;
  _pnNorm: string;
  _descNorm: string;
}

export interface MatchedItem {
  description: string;
  historicalDescription: string;
  pn: string;
  category: string;
  pricingModelNew: string;
  pricingModelHist: string;
  unitPriceNew: number;
  unitPriceHist: number;
  currency: string;
  priceDeltaPct: number;
  priceDeltaUsd: number;
  opportunityHist: string;
  matchMethod: 'pn_exact' | 'fuzzy';
  similarityScore: number;
}

export interface MissingItem {
  description: string;
  pn: string;
  category: string;
  etText: string;
  pricingModel: string;
  unitPrice: number;
  quantity: number;
  currency: string;
  opportunityHist: string;
}

export interface NewCtrItem {
  description: string;
  pn: string;
  category: string;
  pricingModel: string;
  unitPrice: number;
  quantity: number;
  currency: string;
}

export interface ComparisonResult {
  oppNew: string;
  oppsHist: string[];
  matched: MatchedItem[];
  missing: MissingItem[];
  newItems: NewCtrItem[];
  totalNewUsd: number;
  totalHistUsd: number;
  priceVariancePct: number | null;
}

// ── Row normalization ─────────────────────────────────────────────────────────
export function normalizeCtrItems(rows: any[]): CtrItem[] {
  return (rows || []).map((r) => {
    const description = txt(r.description ?? r.Description);
    const pn = txt(r.pn ?? r.part_number);
    return {
      description,
      pn,
      category: txt(r.category_final ?? r.category),
      pricingModel: txt(r.pricing_model ?? r.type_raw),
      unitPrice: num(r.unit_price ?? r.unit_price_median),
      quantity: num(r.quantity, 1),
      currency: txt(r.currency) || 'USD',
      oppId: txt(r.opportunity_id ?? r.oppId),
      etText: txt(r.et_text),
      _pnNorm: ctrNormalizePn(pn),
      _descNorm: normalizeDesc(description),
    };
  });
}

// ── Compare ─────────────────────────────────────────────────────────────────
/**
 * Compares a new CTR against the aggregated historical CTR(s).
 * Ported from CTRComparator.compare (fuzzy path uses token-sort ratio).
 */
export function compareCtr(
  newCost: CtrItem[],
  histCost: CtrItem[],
  oppNew: string,
  oppsHist: string[],
  fuzzyThreshold = 0.75
): ComparisonResult {
  const matched: MatchedItem[] = [];
  const missing: MissingItem[] = [];
  const newItems: NewCtrItem[] = [];

  const existingNewPns = new Set<string>();
  for (const r of newCost) if (ctrIsValidPn(r._pnNorm)) existingNewPns.add(r._pnNorm);

  const matchedHistIdx = new Set<number>();

  for (const rowNew of newCost) {
    let best: CtrItem | null = null;
    let bestScore = 0;
    let bestIdx = -1;
    const pnNew = rowNew._pnNorm;

    for (let idx = 0; idx < histCost.length; idx++) {
      if (matchedHistIdx.has(idx)) continue;
      const rowHist = histCost[idx];
      const pnHist = rowHist._pnNorm;

      if (ctrIsValidPn(pnNew) && pnNew === pnHist) {
        best = rowHist;
        bestScore = 1.0;
        bestIdx = idx;
        break;
      }

      const score = tokenSortRatio(rowNew._descNorm, rowHist._descNorm);
      if (score >= fuzzyThreshold && score > bestScore) {
        best = rowHist;
        bestScore = score;
        bestIdx = idx;
      }
    }

    if (best) {
      matchedHistIdx.add(bestIdx);
      const pNew = rowNew.unitPrice;
      const pHist = best.unitPrice;
      matched.push({
        description: rowNew.description,
        historicalDescription: best.description,
        pn: rowNew.pn,
        category: rowNew.category,
        pricingModelNew: rowNew.pricingModel,
        pricingModelHist: best.pricingModel,
        unitPriceNew: pNew,
        unitPriceHist: pHist,
        currency: rowNew.currency || 'USD',
        priceDeltaPct: pHist ? (pNew - pHist) / pHist : 0,
        priceDeltaUsd: pNew - pHist,
        opportunityHist: best.oppId,
        matchMethod: bestScore === 1.0 ? 'pn_exact' : 'fuzzy',
        similarityScore: Math.round(bestScore * 1000) / 1000,
      });
    } else {
      newItems.push({
        description: rowNew.description,
        pn: rowNew.pn,
        category: rowNew.category,
        pricingModel: rowNew.pricingModel,
        unitPrice: rowNew.unitPrice,
        quantity: rowNew.quantity,
        currency: rowNew.currency || 'USD',
      });
    }
  }

  for (const rowHist of histCost) {
    const pnHist = rowHist._pnNorm;
    if (ctrIsValidPn(pnHist) && existingNewPns.has(pnHist)) continue;
    missing.push({
      description: rowHist.description,
      pn: rowHist.pn,
      category: rowHist.category,
      etText: rowHist.etText,
      pricingModel: rowHist.pricingModel,
      unitPrice: rowHist.unitPrice,
      quantity: rowHist.quantity,
      currency: rowHist.currency || 'USD',
      opportunityHist: rowHist.oppId,
    });
  }

  const totalNewUsd = newCost.reduce((s, r) => s + r.unitPrice, 0);
  const totalHistUsd = histCost.reduce((s, r) => s + r.unitPrice, 0);
  const priceVariancePct = totalHistUsd === 0 ? null : (totalNewUsd - totalHistUsd) / totalHistUsd;

  return { oppNew, oppsHist, matched, missing, newItems, totalNewUsd, totalHistUsd, priceVariancePct };
}
