/**
 * Intelligent search engine — free / offline (no API, no model download).
 *
 * The user describes what they need in natural language (PT or EN) and the
 * engine returns the most relevant historical items (PNs) ranked by relevance.
 * Example: "Preciso de um conector hidráulico de 2\"" -> ranked hydraulic
 * connectors around 2 inch.
 *
 * Strategy (100% in-browser, zero cost):
 *   1. Normalize text (strip accents, canonicalize dimensions/units).
 *   2. Expand query tokens through a PT/EN synonym dictionary.
 *   3. Score each item = term coverage + fuzzy similarity + dimension bonus.
 *
 * The `SearchEngine` interface is intentionally the same shape a future
 * embedding-based engine would expose, so semantic search can be plugged in
 * later without touching the page (see `lexicalEngine`).
 */

import { normalizeCostRows, similarityRatio, toNumber, type BenchItem } from './benchmark';

// ─────────────────────────────────────────────────────────────────────────────
// Public types
// ─────────────────────────────────────────────────────────────────────────────

export interface SearchItem {
  index: number;
  pn: string;
  description: string;
  /** Portuguese description (from the ERP), searched alongside the English one. */
  descriptionPt?: string;
  category: string;
  group: string;
  unitPrice: number;
  currency: string;
  oppId: string;
  /** ERP supply snapshot (stock/cost/vendor/lead time), attached when available. */
  supply?: SupplyInfo;
  /** Margin of the historical quote vs. our real supply cost, when computable. */
  margin?: MarginInfo;
}

/** ERP supply snapshot for one PN (from the daily Supply_Index sheet). */
export interface SupplyInfo {
  pn: string;
  qtyOnHand: number;
  qtyAvailable: number;
  unitCostUsd: number;
  avgCostUsd: number;
  replCostUsd: number;
  lastPricePaid: number;
  vendorName: string;
  leadTimeDays: number | undefined;
  /** Date of the last purchase order for this item (YYYY-MM-DD), when known. */
  poDate: string | undefined;
  inStock: boolean;
}

export interface MarginInfo {
  /** Real unit cost used as the basis (USD). */
  costUsd: number;
  /** Absolute margin: historical quote - cost (USD). */
  amountUsd: number;
  /** Relative margin: (quote - cost) / quote, in the 0..1 range. */
  pct: number;
}

export interface SearchResult {
  item: SearchItem;
  /** Relevance score in the 0..1 range. */
  score: number;
  /** Query concepts that were found in the item (for "why it matched" UI). */
  matchedTerms: string[];
}

export interface SearchOptions {
  /** Maximum number of results to return. Defaults to 50. */
  limit?: number;
  /** Minimum score to include a result. Defaults to 0.08. */
  minScore?: number;
}

export interface SearchEngine {
  /** Sync (lexical) or async (embedding-backed) — the page handles both. */
  search(query: string, items: SearchItem[], opts?: SearchOptions): SearchResult[] | Promise<SearchResult[]>;
}

// ─────────────────────────────────────────────────────────────────────────────
// Data adapter
// ─────────────────────────────────────────────────────────────────────────────

/** Builds searchable items from raw Cost_Element rows (reuses benchmark parsing). */
export function buildSearchItems(costRows: Array<Record<string, unknown>>): SearchItem[] {
  return normalizeCostRows(costRows).map(fromBenchItem);
}

function fromBenchItem(b: BenchItem): SearchItem {
  return {
    index: b.index,
    pn: b.pn,
    description: b.description,
    category: b.category,
    group: b.group,
    unitPrice: b.unitPrice,
    currency: b.currency,
    oppId: b.oppId,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Supply (ERP) integration — joined to bids by PN (== ERP Item code)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Canonical key for joining. Bid PNs and ERP Items are the same code, but the
 * ERP zero-pads to 7 digits ("0000143") while a bid may store "143" — so for
 * numeric codes we compare without leading zeros.
 */
export function pnKey(pn: string): string {
  const t = (pn || '').trim();
  return /^\d+$/.test(t) ? String(parseInt(t, 10)) : t.toLowerCase();
}

function str(row: Record<string, unknown>, key: string): string {
  const v = row[key];
  return v === null || v === undefined ? '' : String(v).trim();
}

function num(row: Record<string, unknown>, key: string): number {
  return toNumber(row[key]);
}

/** Parses one Supply_Index row into a SupplyInfo snapshot. */
function supplyInfoFromRow(row: Record<string, unknown>): SupplyInfo {
  const qtyAvailable = num(row, 'qty_available');
  const leadRaw = row.lead_time_days;
  const poRaw = str(row, 'po_due_date');
  return {
    pn: str(row, 'pn'),
    qtyOnHand: num(row, 'qty_on_hand'),
    qtyAvailable,
    unitCostUsd: num(row, 'unit_cost_usd'),
    avgCostUsd: num(row, 'avg_cost_usd'),
    replCostUsd: num(row, 'repl_cost_usd'),
    lastPricePaid: num(row, 'last_price_paid'),
    vendorName: str(row, 'vendor_name'),
    leadTimeDays: leadRaw === null || leadRaw === undefined || leadRaw === '' ? undefined : num(row, 'lead_time_days'),
    poDate: poRaw ? poRaw.slice(0, 10) : undefined,
    inStock: qtyAvailable > 0,
  };
}

/** Builds a PN -> SupplyInfo map from raw Supply_Index rows. */
export function buildSupplyMap(rows: Array<Record<string, unknown>>): Map<string, SupplyInfo> {
  const map = new Map<string, SupplyInfo>();
  for (const row of rows) {
    const pn = str(row, 'pn');
    if (!pn) continue;
    map.set(pnKey(pn), supplyInfoFromRow(row));
  }
  return map;
}

/**
 * Builds searchable items directly from the ERP Supply_Index (the daily
 * "queries"). Each item carries PN + description (EN, with PT fallback) and its
 * supply snapshot, so a free-text search returns the matching PNs/descriptions.
 */
export function buildSupplyItems(rows: Array<Record<string, unknown>>): SearchItem[] {
  const items: SearchItem[] = [];
  rows.forEach((row, index) => {
    const pn = str(row, 'pn');
    const descEn = str(row, 'description');
    const descPt = str(row, 'description_pt');
    if (!pn && !descEn && !descPt) return;
    const supply = supplyInfoFromRow(row);
    items.push({
      index,
      pn,
      description: descEn || descPt,
      descriptionPt: descPt,
      category: str(row, 'item_category'),
      group: '',
      unitPrice: 0,
      currency: 'USD',
      oppId: '',
      supply,
    });
  });
  return items;
}

/** Best available USD cost basis for margin (avg -> replacement -> unit cost). */
function costBasis(s: SupplyInfo): number {
  return s.avgCostUsd || s.replCostUsd || s.unitCostUsd || 0;
}

/** Computes the margin of a historical quote against our real supply cost. */
export function computeMargin(quoteUsd: number, supply: SupplyInfo): MarginInfo | undefined {
  const cost = costBasis(supply);
  if (!(quoteUsd > 0) || !(cost > 0)) return undefined;
  const amount = quoteUsd - cost;
  return { costUsd: cost, amountUsd: amount, pct: amount / quoteUsd };
}

/** Attaches supply + margin to each item (returns new objects; input untouched). */
export function attachSupply(items: SearchItem[], supply: Map<string, SupplyInfo>): SearchItem[] {
  if (supply.size === 0) return items;
  return items.map((it) => {
    const info = supply.get(pnKey(it.pn));
    if (!info) return it;
    return { ...it, supply: info, margin: computeMargin(it.unitPrice, info) };
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// Text normalization
// ─────────────────────────────────────────────────────────────────────────────

/** Removes diacritics so accented/unaccented terms match ("hidráulico" == "hidraulico"). */
export function stripAccents(s: string): string {
  return s.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}

/**
 * Canonicalizes dimensions/units so "2\"", "2 pol", "2 polegadas", "2in" and
 * "2 inch" all collapse to the same token `2in` (and millimetres to `<n>mm`).
 */
export function normalizeDimensions(text: string): string {
  let t = text;
  // Inch family: quotes, in, inch(es), pol/polegada(s). Supports decimals and fractions (1/2").
  t = t.replace(
    /(\d+(?:[.,]\d+)?|\d+\s*\/\s*\d+)\s*(?:"|''|inch(?:es)?|in\b|pol(?:egadas?)?)/gi,
    (_m, num: string) => `${num.replace(',', '.').replace(/\s+/g, '')}in`
  );
  // Millimetre family.
  t = t.replace(
    /(\d+(?:[.,]\d+)?)\s*(?:mm|mil[ií]?metros?)/gi,
    (_m, num: string) => `${num.replace(',', '.')}mm`
  );
  return t;
}

/** Full normalization pipeline: dimensions -> lowercase -> strip accents. */
export function normalizeText(text: string): string {
  return stripAccents(normalizeDimensions(text || '')).toLowerCase();
}

/** Text used to represent an item for embedding (description + category + group). */
export function buildItemText(item: SearchItem): string {
  return normalizeText(`${item.description} ${item.descriptionPt || ''} ${item.category} ${item.group}`.trim());
}

// ─────────────────────────────────────────────────────────────────────────────
// Language resources (stored unaccented + lowercase)
// ─────────────────────────────────────────────────────────────────────────────

/** Words carrying no search meaning; dropped from the query. */
const STOPWORDS: ReadonlySet<string> = new Set([
  // PT
  'preciso', 'de', 'um', 'uma', 'uns', 'umas', 'para', 'pra', 'com', 'sem', 'o', 'a', 'os', 'as',
  'e', 'ou', 'do', 'da', 'dos', 'das', 'no', 'na', 'nos', 'nas', 'que', 'quero', 'gostaria',
  'tenho', 'ter', 'buscar', 'procurar', 'preciso', 'algum', 'alguma', 'seja', 'tipo',
  // EN
  'i', 'need', 'want', 'looking', 'for', 'the', 'an', 'of', 'with', 'without', 'some', 'any',
  'please', 'find', 'to', 'and', 'or', 'is', 'are', 'kind', 'type',
]);

/**
 * Synonym groups (PT <-> EN, unaccented). A query token that belongs to a group
 * also matches every other member of that group.
 */
const SYNONYM_GROUPS: readonly string[][] = [
  ['conector', 'connector', 'conexao', 'fitting', 'fittings'],
  ['hidraulico', 'hydraulic', 'hydraulics'],
  ['valvula', 'valve', 'valves'],
  ['bomba', 'pump', 'pumps'],
  ['mangueira', 'hose', 'hoses'],
  ['flange', 'flanges'],
  ['junta', 'gasket', 'seal', 'vedacao', 'oring', 'o-ring', 'seals'],
  ['cabo', 'cable', 'cables', 'umbilical'],
  ['sensor', 'sensores', 'sensors', 'transducer', 'transdutor'],
  ['tubo', 'tubulacao', 'pipe', 'pipes', 'tube', 'tubes', 'tubing'],
  ['parafuso', 'bolt', 'bolts', 'screw', 'screws'],
  ['porca', 'nut', 'nuts'],
  ['motor', 'engine', 'motores', 'engines'],
  ['filtro', 'filter', 'filters'],
  ['adaptador', 'adapter', 'adaptor', 'adapters'],
  ['acoplamento', 'coupling', 'couplings'],
  ['rolamento', 'bearing', 'bearings'],
  ['anel', 'ring', 'rings'],
  ['atuador', 'actuator', 'actuators'],
];

const SYNONYM_MAP: ReadonlyMap<string, number> = (() => {
  const m = new Map<string, number>();
  SYNONYM_GROUPS.forEach((group, i) => group.forEach((word) => m.set(word, i)));
  return m;
})();

// ─────────────────────────────────────────────────────────────────────────────
// Query analysis
// ─────────────────────────────────────────────────────────────────────────────

interface QueryConcept {
  /** The token as typed (normalized). */
  token: string;
  /** All words that should count as a match for this concept. */
  expansions: string[];
  /** True when the token is a dimension (e.g. "2in"), used for the size bonus. */
  isDimension: boolean;
}

const DIMENSION_RE = /^\d+(?:[.\/]\d+)?(?:in|mm)$/;

function tokenize(query: string): string[] {
  return normalizeText(query)
    .split(/[^a-z0-9./]+/)
    .filter(Boolean);
}

/** Turns a raw query into de-duplicated concepts (with synonym expansions). */
export function analyzeQuery(query: string): QueryConcept[] {
  const seen = new Set<string>();
  const concepts: QueryConcept[] = [];
  for (const token of tokenize(query)) {
    const isDimension = DIMENSION_RE.test(token);
    if (!isDimension && (STOPWORDS.has(token) || token.length < 2)) continue;
    if (seen.has(token)) continue;
    seen.add(token);
    const groupIdx = SYNONYM_MAP.get(token);
    const expansions =
      groupIdx === undefined ? [token] : SYNONYM_GROUPS[groupIdx].slice();
    concepts.push({ token, expansions, isDimension });
  }
  return concepts;
}

// ─────────────────────────────────────────────────────────────────────────────
// Lexical scoring engine (default, zero-cost)
// ─────────────────────────────────────────────────────────────────────────────

const WEIGHT_COVERAGE = 0.7;
const WEIGHT_FUZZY = 0.3;
const DIMENSION_BONUS = 0.15;

function haystack(item: SearchItem): string {
  return normalizeText(`${item.description} ${item.descriptionPt || ''} ${item.pn} ${item.category} ${item.group}`);
}

function scoreItem(concepts: QueryConcept[], keyTerms: string, item: SearchItem): SearchResult | undefined {
  if (concepts.length === 0) return undefined;
  const hay = haystack(item);

  let hits = 0;
  let dimensionMatched = false;
  const matchedTerms: string[] = [];

  for (const concept of concepts) {
    const found = concept.expansions.some((w) => hay.indexOf(w) !== -1);
    if (found) {
      hits += 1;
      matchedTerms.push(concept.token);
      if (concept.isDimension) dimensionMatched = true;
    }
  }

  const coverage = hits / concepts.length;
  const fuzzy = similarityRatio(keyTerms, normalizeText(item.description));
  let score = coverage * WEIGHT_COVERAGE + fuzzy * WEIGHT_FUZZY;
  if (dimensionMatched) score = Math.min(score + DIMENSION_BONUS, 1);

  if (score <= 0) return undefined;
  return { item, score, matchedTerms };
}

/** Lexical, offline, zero-cost search (the live default). */
export function lexicalSearch(query: string, items: SearchItem[], opts: SearchOptions = {}): SearchResult[] {
  const limit = opts.limit ?? 50;
  const minScore = opts.minScore ?? 0.08;

  const concepts = analyzeQuery(query);
  if (concepts.length === 0) return [];
  const keyTerms = concepts.map((c) => c.token).join(' ');

  const results: SearchResult[] = [];
  for (const item of items) {
    const r = scoreItem(concepts, keyTerms, item);
    if (r && r.score >= minScore) results.push(r);
  }

  results.sort((a, b) => b.score - a.score);
  return results.slice(0, limit);
}

/** Default engine — lexical, offline, no cost. Swap for an embedding engine later. */
export const lexicalEngine: SearchEngine = { search: lexicalSearch };

// ─────────────────────────────────────────────────────────────────────────────
// Semantic engine (sketch) — real AI plug-in point
// ─────────────────────────────────────────────────────────────────────────────
//
// This is the seam where genuine AI drops in without touching the page. Two
// interchangeable providers fit the same `EmbedFn` contract:
//
//   • Free/offline  — Transformers.js (all-MiniLM-L6-v2) running in the browser.
//   • API/higher-Q  — Azure OpenAI `text-embedding-3-small` via a Power Automate
//                      proxy (key stays server-side; never in the SPFx bundle).
//
// Item vectors are computed ONCE (ideally precomputed in the Python pipeline and
// shipped in a `Supply_Index`/`Item_Vectors` sheet) and cached; only the query
// is embedded per search. Until a provider is wired, it falls back to lexical.

/** Embeds one or more texts into vectors. Implemented by a browser model or a proxy. */
export type EmbedFn = (texts: string[]) => Promise<number[][]>;

/** A precomputed item vector, keyed to a SearchItem by index. */
export interface ItemVector {
  index: number;
  vector: number[];
}

/** Cosine similarity of two equal-length vectors (0..1 for non-negative embeddings). */
export function cosine(a: number[], b: number[]): number {
  let dot = 0;
  let na = 0;
  let nb = 0;
  const len = Math.min(a.length, b.length);
  for (let i = 0; i < len; i++) {
    dot += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  if (na === 0 || nb === 0) return 0;
  return dot / (Math.sqrt(na) * Math.sqrt(nb));
}

/**
 * Builds a semantic engine from an embedding provider + precomputed item vectors.
 * Falls back to the lexical engine when either is missing, so the page keeps
 * working while AI is being rolled out.
 */
export function createEmbeddingEngine(embed?: EmbedFn, vectors?: ItemVector[]): SearchEngine {
  if (!embed || !vectors || vectors.length === 0) return lexicalEngine;

  const byIndex = new Map<number, number[]>();
  vectors.forEach((v) => byIndex.set(v.index, v.vector));

  return {
    async search(query, items, opts = {}): Promise<SearchResult[]> {
      const q = query.trim();
      if (!q) return [];
      const limit = opts.limit ?? 50;
      const minScore = opts.minScore ?? 0.2;

      const [queryVec] = await embed([normalizeText(q)]);
      const results: SearchResult[] = [];
      for (const item of items) {
        const vec = byIndex.get(item.index);
        if (!vec) continue;
        const score = cosine(queryVec, vec);
        if (score >= minScore) results.push({ item, score, matchedTerms: [] });
      }
      results.sort((a, b) => b.score - a.score);
      return results.slice(0, limit);
    },
  };
}

