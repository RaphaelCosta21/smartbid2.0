/**
 * Supplier catalog store — browser-persisted (localStorage).
 *
 * Port of `supplier_store.py` to the SPFx web part. DATA.xlsx is read-only, so
 * the supplier catalog (suppliers, contacts, PNs, categories and the quotations
 * linked to each supplier) is persisted per-user in localStorage, mirroring the
 * Item Resolver alias store pattern.
 *
 * Quotations are fed from the "EASI - QUOTES" SharePoint list (populated by the
 * Power Automate extractor). Because the AI extraction can make mistakes, every
 * mapped field is editable before/while it is saved into a supplier here.
 */

const STORAGE_KEY = 'easi.suppliers.v1';

/** Default supplier categories (subsea / ROV services domain). */
export const DEFAULT_CATEGORIES: string[] = [
  'Survey Equipment',
  'ROV Systems',
  'ROV Tooling',
  'Tethering Systems',
  'IWOCS / Well Intervention',
  'Acoustic Positioning (USBL/LBL)',
  'Subsea Distribution',
  'Inspection Equipment',
  'Deck Equipment',
  'Consumables',
  'Engineering Services',
  'Logistics / Freight',
  'Other',
];

export interface SupplierContact {
  name: string;
  email: string;
  phone?: string;
}

export interface Quotation {
  /** Stable client id for editing/removal. */
  id: string;
  quote_number: string;
  date: string;
  valid_until?: string;
  /** Reference / Project / Opportunity the quote relates to. */
  opportunity_id: string;
  item_type: string; // Rental | Sale
  pn: string;
  description: string;
  quantity?: number;
  uom?: string;
  unit_price: number;
  rate?: number;
  rate_period?: string;
  currency: string;
  total?: number;
  lead_time_days?: number;
  notes?: string;
  /** Origin document (link/name) captured by the flow. */
  source_file?: string;
  /** SharePoint list item id this quotation came from (dedupe). */
  source_item_id?: number;
}

export interface Supplier {
  supplier_id: string;
  name: string;
  categories: string[];
  contacts: SupplierContact[];
  country: string;
  pns_supplied: string[];
  notes: string;
  quotations: Quotation[];
  active: boolean;
  created_at: string;
  updated_at: string;
}

export interface SupplierStats {
  total_suppliers: number;
  total_quotations: number;
  unique_categories: number;
  unique_pns: number;
}

// ── ids ──────────────────────────────────────────────────────────────────────
function uuid8(): string {
  let s = '';
  for (let i = 0; i < 8; i++) s += Math.floor(Math.random() * 16).toString(16);
  return s.toUpperCase();
}

export function newSupplierId(): string {
  return `SUP_${uuid8()}`;
}

export function newQuotationId(): string {
  return `Q_${Date.now().toString(36)}_${uuid8().slice(0, 4)}`;
}

// ── persistence ──────────────────────────────────────────────────────────────
export function loadSuppliers(): Supplier[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Supplier[];
    if (!Array.isArray(parsed)) return [];
    return parsed.map(normalizeSupplier);
  } catch {
    return [];
  }
}

export function saveSuppliers(suppliers: Supplier[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(suppliers));
  } catch (err) {
    console.warn('Could not persist suppliers:', err);
  }
}

function normalizeSupplier(s: Partial<Supplier>): Supplier {
  return {
    supplier_id: s.supplier_id || newSupplierId(),
    name: s.name || '',
    categories: Array.isArray(s.categories) ? s.categories : [],
    contacts: Array.isArray(s.contacts) ? s.contacts : [],
    country: s.country || '',
    pns_supplied: Array.isArray(s.pns_supplied) ? s.pns_supplied : [],
    notes: s.notes || '',
    quotations: Array.isArray(s.quotations) ? s.quotations : [],
    active: s.active !== false,
    created_at: s.created_at || new Date().toISOString(),
    updated_at: s.updated_at || new Date().toISOString(),
  };
}

// ── queries ──────────────────────────────────────────────────────────────────
export function listSuppliers(activeOnly = true): Supplier[] {
  const all = loadSuppliers();
  const filtered = activeOnly ? all.filter((s) => s.active) : all;
  return filtered.sort((a, b) => a.name.localeCompare(b.name));
}

export function getSupplier(supplierId: string): Supplier | undefined {
  return loadSuppliers().filter((s) => s.supplier_id === supplierId)[0];
}

export function findByName(name: string): Supplier | undefined {
  const q = name.trim().toLowerCase();
  if (!q) return undefined;
  return listSuppliers().filter((s) => s.name.toLowerCase().indexOf(q) !== -1)[0];
}

export function search(term: string): Supplier[] {
  const q = term.trim().toLowerCase();
  if (!q) return listSuppliers();
  return listSuppliers().filter((s) => {
    if (s.name.toLowerCase().indexOf(q) !== -1) return true;
    if (s.country.toLowerCase().indexOf(q) !== -1) return true;
    if (s.categories.some((c) => c.toLowerCase().indexOf(q) !== -1)) return true;
    if (s.pns_supplied.some((p) => p.toLowerCase().indexOf(q) !== -1)) return true;
    if (s.contacts.some((c) => `${c.name} ${c.email} ${c.phone || ''}`.toLowerCase().indexOf(q) !== -1)) return true;
    if (s.quotations.some((qt) => `${qt.pn} ${qt.description}`.toLowerCase().indexOf(q) !== -1)) return true;
    return false;
  });
}

// ── mutations ────────────────────────────────────────────────────────────────
export function createSupplier(data: {
  name: string;
  categories?: string[];
  country?: string;
  contacts?: SupplierContact[];
  notes?: string;
  pns_supplied?: string[];
}): Supplier {
  const now = new Date().toISOString();
  const supplier: Supplier = {
    supplier_id: newSupplierId(),
    name: data.name.trim(),
    categories: data.categories || [],
    contacts: data.contacts || [],
    country: data.country || '',
    pns_supplied: data.pns_supplied || [],
    notes: data.notes || '',
    quotations: [],
    active: true,
    created_at: now,
    updated_at: now,
  };
  const all = loadSuppliers();
  all.push(supplier);
  saveSuppliers(all);
  return supplier;
}

export function updateSupplier(
  supplierId: string,
  patch: Partial<Omit<Supplier, 'supplier_id' | 'created_at'>>
): Supplier | undefined {
  const all = loadSuppliers();
  const idx = all.findIndex((s) => s.supplier_id === supplierId);
  if (idx === -1) return undefined;
  all[idx] = { ...all[idx], ...patch, updated_at: new Date().toISOString() };
  saveSuppliers(all);
  return all[idx];
}

/** Soft delete (kept for history but hidden from active lists). */
export function deleteSupplier(supplierId: string): void {
  updateSupplier(supplierId, { active: false });
}

export function addQuotation(supplierId: string, quotation: Quotation): Supplier | undefined {
  const all = loadSuppliers();
  const idx = all.findIndex((s) => s.supplier_id === supplierId);
  if (idx === -1) return undefined;
  const supplier = all[idx];
  supplier.quotations.push(quotation);
  // Keep the PN list in sync so the supplier is findable by PN.
  if (quotation.pn && supplier.pns_supplied.indexOf(quotation.pn) === -1) {
    supplier.pns_supplied.push(quotation.pn);
  }
  supplier.updated_at = new Date().toISOString();
  saveSuppliers(all);
  return supplier;
}

export function updateQuotation(
  supplierId: string,
  quotationId: string,
  patch: Partial<Quotation>
): Supplier | undefined {
  const all = loadSuppliers();
  const idx = all.findIndex((s) => s.supplier_id === supplierId);
  if (idx === -1) return undefined;
  const qIdx = all[idx].quotations.findIndex((q) => q.id === quotationId);
  if (qIdx === -1) return undefined;
  all[idx].quotations[qIdx] = { ...all[idx].quotations[qIdx], ...patch };
  all[idx].updated_at = new Date().toISOString();
  saveSuppliers(all);
  return all[idx];
}

export function removeQuotation(supplierId: string, quotationId: string): Supplier | undefined {
  const all = loadSuppliers();
  const idx = all.findIndex((s) => s.supplier_id === supplierId);
  if (idx === -1) return undefined;
  all[idx].quotations = all[idx].quotations.filter((q) => q.id !== quotationId);
  all[idx].updated_at = new Date().toISOString();
  saveSuppliers(all);
  return all[idx];
}

/** Returns true if a quotation from the given SharePoint list item already exists. */
export function isQuoteItemImported(sourceItemId: number): boolean {
  return loadSuppliers().some((s) => s.quotations.some((q) => q.source_item_id === sourceItemId));
}

// ── stats ────────────────────────────────────────────────────────────────────
export function getStats(): SupplierStats {
  const suppliers = listSuppliers();
  const categories = new Set<string>();
  const pns = new Set<string>();
  let quotations = 0;
  suppliers.forEach((s) => {
    s.categories.forEach((c) => categories.add(c));
    s.pns_supplied.forEach((p) => pns.add(p));
    quotations += s.quotations.length;
  });
  return {
    total_suppliers: suppliers.length,
    total_quotations: quotations,
    unique_categories: categories.size,
    unique_pns: pns.size,
  };
}
