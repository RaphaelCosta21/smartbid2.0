/**
 * itemResolver.ts
 *
 * Client-side port of exemplos py/item_resolver.py — resolves whether items
 * from different BIDs are the same physical item, and manages an alias
 * ("aliados") library for item descriptions / part numbers.
 *
 * The SharePoint DATA.xlsx is read-only from the web part, so confirmed aliases
 * are persisted in localStorage instead of item_aliases.json (mirrors the
 * approach used in Modules 04 and 05). There is no embedding model in the
 * browser, so description similarity uses a token-sort fuzzy ratio.
 */

const ALIAS_KEY = 'easi.itemAliases.v1';

export const INVALID_PNS = new Set([
  'na', 'n/a', 'n/d', 'tbd', 'tbc', 'pending', 'none', 'null', '-', '--', '---', '0', '00', 'tba', '?', '', 'nan', 'nd',
]);

export const FUZZY_THRESHOLD = 0.72;

export type MatchMethod = 'alias' | 'pn_exact' | 'desc_exact' | 'embedding' | 'fuzzy_desc';
export type MatchStatus = 'pending' | 'confirmed' | 'rejected';

export interface ResolverItem {
  pn: string;
  description: string;
  oppId: string;
  unitPrice: number;
  pricingModel: string;
  _pnNorm: string;
  _descNorm: string;
}

export interface ItemMatch {
  newPn: string;
  newDescription: string;
  newOppId: string;
  newUnitPrice: number;
  newPricingModel: string;

  histPn: string;
  histDescription: string;
  histOppId: string;
  histUnitPrice: number;
  histPricingModel: string;

  method: MatchMethod;
  confidence: number;
  status: MatchStatus;
  canonicalId?: string;
}

export interface CanonicalItem {
  canonical_id: string;
  primary_pn: string;
  primary_description: string;
  all_pns: string[];
  all_descriptions: string[];
}

export interface AliasData {
  pn_aliases: Record<string, string>;
  desc_aliases: Record<string, string>;
  canonical_items: Record<string, CanonicalItem>;
  rejected: Record<string, true>;
}

// ── normalization ─────────────────────────────────────────────────────────────
export function normalizePn(pn: unknown): string {
  if (pn === null || pn === undefined) return '';
  let s = String(pn).trim().toUpperCase();
  s = s.replace(/[^A-Z0-9]/g, '');
  if (['NA', 'NAN', 'ND', 'TBD', 'TBC', ''].indexOf(s) !== -1) return '';
  return s;
}

export function isValidPn(pn: string): boolean {
  if (!pn) return false;
  if (INVALID_PNS.has(pn.toLowerCase())) return false;
  return /[0-9]/.test(pn); // needs at least one digit
}

export function normalizeDesc(desc: unknown): string {
  if (!desc) return '';
  return String(desc)
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function hash8(text: string): string {
  // djb2 → unsigned → base36 (stable, short, reproducible)
  let h = 5381;
  for (let i = 0; i < text.length; i++) {
    h = (h * 33) ^ text.charCodeAt(i);
  }
  return (h >>> 0).toString(36).slice(0, 8).padStart(8, '0');
}

export function makeCanonicalId(pn: string, description: string): string {
  if (isValidPn(pn)) return `PN_${pn}`;
  return `DESC_${hash8(normalizeDesc(description))}`;
}

// ── fuzzy similarity (token-sort ratio, 0..1) ─────────────────────────────────
function levenshtein(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  if (m === 0) return n;
  if (n === 0) return m;
  let prev = new Array<number>(n + 1);
  let curr = new Array<number>(n + 1);
  for (let j = 0; j <= n; j++) prev[j] = j;
  for (let i = 1; i <= m; i++) {
    curr[0] = i;
    for (let j = 1; j <= n; j++) {
      const cost = a.charCodeAt(i - 1) === b.charCodeAt(j - 1) ? 0 : 1;
      curr[j] = Math.min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + cost);
    }
    const tmp = prev;
    prev = curr;
    curr = tmp;
  }
  return prev[n];
}

function ratio(a: string, b: string): number {
  if (!a.length && !b.length) return 1;
  const maxLen = Math.max(a.length, b.length);
  if (maxLen === 0) return 1;
  return 1 - levenshtein(a, b) / maxLen;
}

export function tokenSortRatio(a: string, b: string): number {
  const sa = a.split(' ').filter(Boolean).sort().join(' ');
  const sb = b.split(' ').filter(Boolean).sort().join(' ');
  return ratio(sa, sb);
}

// ── data normalization ────────────────────────────────────────────────────────
function num(v: unknown): number {
  if (v === null || v === undefined || v === '') return 0;
  const n = typeof v === 'number' ? v : parseFloat(String(v));
  return Number.isFinite(n) ? n : 0;
}

function txt(v: unknown): string {
  if (v === null || v === undefined) return '';
  return String(v).trim();
}

export function normalizeResolverItems(rows: any[]): ResolverItem[] {
  return (rows || []).map((r) => {
    const pn = txt(r.pn);
    const description = txt(r.description);
    return {
      pn,
      description,
      oppId: txt(r.opportunity_id ?? r.oppId),
      unitPrice: num(r.unit_price ?? r.unit_price_median),
      pricingModel: txt(r.pricing_model ?? r.type_raw),
      _pnNorm: normalizePn(pn),
      _descNorm: normalizeDesc(description),
    };
  });
}

// ── alias store (localStorage) ────────────────────────────────────────────────
function emptyAliases(): AliasData {
  return { pn_aliases: {}, desc_aliases: {}, canonical_items: {}, rejected: {} };
}

export function loadAliases(): AliasData {
  try {
    const raw = localStorage.getItem(ALIAS_KEY);
    if (!raw) return emptyAliases();
    const parsed = JSON.parse(raw) as Partial<AliasData>;
    return {
      pn_aliases: parsed.pn_aliases || {},
      desc_aliases: parsed.desc_aliases || {},
      canonical_items: parsed.canonical_items || {},
      rejected: parsed.rejected || {},
    };
  } catch {
    return emptyAliases();
  }
}

export function saveAliases(data: AliasData): void {
  try {
    localStorage.setItem(ALIAS_KEY, JSON.stringify(data));
  } catch {
    /* storage unavailable — keep in-memory only */
  }
}

function rejectionKey(newDesc: string, histDesc: string): string {
  return `${normalizeDesc(newDesc)}||${normalizeDesc(histDesc)}`;
}

export function isRejected(data: AliasData, newDesc: string, histDesc: string): boolean {
  return data.rejected[rejectionKey(newDesc, histDesc)] === true;
}

/** Confirms a match: records PN/description aliases + canonical item. Returns the canonical id. */
export function confirmMatch(data: AliasData, match: ItemMatch): string {
  const canonicalId = makeCanonicalId(match.histPn, match.histDescription);

  for (const pn of [match.newPn, match.histPn]) {
    const pnNorm = normalizePn(pn);
    if (isValidPn(pnNorm)) data.pn_aliases[pnNorm] = canonicalId;
  }
  for (const desc of [match.newDescription, match.histDescription]) {
    const descNorm = normalizeDesc(desc);
    if (descNorm) data.desc_aliases[descNorm] = canonicalId;
  }

  const existing = data.canonical_items[canonicalId];
  if (!existing) {
    const pns = Array.from(new Set([match.newPn, match.histPn].filter(Boolean)));
    const descs = Array.from(new Set([match.newDescription, match.histDescription].filter(Boolean)));
    data.canonical_items[canonicalId] = {
      canonical_id: canonicalId,
      primary_pn: match.histPn || match.newPn,
      primary_description: match.histDescription || match.newDescription,
      all_pns: pns,
      all_descriptions: descs,
    };
  } else {
    for (const pn of [match.newPn, match.histPn]) {
      if (pn && existing.all_pns.indexOf(pn) === -1) existing.all_pns.push(pn);
    }
    for (const desc of [match.newDescription, match.histDescription]) {
      if (desc && existing.all_descriptions.indexOf(desc) === -1) existing.all_descriptions.push(desc);
    }
  }

  saveAliases(data);
  return canonicalId;
}

/** Rejects a match so the same suggestion is not proposed again. */
export function rejectMatch(data: AliasData, match: ItemMatch): void {
  data.rejected[rejectionKey(match.newDescription, match.histDescription)] = true;
  saveAliases(data);
}

export function aliasStats(data: AliasData): { pn: number; desc: number; canonical: number } {
  return {
    pn: Object.keys(data.pn_aliases).length,
    desc: Object.keys(data.desc_aliases).length,
    canonical: Object.keys(data.canonical_items).length,
  };
}

// ── resolution ────────────────────────────────────────────────────────────────
function makeMatch(
  n: ResolverItem,
  h: Partial<ResolverItem>,
  method: MatchMethod,
  confidence: number,
  status: MatchStatus,
  canonicalId?: string
): ItemMatch {
  return {
    newPn: n.pn,
    newDescription: n.description,
    newOppId: n.oppId,
    newUnitPrice: n.unitPrice,
    newPricingModel: n.pricingModel,
    histPn: h.pn || '',
    histDescription: h.description || '',
    histOppId: h.oppId || '',
    histUnitPrice: h.unitPrice || 0,
    histPricingModel: h.pricingModel || '',
    method,
    confidence,
    status,
    canonicalId,
  };
}

/**
 * Resolves the items of a BID against the historical items (all other BIDs).
 * Ported from ItemResolver.resolve_new_ctr (embedding path replaced by fuzzy).
 *
 * `autoConfirmDescExact` — when false (default), an identical description is
 * treated as a *suggestion* (pending) rather than confirmed identity. A shared
 * description is only "semantic value, NOT identity" (per the Python author's
 * own comment), so it should be reviewed unless the caller opts in.
 */
export function resolveBid(
  allCost: ResolverItem[],
  oppId: string,
  threshold: number,
  aliases: AliasData,
  autoConfirmDescExact = false
): ItemMatch[] {
  const matches: ItemMatch[] = [];
  const newItems = allCost.filter((c) => c.oppId === oppId);
  const hist = allCost.filter((c) => c.oppId !== oppId);
  if (!newItems.length || !hist.length) return matches;

  for (const item of newItems) {
    const pnNorm = isValidPn(item._pnNorm) ? item._pnNorm : '';
    const descNorm = item._descNorm;

    // 1. Existing alias (auto-confirmed)
    const cachedCid = aliases.desc_aliases[descNorm];
    if (cachedCid && aliases.canonical_items[cachedCid]) {
      const canonical = aliases.canonical_items[cachedCid];
      matches.push(
        makeMatch(
          item,
          { pn: canonical.primary_pn, description: canonical.primary_description, oppId: '(alias)' },
          'alias',
          1.0,
          'confirmed',
          cachedCid
        )
      );
      continue;
    }

    // 2. Exact PN match (auto-confirmed)
    if (pnNorm) {
      const pnHits = hist.filter((h) => h._pnNorm === pnNorm);
      if (pnHits.length) {
        matches.push(makeMatch(item, pnHits[pnHits.length - 1], 'pn_exact', 1.0, 'confirmed'));
        continue;
      }
    }

    // 3. Exact description match — semantic value, not proven identity.
    //    Auto-confirm only if the caller explicitly opts in; otherwise review.
    if (descNorm) {
      const exact = hist.filter((h) => h._descNorm === descNorm);
      if (exact.length) {
        const h = exact[exact.length - 1];
        if (autoConfirmDescExact) {
          matches.push(makeMatch(item, h, 'desc_exact', 1.0, 'confirmed'));
          continue;
        }
        if (!isRejected(aliases, item.description, h.description)) {
          matches.push(makeMatch(item, h, 'desc_exact', 1.0, 'pending'));
        }
        continue;
      }
    }

    // 4. Best fuzzy description match → pending
    let bestScore = 0;
    let bestIdx = -1;
    for (let i = 0; i < hist.length; i++) {
      const score = tokenSortRatio(descNorm, hist[i]._descNorm);
      if (score > bestScore) {
        bestScore = score;
        bestIdx = i;
      }
    }
    if (bestIdx >= 0 && bestScore >= threshold) {
      const h = hist[bestIdx];
      if (!isRejected(aliases, item.description, h.description)) {
        matches.push(makeMatch(item, h, 'fuzzy_desc', bestScore, 'pending'));
      }
    }
  }

  // Drop suggestions where both PNs are valid but different (definitely not the
  // same physical item) — keeps pn_exact and description-based suggestions.
  return matches.filter((m) => {
    const a = normalizePn(m.newPn);
    const b = normalizePn(m.histPn);
    if (isValidPn(a) && isValidPn(b) && a !== b) return false;
    return true;
  });
}
