/**
 * Price Benchmark logic — TypeScript port of `_price_benchmark_page.py`.
 *
 * Pure, framework-agnostic helpers used by the Price Benchmark page:
 *   - Type classification (MAIN PRICE / ACCESSORY / ZERO PRICE)
 *   - Parent/child hierarchy (accessories indented under their equipment line)
 *   - Cross-bid full-cost history (equipment + accessories)
 *   - Client term -> offered models mapping (persisted in localStorage)
 *
 * Type table (type_raw):
 *   MAIN PRICE : purchase(cap), consum.(ope), call out, afe global, day rate(ope), rental(ope)
 *   ZERO PRICE : in house, onboard, not offered
 *   ACCESSORY  : certif.(cap/ope), transit(ope), logistics(ope), maint.(ope/cap), mobiliz.(ope), update(ope)
 */

// ─────────────────────────────────────────────────────────────────────────────
// Type classification
// ─────────────────────────────────────────────────────────────────────────────

export const ZERO_TYPES: ReadonlySet<string> = new Set([
  'in house', 'in-house', 'inhouse',
  'onboard', 'on board',
  'not offered',
]);

export const ACCESSORY_KEYWORDS: readonly string[] = [
  'certif', 'transit', 'logistics', 'mobiliz', 'maint', 'update',
];

export const CAPEX_KEYWORDS: readonly string[] = [
  'purchase', 'consum', 'call out', 'afe global',
];

export const OPEX_KEYWORDS: readonly string[] = ['rental', 'day rate'];

export interface AccessoryTag {
  label: string;
  color: string;
}

const ACCESSORY_TAGS: ReadonlyArray<{ key: string; tag: AccessoryTag }> = [
  { key: 'certif', tag: { label: 'Certif.', color: '#ffc72c' } },
  { key: 'transit', tag: { label: 'Transit', color: '#0097a9' } },
  { key: 'logistics', tag: { label: 'Logistics', color: '#0097a9' } },
  { key: 'mobiliz', tag: { label: 'Mobiliz.', color: '#534AB7' } },
  { key: 'maint', tag: { label: 'Maint.', color: '#EF9F27' } },
  { key: 'update', tag: { label: 'Update', color: '#EF9F27' } },
];

export function normalizeType(t: unknown): string {
  if (t === null || t === undefined) return '';
  return String(t).trim().toLowerCase();
}

export function isZeroType(t: unknown): boolean {
  return ZERO_TYPES.has(normalizeType(t));
}

export function isAccessory(t: unknown): boolean {
  const n = normalizeType(t);
  if (ZERO_TYPES.has(n)) return false;
  return ACCESSORY_KEYWORDS.some((k) => n.indexOf(k) !== -1);
}

export function isMainType(t: unknown): boolean {
  if (isZeroType(t) || isAccessory(t)) return false;
  return true;
}

export function classifyType(t: unknown): 'ZERO PRICE' | 'ACCESSORY' | 'MAIN PRICE' {
  if (isZeroType(t)) return 'ZERO PRICE';
  if (isAccessory(t)) return 'ACCESSORY';
  return 'MAIN PRICE';
}

export function getAccessoryTag(t: unknown): AccessoryTag {
  const n = normalizeType(t);
  for (const { key, tag } of ACCESSORY_TAGS) {
    if (n.indexOf(key) !== -1) return tag;
  }
  return { label: 'Extra', color: '#7a99ac' };
}

export function isCapex(t: unknown): boolean {
  const n = normalizeType(t);
  return CAPEX_KEYWORDS.some((k) => n.indexOf(k) !== -1);
}

export function isOpex(t: unknown): boolean {
  const n = normalizeType(t);
  return OPEX_KEYWORDS.some((k) => n.indexOf(k) !== -1);
}

// ─────────────────────────────────────────────────────────────────────────────
// Row normalization
// ─────────────────────────────────────────────────────────────────────────────

export interface BenchItem {
  index: number; // preserves original workbook order
  oppId: string;
  description: string;
  pn: string;
  typeRaw: string;
  category: string;
  group: string;
  /** ET Text = the requirement label (e.g. "MBES Head") linking alternative modalities. */
  etText: string;
  premisses: string;
  currency: string;
  quantity: number;
  unitPrice: number; // raw / display price
  unitPriceFin: number; // 0 for zero-cost and accessory lines
  typeClass: 'ZERO PRICE' | 'ACCESSORY' | 'MAIN PRICE';
}

export interface OppInfo {
  oppId: string;
  project: string;
}

export interface LaborRow {
  function: string;
  type: string;
  phase: string;
  hh_per_day: number | null;
  people_qty: number | null;
  days: number | null;
  utilization: number | null;
  total_hh: number | null;
  cost_rate: number | null;
  currency_original: string;
  oppId: string;
}

function pick(row: Record<string, unknown>, keys: string[]): unknown {
  for (const k of keys) {
    if (row[k] !== undefined && row[k] !== null && row[k] !== '') return row[k];
  }
  return undefined;
}

export function toNumber(v: unknown, fallback = 0): number {
  if (v === null || v === undefined || v === '') return fallback;
  if (typeof v === 'number') return Number.isFinite(v) ? v : fallback;
  const cleaned = String(v).replace(/[^0-9.+-]/g, '');
  const n = parseFloat(cleaned);
  return Number.isFinite(n) ? n : fallback;
}

function toStr(v: unknown, fallback = ''): string {
  if (v === null || v === undefined) return fallback;
  const s = String(v).trim();
  return s === 'nan' ? fallback : s;
}

/**
 * Canonical text key used for case-insensitive comparisons across the app.
 * - trims
 * - lowercases
 * - collapses repeated whitespace
 */
export function normalizeTextKey(v: unknown): string {
  return String(v ?? '')
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ');
}

/** Normalizes raw Cost_Element rows into BenchItem[], preserving row order. */
export function normalizeCostRows(rows: Array<Record<string, unknown>>): BenchItem[] {
  return rows.map((row, index) => {
    const typeRaw = toStr(pick(row, ['type_raw', 'pricing_model', 'type']));
    const quantity = toNumber(pick(row, ['quantity', 'qty']), 1) || 1;
    const unitPrice = toNumber(pick(row, ['unit_price', 'unit_price_median', 'unit_price_display', 'unitPrice']));
    const typeClass = classifyType(typeRaw);
    const unitPriceFin = typeClass === 'MAIN PRICE' ? unitPrice : 0;
    return {
      index,
      oppId: toStr(pick(row, ['opportunity_id', 'opportunityId', 'bid'])),
      description: toStr(pick(row, ['description', 'desc'])),
      pn: toStr(pick(row, ['pn', 'part_number'])),
      typeRaw,
      category: toStr(pick(row, ['category_final', 'category'])),
      group: toStr(pick(row, ['group'])),
      etText: toStr(pick(row, ['et_text', 'et', 'requirement'])),
      premisses: toStr(pick(row, ['premisses', 'premises', 'premise'])),
      currency: toStr(pick(row, ['currency', 'currency_original']), 'USD'),
      quantity,
      unitPrice,
      unitPriceFin,
      typeClass,
    };
  });
}

export function normalizeOpportunities(rows: Array<Record<string, unknown>>): OppInfo[] {
  return rows.map((row) => ({
    oppId: toStr(pick(row, ['opportunity_id', 'opportunityId'])),
    project: toStr(pick(row, ['project', 'title', 'name'])),
  }));
}

export function buildOppTitleMap(opps: OppInfo[]): Map<string, string> {
  const m = new Map<string, string>();
  opps.forEach((o) => m.set(o.oppId, o.project));
  return m;
}

export function normalizeLaborRows(rows: Array<Record<string, unknown>>): LaborRow[] {
  return rows.map((row) => ({
    function: toStr(pick(row, ['function', 'role'])),
    type: toStr(pick(row, ['type'])),
    phase: toStr(pick(row, ['phase'])),
    hh_per_day: pick(row, ['hh_per_day']) === undefined ? null : toNumber(pick(row, ['hh_per_day'])),
    people_qty: pick(row, ['people_qty']) === undefined ? null : toNumber(pick(row, ['people_qty'])),
    days: pick(row, ['days']) === undefined ? null : toNumber(pick(row, ['days'])),
    utilization: pick(row, ['utilization']) === undefined ? null : toNumber(pick(row, ['utilization'])),
    total_hh: pick(row, ['total_hh']) === undefined ? null : toNumber(pick(row, ['total_hh'])),
    cost_rate: pick(row, ['cost_rate']) === undefined ? null : toNumber(pick(row, ['cost_rate'])),
    currency_original: toStr(pick(row, ['currency_original', 'currency'])),
    oppId: toStr(pick(row, ['opportunity_id', 'opportunityId'])),
  }));
}

// ─────────────────────────────────────────────────────────────────────────────
// Hierarchy (accessories grouped under their equipment line)
// ─────────────────────────────────────────────────────────────────────────────

export interface HierarchyNode {
  row: BenchItem;
  children: BenchItem[];
}

export function buildHierarchy(items: BenchItem[]): HierarchyNode[] {
  const out: HierarchyNode[] = [];
  let current: HierarchyNode | undefined;
  for (const row of items) {
    if (isAccessory(row.typeRaw)) {
      if (current) {
        current.children.push(row);
      } else {
        out.push({ row, children: [] });
      }
    } else {
      current = { row, children: [] };
      out.push(current);
    }
  }
  return out;
}

// ─────────────────────────────────────────────────────────────────────────────
// Search
// ─────────────────────────────────────────────────────────────────────────────

export function searchByWords(items: BenchItem[], query: string): BenchItem[] {
  const q = normalizeTextKey(query);
  if (!q) return items;
  const words = q.split(/\s+/).filter(Boolean);
  if (words.length === 0) return items;
  return items.filter((it) => {
    const desc = normalizeTextKey(it.description);
    const pn = normalizeTextKey(it.pn);
    return words.every((w) => desc.indexOf(w) !== -1 || pn.indexOf(w) !== -1);
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// String similarity (difflib.SequenceMatcher stand-in via bigram Dice coeff.)
// ─────────────────────────────────────────────────────────────────────────────

function bigrams(s: string): Map<string, number> {
  const m = new Map<string, number>();
  for (let i = 0; i < s.length - 1; i++) {
    const bg = s.substr(i, 2);
    m.set(bg, (m.get(bg) || 0) + 1);
  }
  return m;
}

export function similarityRatio(a: string, b: string): number {
  const s1 = normalizeTextKey(a);
  const s2 = normalizeTextKey(b);
  if (!s1 && !s2) return 1;
  if (!s1 || !s2) return 0;
  if (s1 === s2) return 1;
  if (s1.length < 2 || s2.length < 2) return s1 === s2 ? 1 : 0;
  const bg1 = bigrams(s1);
  const bg2 = bigrams(s2);
  let intersection = 0;
  bg1.forEach((count, bg) => {
    const other = bg2.get(bg);
    if (other) intersection += Math.min(count, other);
  });
  const total = s1.length - 1 + (s2.length - 1);
  return (2 * intersection) / total;
}

function scoreDescription(query: string, other: string): number {
  const q = normalizeTextKey(query);
  let score = similarityRatio(q, other);
  const words = q.split(/\s+/).filter((w) => w.length > 2);
  if (words.length) {
    const lower = normalizeTextKey(other);
    // Whole-word match (not substring) so e.g. "FRAME" does not falsely match
    // "AFRAME", which previously pulled unrelated items into the same group.
    const hits = words.filter((w) => {
      const escaped = w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      return new RegExp(`\\b${escaped}\\b`).test(lower);
    }).length;
    score = Math.min(score + (hits / words.length) * 0.3, 1.0);
  }
  return score;
}

const INVALID_PNS: ReadonlySet<string> = new Set(['', '—', 'n/a', 'tbd', 'na', 'none', 'nan']);

export function isValidPn(pn: string): boolean {
  return !INVALID_PNS.has(normalizeTextKey(pn));
}

// ─────────────────────────────────────────────────────────────────────────────
// Full cost history (equipment + accessories) across bids
// ─────────────────────────────────────────────────────────────────────────────

export interface AccessoryCost {
  typeRaw: string;
  description: string;
  unitPrice: number;
  tag: AccessoryTag;
}

export interface FullCostRecord {
  oppId: string;
  mainPrice: number;
  typeRaw: string;
  description: string;
  accessories: AccessoryCost[];
  totalFullCost: number;
  nAccessories: number;
  totalAccessoriesCost: number;
}

/** Collects the accessory lines that follow `pos` until the next non-accessory. */
function collectAccessories(items: BenchItem[], pos: number): AccessoryCost[] {
  const acc: AccessoryCost[] = [];
  for (let j = pos + 1; j < items.length; j++) {
    const next = items[j];
    if (isAccessory(next.typeRaw)) {
      acc.push({
        typeRaw: next.typeRaw,
        description: next.description,
        unitPrice: next.unitPrice,
        tag: getAccessoryTag(next.typeRaw),
      });
    } else {
      break;
    }
  }
  return acc;
}

export function getFullCostHistory(
  all: BenchItem[],
  pn: string,
  description: string,
  currentOpp: string,
  useDescription: boolean,
  etText = '',
  threshold = 0.65
): FullCostRecord[] {
  const results: FullCostRecord[] = [];
  const byOpp = new Map<string, BenchItem[]>();
  for (const it of all) {
    if (it.oppId === currentOpp) continue;
    const arr = byOpp.get(it.oppId);
    if (arr) arr.push(it);
    else byOpp.set(it.oppId, [it]);
  }

  const pnUpper = (pn || '').trim().toUpperCase();
  const etKey = normalizeTextKey(etText);

  byOpp.forEach((oppItems, oppId) => {
    const matchPositions: number[] = [];
    if (etKey) {
      // Reliable requirement-level match by ET Text: take EVERY main-line
      // modality (in-house, day rate, …) that shares the requirement label.
      oppItems.forEach((it, i) => {
        if (!isAccessory(it.typeRaw) && normalizeTextKey(it.etText) === etKey) {
          matchPositions.push(i);
        }
      });
    } else if (!useDescription && isValidPn(pn)) {
      oppItems.forEach((it, i) => {
        if (it.pn.trim().toUpperCase() === pnUpper) matchPositions.push(i);
      });
    } else {
      let bestPos = -1;
      let bestScore = 0;
      oppItems.forEach((it, i) => {
        if (!it.description) return;
        const score = scoreDescription(description, it.description);
        if (score > bestScore && score >= threshold) {
          bestScore = score;
          bestPos = i;
        }
      });
      if (bestPos >= 0) matchPositions.push(bestPos);
    }

    for (const pos of matchPositions) {
      const match = oppItems[pos];
      const mainPrice = match.unitPrice;
      const accessories = collectAccessories(oppItems, pos);
      const totalAccessoriesCost = accessories.reduce((s, a) => s + a.unitPrice, 0);
      results.push({
        oppId,
        mainPrice,
        typeRaw: match.typeRaw,
        description: match.description,
        accessories,
        totalFullCost: mainPrice + totalAccessoriesCost,
        nAccessories: accessories.length,
        totalAccessoriesCost,
      });
    }
  });

  return results;
}

// ─────────────────────────────────────────────────────────────────────────────
// Acquisition-type breakdown (how the item was offered across bids)
// ─────────────────────────────────────────────────────────────────────────────

export interface AcquisitionTypeStat {
  /** Normalized acquisition type as offered (e.g. "purchase", "in house"). */
  type: string;
  typeClass: 'ZERO PRICE' | 'ACCESSORY' | 'MAIN PRICE';
  count: number;
  /** Share of all matched occurrences, 0..100. */
  pct: number;
  color: string;
}

/** Stable color per acquisition type so the chart legend is consistent. */
export function acquisitionColor(typeRaw: unknown): string {
  const n = normalizeType(typeRaw);
  // Zero-price types must each be distinct (in house ≠ onboard ≠ not offered).
  if (n.indexOf('not offered') !== -1) return '#E24B4A'; // red — we did NOT offer it
  if (n.indexOf('onboard') !== -1 || n.indexOf('on board') !== -1) return '#925E9B'; // mauve
  if (n.indexOf('in house') !== -1 || n.indexOf('in-house') !== -1 || n.indexOf('inhouse') !== -1) return '#009b77'; // green
  if (n.indexOf('purchase') !== -1) return '#ffc72c'; // gold
  if (n.indexOf('rental') !== -1 || n.indexOf('day rate') !== -1) return '#0097a9'; // teal
  if (n.indexOf('call out') !== -1) return '#5b7f95'; // steel
  if (n.indexOf('afe global') !== -1) return '#534AB7'; // indigo
  if (n.indexOf('consum') !== -1) return '#EF9F27'; // orange
  return '#8a9aa5'; // muted gray fallback
}

/**
 * Counts, across ALL bids, how many times a given item was offered under each
 * acquisition type (purchase, in house, rental, …). Matches by PN when a valid
 * PN is available, otherwise by description similarity (one best match per bid).
 * Accessory lines are excluded — they are not acquisition types.
 */
export function getAcquisitionBreakdown(
  all: BenchItem[],
  pn: string,
  description: string,
  useDescription: boolean,
  etText = '',
  threshold = 0.65
): AcquisitionTypeStat[] {
  const byOpp = new Map<string, BenchItem[]>();
  for (const it of all) {
    const arr = byOpp.get(it.oppId);
    if (arr) arr.push(it);
    else byOpp.set(it.oppId, [it]);
  }

  const pnUpper = (pn || '').trim().toUpperCase();
  const etKey = normalizeTextKey(etText);
  const matches: BenchItem[] = [];

  byOpp.forEach((oppItems) => {
    if (etKey) {
      // Requirement-level match by ET Text: count each distinct acquisition
      // type once per bid (in-house, day rate, call out, …).
      const seen = new Set<string>();
      oppItems.forEach((it) => {
        if (!isAccessory(it.typeRaw) && normalizeTextKey(it.etText) === etKey) {
          const key = normalizeType(it.typeRaw);
          if (!seen.has(key)) {
            seen.add(key);
            matches.push(it);
          }
        }
      });
    } else if (!useDescription && isValidPn(pn)) {
      // Count each distinct acquisition type at most once per bid, so a bid
      // that offers the same item both in-house and as a rental shows BOTH.
      const seen = new Set<string>();
      oppItems.forEach((it) => {
        if (it.pn.trim().toUpperCase() === pnUpper && !isAccessory(it.typeRaw)) {
          const key = normalizeType(it.typeRaw);
          if (!seen.has(key)) {
            seen.add(key);
            matches.push(it);
          }
        }
      });
    } else {
      // Description-only fallback (no PN, no ET): keep ONE best match per bid
      // to avoid inflating the donut with weak/ambiguous matches.
      let best: { score: number; item: BenchItem } | undefined;
      oppItems.forEach((it) => {
        if (!it.description || isAccessory(it.typeRaw)) return;
        const score = scoreDescription(description, it.description);
        if (score >= threshold) {
          if (!best || score > best.score) best = { score, item: it };
        }
      });
      if (best) matches.push(best.item);
    }
  });

  if (matches.length === 0) return [];

  const counts = new Map<string, { count: number; cls: 'ZERO PRICE' | 'ACCESSORY' | 'MAIN PRICE' }>();
  for (const m of matches) {
    const key = normalizeType(m.typeRaw) || '(unspecified)';
    const prev = counts.get(key);
    if (prev) prev.count += 1;
    else counts.set(key, { count: 1, cls: classifyType(m.typeRaw) });
  }

  const total = matches.length;
  return Array.from(counts.entries())
    .map(([type, { count, cls }]) => ({
      type,
      typeClass: cls,
      count,
      pct: (count / total) * 100,
      color: acquisitionColor(type),
    }))
    .sort((a, b) => b.count - a.count);
}

// ─────────────────────────────────────────────────────────────────────────────
// Multiple acquisition modalities for the same requirement (within one bid)
//
// Detects when a bid offers the SAME requirement under more than one
// acquisition type — e.g. an in-house MBES head (maintenance-only cost) vs. a
// rented R2Sonic "as MBES head" (day rate). Lines are grouped primarily by the
// ET Text field (the requirement label, e.g. "MBES Head"), falling back to
// shared significant description tokens when ET Text is empty.
// ─────────────────────────────────────────────────────────────────────────────

export interface AcquisitionOption {
  index: number;
  et: string;
  typeRaw: string;
  typeClass: 'ZERO PRICE' | 'ACCESSORY' | 'MAIN PRICE';
  color: string;
  description: string;
  pn: string;
  unitPrice: number;
  quantity: number;
  mainCost: number;
  accessoriesCost: number;
  total: number;
  isRental: boolean;
  isOwn: boolean;
}

export interface RequirementOptions {
  label: string;
  sharedTokens: string[];
  options: AcquisitionOption[];
  ownTotal?: number;
  rentTotal?: number;
  rentDayRate?: number;
  savings?: number;
  cheaper?: 'own' | 'rent';
  breakEvenDays?: number;
}

/** Generic / structural words that must not, on their own, link two lines. */
const OPTION_STOP_TOKENS: ReadonlySet<string> = new Set([
  'como', 'com', 'and', 'the', 'for', 'with', 'from', 'system', 'unit', 'units',
  'subsea', 'spread', 'full', 'set', 'kit', 'type', 'model', 'series', 'offshore',
  'onshore', 'project', 'house', 'inhouse', 'rate', 'day', 'rental', 'purchase',
  'onboard', 'each', 'per',
]);

function optionTokens(desc: string): Set<string> {
  const out = new Set<string>();
  for (const t of normalizeTextKey(desc).split(/[^a-z0-9]+/)) {
    if (t.length >= 3 && !OPTION_STOP_TOKENS.has(t)) out.add(t);
  }
  return out;
}

export function detectAcquisitionOptions(bidItems: BenchItem[]): RequirementOptions[] {
  const nodes = buildHierarchy(bidItems).filter((n) => !isAccessory(n.row.typeRaw));

  const opts: AcquisitionOption[] = nodes.map((n) => {
    const row = n.row;
    const mainCost = isZeroType(row.typeRaw) ? 0 : row.unitPrice * (row.quantity || 1);
    const accessoriesCost = n.children.reduce((s, c) => s + c.unitPrice * (c.quantity || 1), 0);
    const t = normalizeType(row.typeRaw);
    return {
      index: row.index,
      et: row.etText,
      typeRaw: row.typeRaw,
      typeClass: classifyType(row.typeRaw),
      color: acquisitionColor(row.typeRaw),
      description: row.description,
      pn: row.pn,
      unitPrice: row.unitPrice,
      quantity: row.quantity || 1,
      mainCost,
      accessoriesCost,
      total: mainCost + accessoriesCost,
      isRental: isOpex(row.typeRaw) || t.indexOf('day rate') !== -1 || t.indexOf('rental') !== -1,
      isOwn: isZeroType(row.typeRaw) || t.indexOf('purchase') !== -1,
    };
  });

  const tokenSets = opts.map((o) => optionTokens(o.description));

  // Builds a RequirementOptions from a set of option indices, or undefined when
  // it isn't a genuine multi-modality requirement (needs >= 2 distinct types).
  const buildGroup = (idxs: number[], forcedLabel?: string): RequirementOptions | undefined => {
    if (idxs.length < 2) return undefined;
    const groupOpts = idxs.map((i) => opts[i]);
    const distinctTypes = new Set(groupOpts.map((o) => normalizeType(o.typeRaw)));
    if (distinctTypes.size < 2) return undefined;

    let label = (forcedLabel || '').trim();
    let sharedTokens: string[] = [];
    if (!label) {
      let shared: Set<string> | undefined;
      idxs.forEach((i) => {
        if (!shared) shared = new Set(tokenSets[i]);
        else shared = new Set(Array.from(shared).filter((t) => tokenSets[i].has(t)));
      });
      sharedTokens = shared ? Array.from(shared) : [];
      label = sharedTokens.length
        ? sharedTokens.map((t) => t.charAt(0).toUpperCase() + t.slice(1)).join(' ')
        : groupOpts[0].description;
    }

    const sorted = groupOpts.slice().sort((a, b) => b.total - a.total);
    const own = sorted.filter((o) => o.isOwn && !o.isRental)[0];
    const rent = sorted.filter((o) => o.isRental)[0];

    const ro: RequirementOptions = { label, sharedTokens, options: sorted };
    if (own && rent) {
      ro.ownTotal = own.total;
      ro.rentTotal = rent.total;
      ro.rentDayRate = rent.unitPrice > 0 ? rent.unitPrice : undefined;
      ro.savings = Math.abs(rent.total - own.total);
      ro.cheaper = own.total <= rent.total ? 'own' : 'rent';
      if (ro.rentDayRate && ro.rentDayRate > 0) ro.breakEvenDays = own.total / ro.rentDayRate;
    }
    return ro;
  };

  const result: RequirementOptions[] = [];

  // 1) Primary grouping by ET Text — the requirement column ("MBES Head") that
  //    reliably links alternative modalities of the same requirement.
  const byEt = new Map<string, number[]>();
  const noEt: number[] = [];
  opts.forEach((o, i) => {
    const key = normalizeTextKey(o.et);
    if (key) {
      const arr = byEt.get(key);
      if (arr) arr.push(i);
      else byEt.set(key, [i]);
    } else {
      noEt.push(i);
    }
  });
  byEt.forEach((idxs) => {
    const ro = buildGroup(idxs, opts[idxs[0]].et);
    if (ro) result.push(ro);
  });

  // 2) Fallback: shared-token clustering for lines without ET Text.
  if (noEt.length > 1) {
    const parent = noEt.map((_, k) => k);
    const find = (x: number): number => {
      let r = x;
      while (parent[r] !== r) {
        parent[r] = parent[parent[r]];
        r = parent[r];
      }
      return r;
    };
    const union = (a: number, b: number): void => {
      parent[find(a)] = find(b);
    };
    for (let a = 0; a < noEt.length; a++) {
      for (let b = a + 1; b < noEt.length; b++) {
        let shared = 0;
        tokenSets[noEt[a]].forEach((t) => {
          if (tokenSets[noEt[b]].has(t)) shared++;
        });
        if (shared >= 2) union(a, b);
      }
    }
    const clusters = new Map<number, number[]>();
    noEt.forEach((_, k) => {
      const r = find(k);
      const arr = clusters.get(r);
      if (arr) arr.push(noEt[k]);
      else clusters.set(r, [noEt[k]]);
    });
    clusters.forEach((idxs) => {
      const ro = buildGroup(idxs);
      if (ro) result.push(ro);
    });
  }

  return result.sort(
    (a, b) => Math.max(...b.options.map((o) => o.total)) - Math.max(...a.options.map((o) => o.total))
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Client term -> offered models mapping (localStorage-backed)
// ─────────────────────────────────────────────────────────────────────────────

export interface EquipmentMapping {
  client_term: string;
  keywords: string[];
  our_models: string[];
  notes?: string;
}

const MAPPING_STORAGE_KEY = 'easi.equipmentMappings.v1';

const DEFAULT_MAPPINGS: EquipmentMapping[] = [
  {
    client_term: 'GNSS',
    keywords: ['gnss', 'c-nav', 'cnav', 'gps compass'],
    our_models: ['Hemisphere GNSS VS101 GPS Compass', 'C-NavX1\u2122 GNSS Receiver', 'C-NavX3\u2122 GNSS Receiver'],
    notes:
      'GNSS - Global Navigation System. Serve para determinar posi\u00e7\u00e3o, navega\u00e7\u00e3o e tempo, ' +
      'principalmente em ambientes offshore. Enquanto um GPS comum erra alguns METROS, o C-Nav pode chegar ' +
      'a uma precis\u00e3o centim\u00e9trica.',
  },
];

export function loadMappings(): EquipmentMapping[] {
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(MAPPING_STORAGE_KEY) : null;
    if (!raw) return DEFAULT_MAPPINGS.slice();
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed.mappings)) return parsed.mappings as EquipmentMapping[];
    if (Array.isArray(parsed)) return parsed as EquipmentMapping[];
    return DEFAULT_MAPPINGS.slice();
  } catch {
    return DEFAULT_MAPPINGS.slice();
  }
}

export function saveMappings(mappings: EquipmentMapping[]): void {
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(MAPPING_STORAGE_KEY, JSON.stringify({ mappings }));
    }
  } catch {
    /* ignore quota / privacy-mode errors */
  }
}

export function findMapping(query: string, mappings: EquipmentMapping[]): EquipmentMapping | undefined {
  const q = (query || '').trim().toLowerCase();
  if (!q) return undefined;
  for (const m of mappings) {
    if ((m.keywords || []).some((kw) => q.indexOf(kw) !== -1 || kw.indexOf(q) !== -1)) return m;
    if ((m.client_term || '').toLowerCase() && q.indexOf(m.client_term.toLowerCase()) !== -1) return m;
  }
  return undefined;
}

export interface ModelHistoryRow {
  matchedModel: string;
  item: BenchItem;
}

export function getModelHistory(items: BenchItem[], modelNames: string[]): ModelHistoryRow[] {
  const out: ModelHistoryRow[] = [];
  for (const model of modelNames) {
    const words = model.split(/\s+/).map((w) => w.trim().toLowerCase()).filter((w) => w.length > 2);
    if (!words.length) continue;
    for (const it of items) {
      if (!isMainType(it.typeRaw) || it.unitPrice <= 0) continue;
      const desc = it.description.toLowerCase();
      if (words.every((w) => desc.indexOf(w) !== -1)) {
        out.push({ matchedModel: model, item: it });
      }
    }
  }
  return out;
}

// ─────────────────────────────────────────────────────────────────────────────
// Numeric helpers
// ─────────────────────────────────────────────────────────────────────────────

export function median(values: number[]): number | null {
  if (!values.length) return null;
  const s = [...values].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}

export function mean(values: number[]): number | null {
  if (!values.length) return null;
  return values.reduce((a, b) => a + b, 0) / values.length;
}

export function fmtUsd(v: number | null | undefined): string {
  if (v === null || v === undefined || !Number.isFinite(v)) return '—';
  return '$' + Math.round(v).toLocaleString('en-US');
}

export function fmtNum(v: number | null | undefined, digits = 0): string {
  if (v === null || v === undefined || !Number.isFinite(v)) return '—';
  return v.toLocaleString('en-US', { minimumFractionDigits: digits, maximumFractionDigits: digits });
}
