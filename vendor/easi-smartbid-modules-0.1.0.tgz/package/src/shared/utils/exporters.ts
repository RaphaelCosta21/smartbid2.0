import * as XLSX from 'xlsx';

/** A row is a flat record of column name -> primitive value. */
export type ExportRow = Record<string, string | number | boolean | null | undefined>;

function withTimestamp(name: string, ext: string): string {
  const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
  const base = name.replace(/\.(csv|xlsx)$/i, '');
  return `${base}_${stamp}.${ext}`;
}

function triggerDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  // Revoke on the next tick so the download has time to start.
  window.setTimeout(() => URL.revokeObjectURL(url), 0);
}

/** Export rows as an .xlsx workbook using the bundled SheetJS library. */
export function exportToXlsx(
  rows: ExportRow[],
  filename: string,
  sheetName = 'Sheet1'
): void {
  const worksheet = XLSX.utils.json_to_sheet(rows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, sheetName.slice(0, 31));
  XLSX.writeFile(workbook, withTimestamp(filename, 'xlsx'));
}

/** Export rows as a UTF-8 CSV file (Excel-friendly, with BOM). */
export function exportToCsv(rows: ExportRow[], filename: string): void {
  const worksheet = XLSX.utils.json_to_sheet(rows);
  const csv = XLSX.utils.sheet_to_csv(worksheet);
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  triggerDownload(blob, withTimestamp(filename, 'csv'));
}
