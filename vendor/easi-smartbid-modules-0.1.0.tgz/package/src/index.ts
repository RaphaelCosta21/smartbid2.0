/**
 * @easi/smartbid-modules — entrypoint público.
 *
 * Importe:
 *   import { Suppliers, BidComparator, BidPresentation, PriceHistory } from '@easi/smartbid-modules';
 *   import { configureSmartBidModules, MockAdapter } from '@easi/smartbid-modules/adapters';
 *   // ou:
 *   import { configureSmartBidModules, MockAdapter } from '@easi/smartbid-modules';
 */

// ── Módulos (componentes React) ──────────────────────────────────────────────
export { Suppliers } from './modules/suppliers';
export { BidComparator } from './modules/bid-comparator';
export { BidPresentation } from './modules/bid-presentation';
export { PriceHistory } from './modules/price-history';

// ── Adapter (bootstrap) ──────────────────────────────────────────────────────
export {
  configureSmartBidModules,
  getSmartBidAdapter,
  ApiClient,
} from './adapters/ApiClient';
export type { SmartBidDataAdapter, BenchmarkDataset } from './adapters/DataAdapter';
export { MockAdapter } from './adapters/MockAdapter';
export type { MockAdapterOptions } from './adapters/MockAdapter';

// ── UI primitives (podem ser úteis fora dos módulos) ─────────────────────────
export {
  Loading,
  Card,
  MetricCard,
  EmptyState,
  ErrorState,
  ToastProvider,
  useToast,
} from './shared/ui';
export type {
  ILoadingProps,
  ICardProps,
  IMetricCardProps,
  IEmptyStateProps,
  IErrorStateProps,
  ToastKind,
} from './shared/ui';

// ── Tipos de domínio ─────────────────────────────────────────────────────────
export type {
  CostElement,
  Opportunity,
  ClassificationResult,
  QuoteListItem,
} from './shared/types';

// ── Supplier store (seed / integração custom) ────────────────────────────────
// Útil para popular o catálogo de fornecedores programaticamente (playground,
// migração de dados, testes). O módulo Suppliers persiste em localStorage.
export {
  createSupplier,
  addQuotation,
  listSuppliers,
  newQuotationId,
  DEFAULT_CATEGORIES,
} from './shared/utils/supplierStore';
export type {
  Supplier,
  SupplierContact,
  Quotation,
} from './shared/utils/supplierStore';
