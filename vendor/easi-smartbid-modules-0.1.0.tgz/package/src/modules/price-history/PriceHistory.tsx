import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ApiClient } from '../../adapters/ApiClient';
import { Loading, useToast } from '../../shared/ui';
import { BTN_GHOST, BTN_ICON, BTN_LINK, BTN_PRIMARY, BTN_SMALL, TAB_ROW, chipCls, tabCls } from '../../shared/ui/buttonClasses';
import {
  AcquisitionTypeStat,
  acquisitionColor,
  BenchItem,
  OppInfo,
  LaborRow,
  normalizeTextKey,
  buildHierarchy,
  buildOppTitleMap,
  fmtNum,
  fmtUsd,
  getAcquisitionBreakdown,
  getFullCostHistory,
  getModelHistory,
  findMapping,
  isAccessory,
  isCapex,
  isMainType,
  isOpex,
  isValidPn,
  isZeroType,
  loadMappings,
  mean,
  median,
  normalizeCostRows,
  normalizeLaborRows,
  normalizeOpportunities,
  saveMappings,
  searchByWords,
  getAccessoryTag,
  EquipmentMapping,
} from '../../shared/utils/benchmark';
import { buildSupplyMap, computeMargin, pnKey, type SupplyInfo } from '../../shared/utils/aiSearch';

// ─────────────────────────────────────────────────────────────────────────────
// Shared styling tokens / small presentational helpers
// ─────────────────────────────────────────────────────────────────────────────

const INPUT_CLS =
  'w-full bg-surface border border-border rounded-none p-2.5 text-sm text-light placeholder-muted focus:border-steel outline-none';
const LABEL_CLS = 'block text-xs uppercase tracking-widest text-muted mb-1.5 font-mono';

const COLORS = {
  gold: '#ffc72c',
  teal: '#0097a9',
  steel: '#5b7f95',
  muted: '#5b7f95',
  green: '#009b77',
  red: '#E24B4A',
  light: '#0d2430',
};

const Field: React.FC<{ label: string; children: React.ReactNode }> = ({ label, children }) => (
  <div>
    <label className={LABEL_CLS}>{label}</label>
    {children}
  </div>
);

const SectionLabel: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="text-xs uppercase tracking-widest text-muted font-mono border-b border-border pb-1 mb-3">
    {children}
  </div>
);

// Container-based layout helpers. Tailwind's md:/lg: prefixes react to the
// viewport width, but this web part renders inside a narrow shell, so they
// cram columns and cause overflow. Inline auto-fit grids wrap by the actual
// container width instead, which fixes the cramming and clipping.
const autoGrid = (min: number): React.CSSProperties => ({
  display: 'grid',
  gap: '0.75rem',
  gridTemplateColumns: `repeat(auto-fit, minmax(${min}px, 1fr))`,
});

const tableGrid = (cols: string, minWidth: number): React.CSSProperties => ({
  display: 'grid',
  gridTemplateColumns: cols,
  gap: '0.5rem',
  minWidth,
});
const ACC_COLS = '2fr 1fr 1fr 1fr';
const ACC_MINW = 480;
const LABOR_COLS = '1.4fr 0.8fr 1fr 0.6fr 0.6fr 0.5fr 0.6fr 0.6fr 0.6fr 0.6fr 1fr';
const LABOR_MINW = 960;
// inlined so the card renders correctly regardless of CSS generation timing.
const StatGrid: React.FC<{ children: React.ReactNode; min?: number }> = ({ children, min = 150 }) => (
  <div style={autoGrid(min)}>{children}</div>
);

const Stat: React.FC<{ label: string; value: React.ReactNode; hint?: string; title?: string }> = ({
  label,
  value,
  hint,
  title,
}) => (
  <div
    className="rounded-none p-3 min-w-0"
    style={{
      background: '#ffffff',
      border: '1px solid #dfe6ec',
      borderRadius: 8,
      boxShadow: '0 1px 2px rgba(0,38,62,0.05), 0 4px 12px rgba(0,38,62,0.05)',
      borderTop: '2px solid #5b7f95',
    }}
  >
    <div className="text-[10px] uppercase tracking-widest font-mono truncate" style={{ color: COLORS.muted }} title={label}>
      {label}
    </div>
    <div
      className="mt-1.5 font-mono font-semibold truncate"
      style={{ color: COLORS.light, fontSize: '1.05rem', lineHeight: 1.2 }}
      title={title}
    >
      {value}
    </div>
    {hint && (
      <div className="text-[10px] mt-0.5 truncate" style={{ color: COLORS.muted }}>
        {hint}
      </div>
    )}
  </div>
);

// Searchable BID selector — native <select> can't be filtered by typing, so this
// combobox lets the user search across the BID id and project title.
const BidSelect: React.FC<{
  value: string;
  onChange: (id: string) => void;
  bidIds: string[];
  oppTitles: Map<string, string>;
}> = ({ value, onChange, bidIds, oppTitles }) => {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return undefined;
    const onDocClick = (e: MouseEvent): void => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', onDocClick);
    return () => document.removeEventListener('mousedown', onDocClick);
  }, [open]);

  const label = (id: string): string => `${id} — ${(oppTitles.get(id) || '').slice(0, 40)}`;

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return bidIds;
    return bidIds.filter((id) => label(id).toLowerCase().indexOf(q) !== -1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bidIds, oppTitles, query]);

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={() => {
          setOpen((o) => !o);
          setQuery('');
        }}
        className={`${INPUT_CLS} flex items-center justify-between text-left`}
      >
        <span className="truncate">{value ? label(value) : 'Select a BID…'}</span>
        <span className="text-muted ml-2 shrink-0">▾</span>
      </button>
      {open && (
        <div
          className="absolute z-30 mt-1 w-full border border-border rounded-none"
          style={{ background: '#ffffff', boxShadow: '0 8px 24px rgba(0,38,62,0.12)' }}
        >
          <div className="p-2 border-b border-border">
            <input
              autoFocus
              className={INPUT_CLS}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search BID or project…"
            />
          </div>
          <div className="max-h-60 overflow-y-auto">
            {filtered.length === 0 ? (
              <div className="px-3 py-2 text-xs text-muted">No BID found.</div>
            ) : (
              filtered.map((id) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => {
                    onChange(id);
                    setOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 text-xs truncate transition ${
                    id === value ? 'bg-navy/60 text-gold' : 'text-light hover:bg-navy/40'
                  }`}
                  title={label(id)}
                >
                  {label(id)}
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Lightweight charts (no external chart library available in this bundle)
// ─────────────────────────────────────────────────────────────────────────────

const ParetoChart: React.FC<{ data: Array<{ label: string; value: number; pct: number }> }> = ({ data }) => {
  const [zoom, setZoom] = useState(1);
  if (!data.length) return null;
  const H = 440;
  const padTop = 24;
  const padBottom = 185;
  const padL = 16;
  const padR = 16;
  const colW = Math.round(56 * zoom);
  const W = Math.max(data.length * colW + padL + padR, 560);
  const plotH = H - padTop - padBottom;
  const maxVal = Math.max(...data.map((d) => d.value)) || 1;
  const x = (i: number): number => padL + i * colW + colW / 2;
  const yVal = (v: number): number => padTop + plotH * (1 - v / maxVal);
  const yPct = (p: number): number => padTop + plotH * (1 - p / 100);
  const barW = Math.min(colW * 0.6, 44);
  const labelChars = Math.max(16, Math.round(colW / 2.2));
  const labelFont = zoom >= 1.4 ? 11 : 9;
  const showValues = colW >= 62;
  const linePts = data.map((d, i) => `${x(i)},${yPct(d.pct)}`).join(' ');
  const zoomOut = (): void => setZoom((z) => Math.max(0.6, +(z - 0.35).toFixed(2)));
  const zoomIn = (): void => setZoom((z) => Math.min(4, +(z + 0.35).toFixed(2)));
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-xs font-medium text-muted mr-1">Zoom</span>
        <button type="button" onClick={zoomOut} className={BTN_ICON} aria-label="Zoom out">−</button>
        <button type="button" onClick={zoomIn} className={BTN_ICON} aria-label="Zoom in">+</button>
        <button
          type="button"
          onClick={() => setZoom(1)}
          className={BTN_SMALL}
        >
          Reset
        </button>
        <span className="text-[10px] text-muted ml-1">Arraste na horizontal para ver todos os itens · passe o mouse para detalhes</span>
      </div>
      <div className="overflow-x-auto border border-border rounded-lg bg-surface p-1">
        <svg width={W} height={H} role="img" aria-label="Pareto chart">
          <line x1={padL} x2={W - padR} y1={yPct(80)} y2={yPct(80)} stroke={COLORS.red} strokeDasharray="4 4" strokeWidth={1} />
          <text x={padL + 2} y={yPct(80) - 4} fontSize={9} fill={COLORS.red}>80%</text>
          {data.map((d, i) => {
            const bh = plotH * (d.value / maxVal);
            const color = d.pct <= 80 ? COLORS.gold : COLORS.steel;
            return (
              <g key={i} style={{ cursor: 'pointer' }}>
                <title>{`${d.label}\nCusto: ${fmtUsd(d.value)}\nAcumulado: ${d.pct.toFixed(1)}%`}</title>
                <rect x={x(i) - barW / 2} y={yVal(d.value)} width={barW} height={bh} fill={color} rx={2} />
                {showValues && (
                  <text x={x(i)} y={yVal(d.value) - 4} fontSize={labelFont} fill="#33464f" textAnchor="middle">
                    {fmtUsd(d.value)}
                  </text>
                )}
                <text
                  x={x(i)}
                  y={H - padBottom + 14}
                  fontSize={labelFont}
                  fill="#33464f"
                  textAnchor="end"
                  transform={`rotate(-40 ${x(i)} ${H - padBottom + 14})`}
                >
                  {d.label.length > labelChars ? d.label.slice(0, labelChars) + '…' : d.label}
                </text>
              </g>
            );
          })}
          <polyline points={linePts} fill="none" stroke={COLORS.red} strokeWidth={1.5} />
          {data.map((d, i) => (
            <circle key={i} cx={x(i)} cy={yPct(d.pct)} r={4} fill={COLORS.red} style={{ cursor: 'pointer' }}>
              <title>{`${d.label}\nAcumulado: ${d.pct.toFixed(1)}%\nCusto: ${fmtUsd(d.value)}`}</title>
            </circle>
          ))}
        </svg>
      </div>
    </div>
  );
};

const HRanking: React.FC<{
  rows: Array<{ desc: string; value: number; pctBid: number }>;
  color: string;
}> = ({ rows, color }) => {
  if (!rows.length) return null;
  const max = Math.max(...rows.map((r) => r.value)) || 1;
  return (
    <div className="space-y-1.5">
      {rows.map((r, i) => (
        <div key={i} className="flex items-center gap-3" title={`${r.desc}\n${fmtUsd(r.value)} (${r.pctBid.toFixed(1)}% do BID)`}>
          <div className="w-40 shrink-0 text-xs text-light" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }}>
            {r.desc}
          </div>
          <div className="flex-1 h-4 bg-[#eef2f5] relative rounded">
            <div className="h-full rounded" style={{ width: `${(r.value / max) * 100}%`, background: color }} />
          </div>
          <div className="w-32 shrink-0 text-right text-xs font-mono" style={{ color }}>
            {fmtUsd(r.value)} ({r.pctBid.toFixed(1)}%)
          </div>
        </div>
      ))}
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// TAB 2 — Bid Ranking
// ─────────────────────────────────────────────────────────────────────────────

type RankSubTab = 'pareto' | 'capex' | 'opex' | 'categories' | 'accessories';

const BidRankingTab: React.FC<{ cost: BenchItem[]; opps: OppInfo[]; oppTitles: Map<string, string> }> = ({
  cost,
  opps,
  oppTitles,
}) => {
  const bidIds = useMemo(() => opps.map((o) => o.oppId).filter(Boolean), [opps]);
  const [selBid, setSelBid] = useState(bidIds[0] || '');
  const [typeFilter, setTypeFilter] = useState<Set<string>>(new Set());
  const [subTab, setSubTab] = useState<RankSubTab>('pareto');

  const typesAvailable = useMemo(
    () => Array.from(new Set(cost.filter((c) => c.oppId === selBid).map((c) => c.typeRaw).filter(Boolean))).sort(),
    [cost, selBid]
  );

  // Default: all types selected whenever the bid changes.
  useEffect(() => {
    setTypeFilter(new Set(typesAvailable));
  }, [typesAvailable]);

  const bidItems = useMemo(() => {
    const items = cost.filter((c) => c.oppId === selBid);
    if (typeFilter.size === 0) return items;
    return items.filter((c) => typeFilter.has(c.typeRaw));
  }, [cost, selBid, typeFilter]);

  const dfMain = bidItems.filter((c) => isMainType(c.typeRaw));
  const dfZero = bidItems.filter((c) => isZeroType(c.typeRaw));
  const dfAcc = bidItems.filter((c) => isAccessory(c.typeRaw));
  const dfNoPrice = dfMain.filter((c) => c.unitPrice === 0);
  const capexItems = dfMain.filter((c) => isCapex(c.typeRaw));
  const opexItems = dfMain.filter((c) => isOpex(c.typeRaw));
  const totalBid = dfMain.reduce((s, c) => s + c.unitPriceFin * c.quantity, 0);
  const accTotal = dfAcc.reduce((s, c) => s + c.unitPrice * c.quantity, 0);

  const toggleType = (t: string): void => {
    setTypeFilter((prev) => {
      const next = new Set(prev);
      if (next.has(t)) next.delete(t);
      else next.add(t);
      return next;
    });
  };

  const { paretoRows, paretoTotal } = useMemo(() => {
    const src = [
      ...dfMain.map((c) => ({ desc: c.description, total: c.unitPriceFin * c.quantity })),
      ...dfAcc.map((c) => ({ desc: c.description, total: c.unitPrice * c.quantity })),
    ].filter((r) => r.total > 0);
    const grandTotal = src.reduce((s, r) => s + r.total, 0);
    const sorted = src.sort((a, b) => b.total - a.total).slice(0, 30);
    let cum = 0;
    const rows = sorted.map((r) => {
      cum += r.total;
      return { label: r.desc, value: r.total, pct: grandTotal > 0 ? (cum / grandTotal) * 100 : 0 };
    });
    return { paretoRows: rows, paretoTotal: grandTotal };
  }, [dfMain, dfAcc]);

  const rankRows = (items: BenchItem[]): Array<{ desc: string; value: number; pctBid: number }> =>
    items
      .map((c) => ({ desc: c.description, value: c.unitPriceFin * c.quantity }))
      .filter((r) => r.value > 0)
      .sort((a, b) => b.value - a.value)
      .slice(0, 15)
      .map((r) => ({ ...r, pctBid: totalBid > 0 ? (r.value / totalBid) * 100 : 0 }));

  const categoryRows = useMemo(() => {
    const map = new Map<string, number>();
    dfMain.forEach((c) => {
      const total = c.unitPriceFin * c.quantity;
      if (total > 0) map.set(c.category || 'Other', (map.get(c.category || 'Other') || 0) + total);
    });
    return Array.from(map.entries())
      .map(([cat, total]) => ({ cat, total, pct: totalBid > 0 ? (total / totalBid) * 100 : 0 }))
      .sort((a, b) => b.total - a.total);
  }, [dfMain, totalBid]);

  const subTabs: Array<{ key: RankSubTab; label: string }> = [
    { key: 'pareto', label: 'Pareto' },
    { key: 'capex', label: 'Top CAPEX' },
    { key: 'opex', label: 'Top OPEX' },
    { key: 'categories', label: 'Categories' },
    { key: 'accessories', label: 'Accessories' },
  ];

  const n80 = paretoRows.filter((d) => d.pct <= 80).length;
  const catMax = Math.max(...categoryRows.map((c) => c.total), 1);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        <Field label="Select BID">
          <BidSelect value={selBid} onChange={setSelBid} bidIds={bidIds} oppTitles={oppTitles} />
        </Field>
        <Field label="Filter by Type (click to toggle)">
          <div className="flex flex-wrap gap-1.5">
            {typesAvailable.map((t) => {
              const on = typeFilter.has(t);
              return (
                <button
                  key={t}
                  type="button"
                  onClick={() => toggleType(t)}
                  className={chipCls(on)}
                >
                  {t}
                </button>
              );
            })}
          </div>
        </Field>
      </div>

      {bidItems.length === 0 ? (
        <p className="text-sm text-muted">No cost data for this BID or selected types.</p>
      ) : (
        <>
          <StatGrid>
            <Stat label="Total BID (USD)" value={fmtUsd(totalBid)} />
            <Stat label="CAPEX (USD)" value={capexItems.length ? fmtUsd(capexItems.reduce((s, c) => s + c.unitPriceFin * c.quantity, 0)) : '—'} />
            <Stat label="OPEX (USD)" value={opexItems.length ? fmtUsd(opexItems.reduce((s, c) => s + c.unitPriceFin * c.quantity, 0)) : '—'} />
            <Stat label="In-house / Onboard" value={fmtNum(dfZero.length)} />
            <Stat label="Missing price" value={fmtNum(dfNoPrice.length)} hint={dfNoPrice.length ? 'items typed but unpriced' : undefined} />
          </StatGrid>

          {dfNoPrice.length > 0 && (
            <div className="border border-red-500/40 bg-red-500/5 rounded-none p-3">
              <p className="text-xs uppercase tracking-widest text-red-400 font-mono mb-2">
                {dfNoPrice.length} item(s) with missing price
              </p>
              <div className="space-y-1 max-h-40 overflow-y-auto">
                {dfNoPrice.map((c, i) => (
                  <div key={i} className="text-xs text-muted flex justify-between gap-2">
                    <span className="truncate">{c.description}</span>
                    <span className="font-mono shrink-0">{c.typeRaw}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className={TAB_ROW}>
            {subTabs.map((st) => (
              <button
                key={st.key}
                onClick={() => setSubTab(st.key)}
                className={tabCls(subTab === st.key)}
              >
                {st.label}
              </button>
            ))}
          </div>

          {subTab === 'pareto' && (
            <div className="space-y-3">
              <div className="flex items-center gap-4 text-xs text-muted">
                <span className="flex items-center gap-1"><span className="inline-block w-3 h-3" style={{ background: COLORS.gold }} /> Cost</span>
                <span className="flex items-center gap-1"><span className="inline-block w-3 h-0.5" style={{ background: COLORS.red }} /> Cumul. %</span>
              </div>
              <ParetoChart data={paretoRows} />
              {n80 > 0 && (
                <div className="bg-navy/40 border-l-2 border-gold p-3 text-xs text-light">
                  <strong>{n80} item(s)</strong> = 80% of cost (
                  {fmtUsd(paretoRows.slice(0, n80).reduce((s, d) => s + d.value, 0))} of {fmtUsd(paretoTotal)})
                </div>
              )}
            </div>
          )}

          {subTab === 'capex' && (capexItems.length ? <HRanking rows={rankRows(capexItems)} color={COLORS.gold} /> : <p className="text-sm text-muted">No CAPEX items.</p>)}
          {subTab === 'opex' && (opexItems.length ? <HRanking rows={rankRows(opexItems)} color={COLORS.teal} /> : <p className="text-sm text-muted">No OPEX items.</p>)}

          {subTab === 'categories' && (
            <div className="space-y-1.5">
              {categoryRows.length === 0 ? (
                <p className="text-sm text-muted">No data.</p>
              ) : (
                categoryRows.map((c, i) => (
                  <div key={i} className="flex items-center gap-3" title={`${c.cat}\n${fmtUsd(c.total)} (${c.pct.toFixed(1)}%)`}>
                    <div className="w-40 shrink-0 text-xs text-light" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }}>{c.cat}</div>
                    <div className="flex-1 h-4 bg-black/30">
                      <div className="h-full bg-teal" style={{ width: `${(c.total / catMax) * 100}%` }} />
                    </div>
                    <div className="w-32 shrink-0 text-right text-xs font-mono text-teal">
                      {fmtUsd(c.total)} ({c.pct.toFixed(1)}%)
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {subTab === 'accessories' && (
            dfAcc.length === 0 ? (
              <p className="text-sm text-green">No accessory lines in this BID.</p>
            ) : (
              <div className="space-y-3">
                <StatGrid>
                  <Stat label="Accessory lines" value={fmtNum(dfAcc.length)} />
                  <Stat label="Total acc. cost" value={fmtUsd(accTotal)} />
                </StatGrid>
                <div className="border border-border rounded-none overflow-x-auto">
                  <div style={{ minWidth: ACC_MINW }}>
                  <div style={tableGrid(ACC_COLS, ACC_MINW)} className="px-3 py-2 bg-deep/95 border-b border-border text-[10px] uppercase tracking-widest text-muted font-mono">
                    <div>Accessory</div>
                    <div>PN</div>
                    <div>Type</div>
                    <div className="text-right">Price</div>
                  </div>
                  <div className="max-h-96 overflow-y-auto">
                    {dfAcc.map((c, i) => {
                      const tag = getAccessoryTag(c.typeRaw);
                      return (
                        <div key={i} style={{ ...tableGrid(ACC_COLS, ACC_MINW), alignItems: 'flex-start' }} className="px-3 py-1.5 border-b border-border-light">
                          <div className="text-[11px] text-light" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }} title={c.description}>{c.description}</div>
                          <div className="text-[10px] text-muted font-mono" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }}>{c.pn || '—'}</div>
                          <div className="text-[10px]" style={{ color: tag.color, whiteSpace: 'normal', overflowWrap: 'anywhere' }}>{c.typeRaw}</div>
                          <div className="text-[11px] font-mono text-right" style={{ color: tag.color }}>{fmtUsd(c.unitPrice)}</div>
                        </div>
                      );
                    })}
                  </div>
                  </div>
                </div>
              </div>
            )
          )}
        </>
      )}
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Acquisition-type chart — % of how the item was offered (purchase / in house…)
// ─────────────────────────────────────────────────────────────────────────────

const AcquisitionChart: React.FC<{ stats: AcquisitionTypeStat[]; total: number }> = ({ stats, total }) => {
  if (!stats.length) return null;
  const size = 150;
  const stroke = 26;
  const r = (size - stroke) / 2;
  const cx = size / 2;
  const C = 2 * Math.PI * r;

  // Pre-compute each arc's start offset so the map stays side-effect free.
  let acc = 0;
  const segments = stats.map((s) => {
    const start = acc;
    const len = (s.pct / 100) * C;
    acc += len;
    return { s, start, len };
  });

  // Dark text on light slices (gold/orange), white text elsewhere, for contrast.
  const labelColor = (hex: string): string => (hex === '#ffc72c' || hex === '#EF9F27' ? '#0d2430' : '#ffffff');

  return (
    <div className="flex flex-wrap items-center gap-x-6 gap-y-3">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} role="img" aria-label="Acquisition mix">
        <g transform={`rotate(-90 ${cx} ${cx})`}>
          <circle cx={cx} cy={cx} r={r} fill="none" stroke="#eef2f5" strokeWidth={stroke} />
          {segments.map(({ s, start, len }) => (
            <circle
              key={s.type}
              cx={cx}
              cy={cx}
              r={r}
              fill="none"
              stroke={s.color}
              strokeWidth={stroke}
              strokeDasharray={`${len} ${C - len}`}
              strokeDashoffset={-start}
            >
              <title>{`${s.type}: ${s.count} of ${total} (${s.pct.toFixed(0)}%)`}</title>
            </circle>
          ))}
        </g>
        {segments.map(({ s, start, len }) => {
          if (s.pct < 8) return null; // skip labels on slivers to avoid clutter
          const angle = -Math.PI / 2 + ((start + len / 2) / C) * 2 * Math.PI;
          const lx = cx + r * Math.cos(angle);
          const ly = cx + r * Math.sin(angle);
          return (
            <text
              key={s.type}
              x={lx}
              y={ly}
              textAnchor="middle"
              dominantBaseline="central"
              fontSize={11}
              fontWeight={700}
              fill={labelColor(s.color)}
              style={{ pointerEvents: 'none' }}
            >
              {s.pct.toFixed(0)}%
            </text>
          );
        })}
        <text x={cx} y={cx - 3} textAnchor="middle" fontSize={22} fontWeight={700} fill={COLORS.light}>{total}</text>
        <text x={cx} y={cx + 14} textAnchor="middle" fontSize={9} fill={COLORS.muted}>bid records</text>
      </svg>
      <div className="flex-1 space-y-1.5" style={{ minWidth: 200 }}>
        {stats.map((s) => (
          <div key={s.type} className="flex items-center gap-2 text-[11px]">
            <span className="inline-block w-3 h-3 rounded-sm shrink-0" style={{ background: s.color }} />
            <span className="text-light capitalize truncate" title={s.type}>{s.type}</span>
            <span className="ml-auto font-mono shrink-0" style={{ color: s.color }}>
              {s.pct.toFixed(0)}% · {s.count}×
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Inventory (ERP) strip — stock / cost / vendor / margin for a PN
// ─────────────────────────────────────────────────────────────────────────────

const SupplyStrip: React.FC<{ supply?: SupplyInfo; quoteUsd?: number }> = ({ supply, quoteUsd }) => {
  if (!supply) {
    return (
      <div className="text-[10px] font-mono" style={{ color: COLORS.muted }}>
        No inventory (ERP) data for this PN.
      </div>
    );
  }
  const stockColor = supply.inStock ? COLORS.green : COLORS.red;
  const cost = supply.avgCostUsd || supply.replCostUsd || supply.unitCostUsd;
  const margin = quoteUsd && quoteUsd > 0 ? computeMargin(quoteUsd, supply) : undefined;
  const marginColor = !margin ? COLORS.muted : margin.pct >= 0.3 ? COLORS.green : margin.pct >= 0.1 ? COLORS.gold : COLORS.red;
  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] font-mono" style={{ color: COLORS.light }}>
      <span style={{ color: stockColor }}>{supply.inStock ? `● in stock: ${supply.qtyAvailable}` : '○ out of stock'}</span>
      {cost > 0 && <span>cost: {fmtUsd(cost)}</span>}
      {supply.poDate && <span title="Date of the last purchase order for this item">last PO: {supply.poDate}</span>}
      {typeof supply.leadTimeDays === 'number' && <span>lead time: {supply.leadTimeDays}d</span>}
      {supply.vendorName && (
        <span className="truncate max-w-[240px]" title={supply.vendorName}>
          vendor: {supply.vendorName}
        </span>
      )}
      {margin && (
        <span className="font-semibold" style={{ color: marginColor }}>
          margin ≈ {(margin.pct * 100).toFixed(0)}%
        </span>
      )}
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Equipment mapping card — "When clients ask for GNSS, we typically offer…"
// ─────────────────────────────────────────────────────────────────────────────

const MappingCard: React.FC<{ query: string; cost: BenchItem[] }> = ({ query, cost }) => {
  const toast = useToast();
  const [mappings, setMappings] = useState<EquipmentMapping[]>(() => loadMappings());
  const [editing, setEditing] = useState(false);
  const [editModels, setEditModels] = useState('');
  const [editNotes, setEditNotes] = useState('');

  const mappingHit = useMemo(() => (query.trim() ? findMapping(query, mappings) : undefined), [query, mappings]);
  const modelHistory = useMemo(
    () => (mappingHit ? getModelHistory(cost, mappingHit.our_models) : []),
    [mappingHit, cost]
  );

  const startEdit = (): void => {
    if (!mappingHit) return;
    setEditModels(mappingHit.our_models.join('\n'));
    setEditNotes(mappingHit.notes || '');
    setEditing(true);
  };

  const saveEdit = (): void => {
    if (!mappingHit) return;
    const updated = mappings.map((m) =>
      m.client_term === mappingHit.client_term
        ? { ...m, our_models: editModels.split('\n').map((s) => s.trim()).filter(Boolean), notes: editNotes.trim() }
        : m
    );
    setMappings(updated);
    saveMappings(updated);
    setEditing(false);
    toast.success('Mapping saved');
  };

  const createMapping = (): void => {
    const term = query.trim().toUpperCase();
    if (!term) return;
    const created: EquipmentMapping = {
      client_term: term,
      keywords: query.trim().toLowerCase().split(/[,\s]+/).filter(Boolean),
      our_models: editModels.split('\n').map((s) => s.trim()).filter(Boolean),
      notes: editNotes.trim(),
    };
    if (!created.our_models.length) {
      toast.error('Add at least one model');
      return;
    }
    const updated = [...mappings, created];
    setMappings(updated);
    saveMappings(updated);
    setEditModels('');
    setEditNotes('');
    toast.success(`Mapping created for ${term}`);
  };

  if (!query.trim()) return null;

  return mappingHit ? (
    <div className="border border-border border-t-2 border-t-teal bg-navy/30 rounded-none p-4 space-y-3">
      <p className="text-sm text-light">
        When clients ask for <strong className="text-gold">{mappingHit.client_term}</strong>, we typically offer:
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
        {mappingHit.our_models.map((m, i) => (
          <div key={i} className="bg-navy/60 border border-border border-t-2 border-t-teal p-2.5 text-center text-xs text-light">
            {m}
          </div>
        ))}
      </div>
      {mappingHit.notes && <p className="text-xs text-muted">{mappingHit.notes}</p>}

      {modelHistory.length > 0 ? (
        <div className="space-y-1">
          <p className="text-xs uppercase tracking-widest text-muted font-mono">Historical prices for these models</p>
          {mappingHit.our_models.map((model) => {
            const recs = modelHistory.filter((h) => h.matchedModel === model).map((h) => h.item.unitPrice).filter((p) => p > 0);
            if (!recs.length) return null;
            return (
              <div key={model} className="flex justify-between text-xs">
                <span className="text-light truncate">{model}</span>
                <span className="text-gold font-mono shrink-0">
                  avg {fmtUsd(mean(recs))} · min {fmtUsd(Math.min(...recs))} · max {fmtUsd(Math.max(...recs))} ({recs.length})
                </span>
              </div>
            );
          })}
        </div>
      ) : (
        <p className="text-xs text-muted">No historical records yet for these specific models.</p>
      )}

      {editing ? (
        <div className="space-y-2 border-t border-border pt-3">
          <textarea className={INPUT_CLS} rows={3} value={editModels} onChange={(e) => setEditModels(e.target.value)} placeholder="Models we offer (one per line)" />
          <input className={INPUT_CLS} value={editNotes} onChange={(e) => setEditNotes(e.target.value)} placeholder="Notes" />
          <div className="flex gap-2">
            <button onClick={saveEdit} className={BTN_PRIMARY}>Save</button>
            <button onClick={() => setEditing(false)} className={BTN_GHOST}>Cancel</button>
          </div>
        </div>
      ) : (
        <button onClick={startEdit} className={BTN_LINK}>Edit this mapping</button>
      )}
    </div>
  ) : (
    <div className="border border-border bg-navy/20 rounded-none p-4 space-y-2">
      <p className="text-xs uppercase tracking-widest text-muted font-mono">Create mapping for “{query}”</p>
      <textarea className={INPUT_CLS} rows={3} value={editModels} onChange={(e) => setEditModels(e.target.value)} placeholder="Models we offer (one per line)" />
      <input className={INPUT_CLS} value={editNotes} onChange={(e) => setEditNotes(e.target.value)} placeholder="Notes (optional)" />
      <button onClick={createMapping} className={BTN_PRIMARY}>Add mapping</button>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// TAB 3 — Item History (search by BID or by item; full cost + acquisition mix)
// ─────────────────────────────────────────────────────────────────────────────

type HistoryMode = 'bid' | 'item';

const HistoryTab: React.FC<{
  cost: BenchItem[];
  opps: OppInfo[];
  oppTitles: Map<string, string>;
  supplyMap: Map<string, SupplyInfo>;
  supplyRows: Array<Record<string, unknown>>;
}> = ({ cost, opps, oppTitles, supplyMap, supplyRows }) => {
  const [mode, setMode] = useState<HistoryMode>('item');

  const modes: Array<{ key: HistoryMode; label: string }> = [
    { key: 'item', label: 'Search by item' },
    { key: 'bid', label: 'Search by BID' },
  ];

  return (
    <div className="space-y-4">
      <div className={TAB_ROW}>
        {modes.map((m) => (
          <button
            key={m.key}
            onClick={() => setMode(m.key)}
            className={tabCls(mode === m.key)}
          >
            {m.label}
          </button>
        ))}
      </div>

      {mode === 'bid' ? (
        <BidHistoryView cost={cost} opps={opps} oppTitles={oppTitles} supplyMap={supplyMap} />
      ) : (
        <ItemHistoryView cost={cost} oppTitles={oppTitles} supplyMap={supplyMap} supplyRows={supplyRows} />
      )}
    </div>
  );
};

// ── Search-by-item: free lookup by PN or description across every bid ─────────

interface ItemGroup {
  key: string;
  kind: 'pn' | 'et' | 'desc';
  source: 'bids' | 'erp';
  label: string;
  row: BenchItem;
  occurrences: number;
  nBids: number;
  aliases: string[];
}

const ItemHistoryView: React.FC<{
  cost: BenchItem[];
  oppTitles: Map<string, string>;
  supplyMap: Map<string, SupplyInfo>;
  supplyRows: Array<Record<string, unknown>>;
}> = ({ cost, oppTitles, supplyMap, supplyRows }) => {
  const [query, setQuery] = useState('');
  const [source, setSource] = useState<'bids' | 'erp' | 'all'>('all');
  const [expanded, setExpanded] = useState<string | null>(null);

  useEffect(() => setExpanded(null), [query, source]);

  const groups = useMemo<ItemGroup[]>(() => {
    const q = query.trim();
    if (!q) return [];
    const hits = source === 'erp' ? [] : searchByWords(cost, q).filter((c) => !isAccessory(c.typeRaw));

    // Consolidation key: PN when available, else the ET Text requirement label
    // (so different spellings of the same requirement collapse into one card),
    // else the normalized description as a last resort.
    const keyOf = (it: BenchItem): { key: string; kind: 'pn' | 'et' | 'desc' } => {
      if (isValidPn(it.pn)) return { key: `pn:${pnKey(it.pn)}`, kind: 'pn' };
      const et = normalizeTextKey(it.etText);
      if (et) return { key: `et:${et}`, kind: 'et' };
      return { key: `desc:${normalizeTextKey(it.description)}`, kind: 'desc' };
    };

    const map = new Map<string, ItemGroup>();
    const aliasSets = new Map<string, Set<string>>();
    const bidSets = new Map<string, Set<string>>();
    for (const it of hits) {
      const { key, kind } = keyOf(it);
      let g = map.get(key);
      if (!g) {
        const label = kind === 'et' ? (it.etText || '').trim() : it.description;
        g = { key, kind, source: 'bids', label, row: it, occurrences: 0, nBids: 0, aliases: [] };
        map.set(key, g);
        aliasSets.set(key, new Set<string>());
        bidSets.set(key, new Set<string>());
      }
      g.occurrences += 1;
      // Prefer a priced representative row so the card shows a real price.
      if (it.unitPrice > g.row.unitPrice) g.row = it;
      if (it.description) aliasSets.get(key)!.add(it.description.trim());
      bidSets.get(key)!.add(it.oppId);
    }
    map.forEach((g) => {
      g.nBids = bidSets.get(g.key)?.size || 0;
      g.aliases = Array.from(aliasSets.get(g.key) || []);
    });

    // ERP-only support (PN search): include PNs that exist in Supply_Index but
    // have never appeared in bids, so users can look up query items directly.
    if (source !== 'bids') {
      const qNorm = normalizeTextKey(q);
      const qKey = pnKey(q);
      if (qNorm) {
        supplyRows.forEach((raw, idx) => {
          const pnRaw = String(raw.pn ?? '').trim();
          const key = pnKey(pnRaw);
          if (!key) return;
          const descEn = String(raw.description ?? '').trim();
          const descPt = String(raw.description_pt ?? '').trim();
          const category = String(raw.item_category ?? '').trim();

          const pnHit = qKey ? key.indexOf(qKey) !== -1 || pnKey(pnRaw).indexOf(qKey) !== -1 : false;
          const descHit = normalizeTextKey(descEn).indexOf(qNorm) !== -1 || normalizeTextKey(descPt).indexOf(qNorm) !== -1;
          if (!pnHit && !descHit) return;

          const grpKey = `pn:${key}`;
          if (map.has(grpKey)) return; // bids result already covers this PN
          const supply = supplyMap.get(key);
          const pnLabel = pnRaw || key;
          map.set(grpKey, {
            key: grpKey,
            kind: 'pn',
            source: 'erp',
            label: pnLabel,
            row: {
              index: -100000 - idx,
              oppId: '',
              description: descEn || descPt || `ERP item ${pnLabel}`,
              pn: pnLabel,
              typeRaw: 'ERP only',
              category,
              group: '',
              etText: '',
              premisses: '',
              currency: 'USD',
              quantity: 1,
              unitPrice: 0,
              unitPriceFin: 0,
              typeClass: 'ZERO PRICE',
            },
            occurrences: 1,
            nBids: 0,
            aliases: [descEn, descPt].filter(Boolean),
          });
        });
      }
    }

    return Array.from(map.values()).sort((a, b) => b.nBids - a.nBids || b.occurrences - a.occurrences).slice(0, 60);
  }, [cost, query, source, supplyMap, supplyRows]);

  return (
    <div className="space-y-4">
      <p className="text-sm text-light font-semibold">
        Search any item by PN or description — no bid required. See how it was acquired, its full cost history and inventory.
      </p>
      <Field label="Search by description or PN">
        <input
          className={INPUT_CLS}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="e.g. GNSS RECEIVER · C-NAV · ROV CLASS III · 0000143"
        />
      </Field>

      <div className={TAB_ROW}>
        {[
          { key: 'all', label: 'Bids + ERP' },
          { key: 'bids', label: 'Only bids' },
          { key: 'erp', label: 'Only ERP' },
        ].map((m) => (
          <button
            key={m.key}
            onClick={() => setSource(m.key as 'all' | 'bids' | 'erp')}
            className={chipCls(source === m.key)}
          >
            {m.label}
          </button>
        ))}
      </div>

      <MappingCard query={query} cost={cost} />

      {!query.trim() ? (
        <p className="text-sm text-muted">Enter a description or PN above to search bids and/or ERP query data.</p>
      ) : groups.length === 0 ? (
        <p className="text-sm text-gold">No items found for “{query}”.</p>
      ) : (
        <>
          <p className="text-xs text-muted">
            {groups.length} distinct item{groups.length === 1 ? '' : 's'} — click “Full history” to see acquisition mix,
            cost history and inventory. ERP-only items show inventory even with no bid history.
          </p>
          <div className="space-y-1.5">
            {groups.map((g) => (
              <HistoryItemCard
                key={g.key}
                node={{ row: g.row, children: [] }}
                cost={cost}
                selBid=""
                oppTitles={oppTitles}
                supplyMap={supplyMap}
                bidMode={false}
                occurrences={g.occurrences}
                nBids={g.nBids}
                title={g.kind === 'et' ? g.label : undefined}
                aliases={g.kind === 'et' ? g.aliases : undefined}
                expanded={expanded === g.key}
                onToggle={() => setExpanded(expanded === g.key ? null : g.key)}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
};

// ── Search-by-BID: inspect the full cost of every item within one bid ─────────

const BidHistoryView: React.FC<{
  cost: BenchItem[];
  opps: OppInfo[];
  oppTitles: Map<string, string>;
  supplyMap: Map<string, SupplyInfo>;
}> = ({ cost, opps, oppTitles, supplyMap }) => {
  const bidIds = useMemo(() => opps.map((o) => o.oppId).filter(Boolean), [opps]);
  const [selBid, setSelBid] = useState(bidIds[0] || '');
  const [filterText, setFilterText] = useState('');
  const [showInhouse, setShowInhouse] = useState(true);
  const [expanded, setExpanded] = useState<number | null>(null);

  useEffect(() => setExpanded(null), [selBid]);

  const bidItems = useMemo(() => cost.filter((c) => c.oppId === selBid), [cost, selBid]);
  const hierarchy = useMemo(() => buildHierarchy(bidItems), [bidItems]);

  const parents = useMemo(() => {
    let list = hierarchy.filter((node) => {
      const t = node.row.typeRaw;
      if (isMainType(t)) return true;
      if (isZeroType(t) && showInhouse) return true;
      return false;
    });
    if (filterText) {
      const q = normalizeTextKey(filterText);
      list = list.filter(
        (n) => normalizeTextKey(n.row.description).indexOf(q) !== -1 || normalizeTextKey(n.row.pn).indexOf(q) !== -1
      );
    }
    return list;
  }, [hierarchy, showInhouse, filterText]);

  const nPriced = parents.filter((p) => isMainType(p.row.typeRaw)).length;
  const nInhouse = parents.filter((p) => isZeroType(p.row.typeRaw)).length;

  return (
    <div className="space-y-4">
      <p className="text-sm text-light font-semibold">
        Select a BID and explore the FULL COST of each item (equipment + accessories) across past bids.
      </p>
      <p className="text-xs text-muted">
        Full cost = equipment price + certif. + transit + maint. + logistics. Items without a PN (TBD/blank) are matched by description similarity.
      </p>

      <div style={{ ...autoGrid(200), alignItems: 'end' }}>
        <Field label="Select BID">
          <BidSelect value={selBid} onChange={setSelBid} bidIds={bidIds} oppTitles={oppTitles} />
        </Field>
        <Field label="Filter items">
          <input className={INPUT_CLS} value={filterText} onChange={(e) => setFilterText(e.target.value)} placeholder="e.g. ROV, USBL..." />
        </Field>
        <label className="flex items-center gap-2 text-xs text-muted cursor-pointer pb-2.5">
          <input type="checkbox" checked={showInhouse} onChange={(e) => setShowInhouse(e.target.checked)} />
          Include In House
        </label>
      </div>

      {parents.length === 0 ? (
        <p className="text-sm text-muted">No items found for this BID.</p>
      ) : (
        <>
          <p className="text-xs text-muted">
            {parents.length} equipment items — {nPriced} priced, {nInhouse} in-house/zero — click to see full cost history
          </p>
          <div className="space-y-1.5">
            {parents.map((node, i) => (
              <HistoryItemCard
                key={i}
                node={node}
                cost={cost}
                selBid={selBid}
                oppTitles={oppTitles}
                supplyMap={supplyMap}
                bidMode
                expanded={expanded === i}
                onToggle={() => setExpanded(expanded === i ? null : i)}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
};

const HistoryItemCard: React.FC<{
  node: { row: BenchItem; children: BenchItem[] };
  cost: BenchItem[];
  selBid: string;
  oppTitles: Map<string, string>;
  supplyMap: Map<string, SupplyInfo>;
  bidMode: boolean;
  occurrences?: number;
  nBids?: number;
  title?: string;
  aliases?: string[];
  expanded: boolean;
  onToggle: () => void;
}> = ({ node, cost, selBid, oppTitles, supplyMap, bidMode, occurrences, nBids, title, aliases, expanded, onToggle }) => {
  const row = node.row;
  const pnValid = isValidPn(row.pn);
  const historyEtText = title ? row.etText : '';
  const zero = isZeroType(row.typeRaw);
  const accCost = node.children.reduce((s, c) => s + c.unitPrice, 0);
  const currentFull = row.unitPrice + accCost;
  const showCurrent = bidMode && !!selBid;

  const history = useMemo(
    () => getFullCostHistory(cost, row.pn, row.description, selBid, !pnValid, historyEtText),
    [cost, row.pn, row.description, selBid, pnValid, historyEtText]
  );

  const acquisition = useMemo(
    () => getAcquisitionBreakdown(cost, row.pn, row.description, !pnValid, historyEtText),
    [cost, row.pn, row.description, pnValid, historyEtText]
  );
  const acqTotal = acquisition.reduce((s, a) => s + a.count, 0);

  const supply = useMemo(
    () => (pnValid ? supplyMap.get(pnKey(row.pn)) : undefined),
    [supplyMap, row.pn, pnValid]
  );

  const fullCosts = history.map((h) => h.totalFullCost).filter((v) => v > 0);
  const avgFull = mean(fullCosts) || 0;
  const divergence = showCurrent && avgFull > 0 && currentFull > 0 ? ((currentFull - avgFull) / avgFull) * 100 : null;

  let badge: React.ReactNode;
  if (!bidMode) {
    badge = <span className="text-green">{nBids ?? history.length} bid(s) · {occurrences ?? history.length}×</span>;
  } else if (history.length && divergence !== null) {
    const color = divergence > 10 ? COLORS.red : divergence < -10 ? COLORS.green : COLORS.muted;
    badge = (
      <span style={{ color }}>
        {divergence > 10 ? '▲' : divergence < -10 ? '▼' : '≈'} {divergence >= 0 ? '+' : ''}
        {divergence.toFixed(0)}% vs avg · {history.length} bid(s)
      </span>
    );
  } else if (history.length) {
    badge = <span className="text-green">{history.length} bid(s)</span>;
  } else {
    badge = <span className="text-steel">{pnValid ? 'no history' : 'no history (desc match)'}</span>;
  }

  const avgMain = mean(history.map((h) => h.mainPrice).filter((v) => v > 0)) || 0;
  const avgAcc = mean(history.map((h) => h.totalAccessoriesCost)) || 0;
  const maxFull = Math.max(showCurrent ? currentFull : 0, ...history.map((h) => h.totalFullCost), 1);

  return (
    <div
      className="bg-navy/30 border border-border rounded-none p-3"
      style={{ borderLeft: `3px solid ${zero ? COLORS.green : expanded ? COLORS.gold : 'rgba(91,127,149,0.3)'}` }}
    >
      <div className="flex justify-between items-center gap-3">
        <div className="min-w-0">
          <div className="text-xs font-medium text-light truncate">
            {title ? (
              <>
                <span className="text-[9px] mr-1.5 px-1 border rounded-sm" style={{ color: COLORS.teal, borderColor: COLORS.teal }}>
                  REQUIREMENT
                </span>
                {title}
              </>
            ) : row.typeRaw === 'ERP only' ? (
              <>
                <span className="text-[9px] mr-1.5 px-1 border rounded-sm" style={{ color: COLORS.steel, borderColor: COLORS.steel }}>
                  ERP
                </span>
                {row.pn ? `PN ${row.pn}` : row.description}
              </>
            ) : (
              <>
                {zero && (
                  <span className="text-[9px] mr-1.5 px-1 border rounded-sm" style={{ color: COLORS.green, borderColor: COLORS.green }}>
                    {row.typeRaw}
                  </span>
                )}
                {row.description}
              </>
            )}
          </div>
          <div className="text-[10px] text-muted font-mono mt-0.5 truncate">
            PN: {pnValid ? row.pn : '—'} · {row.typeRaw} ·{' '}
            <span className="text-gold">{zero ? row.typeRaw : fmtUsd(row.unitPrice)}</span>
            {accCost > 0 && <span className="text-light"> · Full: {fmtUsd(currentFull)}</span>}
            {node.children.length > 0 && <span className="text-teal"> · {node.children.length} acc.</span>}
            <span className="text-steel"> · match: {title ? 'requirement (ET)' : pnValid ? 'PN' : 'desc'}</span>
          </div>
          {title && aliases && aliases.length > 1 && (
            <div className="text-[10px] text-muted mt-0.5">
              {aliases.length} descriptions grouped: {aliases.slice(0, 4).join(' · ')}
              {aliases.length > 4 ? ` +${aliases.length - 4}` : ''}
            </div>
          )}
        </div>
        <div className="text-[10px] font-mono shrink-0 text-right">{badge}</div>
      </div>
      <button onClick={onToggle} className={`mt-2 ${BTN_LINK}`}>
        {expanded ? '▲ Close' : '▼ Full history'}
      </button>

      {expanded && (
        <div className="mt-3 space-y-4">
          {acquisition.length > 0 && (
            <div className="space-y-2">
              <SectionLabel>Acquisition mix — how this item was offered ({acqTotal} bid record{acqTotal === 1 ? '' : 's'})</SectionLabel>
              <AcquisitionChart stats={acquisition} total={acqTotal} />
            </div>
          )}

          <div className="space-y-2">
            <SectionLabel>Inventory (ERP)</SectionLabel>
            <SupplyStrip supply={supply} quoteUsd={row.unitPrice > 0 ? row.unitPrice : avgMain} />
          </div>

          {history.length === 0 ? (
            <p className="text-xs text-muted">
              {pnValid ? `No cost history found for PN ${row.pn}.` : `No similar items found for “${row.description.slice(0, 50)}”.`}
            </p>
          ) : (
            <>
              <SectionLabel>Full Cost Comparison</SectionLabel>
              <StatGrid>
                {showCurrent && <Stat label="This BID (Full)" value={fmtUsd(currentFull)} />}
                <Stat label="Avg Historical (Full)" value={avgFull ? fmtUsd(avgFull) : '—'} />
                {showCurrent ? (
                  <Stat
                    label="Divergence"
                    value={divergence !== null ? `${divergence >= 0 ? '+' : ''}${divergence.toFixed(1)}%` : '—'}
                    hint={divergence !== null ? `${currentFull - avgFull >= 0 ? '+' : ''}${fmtUsd(currentFull - avgFull)}` : undefined}
                  />
                ) : (
                  <Stat label="Bids with history" value={fmtNum(history.length)} />
                )}
                <Stat label="Avg Equip. Only" value={avgMain ? fmtUsd(avgMain) : '—'} />
                <Stat label="Avg Accessories" value={fmtUsd(avgAcc)} />
              </StatGrid>

              {showCurrent && divergence !== null && avgFull > 0 && (
                <div
                  className="bg-navy/40 border border-border p-3 text-xs"
                  style={{ borderLeft: `4px solid ${divergence > 10 ? COLORS.red : divergence < -10 ? COLORS.green : COLORS.steel}` }}
                >
                  <div className="text-light">
                    <strong>{fmtUsd(currentFull)}</strong> (this bid) vs <strong>{fmtUsd(avgFull)}</strong> (avg) →{' '}
                    <span style={{ color: divergence > 10 ? COLORS.red : divergence < -10 ? COLORS.green : COLORS.steel, fontWeight: 600 }}>
                      {divergence >= 0 ? '+' : ''}{divergence.toFixed(1)}% {divergence > 0 ? 'ABOVE' : 'BELOW'} average
                    </span>
                  </div>
                  <div className="mt-1.5 h-1.5 bg-steel/20 rounded overflow-hidden">
                    <div
                      className="h-full rounded"
                      style={{
                        width: `${Math.min(Math.abs(divergence), 100)}%`,
                        background: divergence > 10 ? COLORS.red : divergence < -10 ? COLORS.green : COLORS.steel,
                      }}
                    />
                  </div>
                </div>
              )}

              <SectionLabel>History by BID (Equipment + Accessories)</SectionLabel>
              <div className="text-[10px] text-muted font-mono -mt-2">
                Main bar color = acquisition type (purchase/in house/day rate/etc.) · Teal segment = accessories
              </div>
              <div className="space-y-2">
                {showCurrent && (
                  <StackedBar
                    label={`${selBid} (CURRENT)`}
                    typeRaw={row.typeRaw}
                    description={row.description}
                    main={row.unitPrice}
                    acc={accCost}
                    max={maxFull}
                    current
                  />
                )}
                {history.map((h, hi) => (
                  <StackedBar
                    key={hi}
                    label={`${h.oppId} — ${(oppTitles.get(h.oppId) || '').slice(0, 22)}`}
                    typeRaw={h.typeRaw}
                    description={h.description}
                    main={h.mainPrice}
                    acc={h.totalAccessoriesCost}
                    max={maxFull}
                  />
                ))}
              </div>

              {showCurrent && zero && fullCosts.length > 0 && (
                <div className="bg-green/10 border border-green/30 p-3 text-xs text-light" style={{ borderLeft: `3px solid ${COLORS.green}` }}>
                  This item is <strong>In House</strong> (zero equipment cost), but in other bids the full cost averaged{' '}
                  <strong>{fmtUsd(avgFull)}</strong>. {accCost > 0 ? `Current accessories cost: ${fmtUsd(accCost)}.` : 'No accessories charged.'}
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
};

const StackedBar: React.FC<{
  label: string;
  typeRaw: string;
  description?: string;
  main: number;
  acc: number;
  max: number;
  current?: boolean;
}> = ({
  label,
  typeRaw,
  description,
  main,
  acc,
  max,
  current,
}) => {
  const mainColor = acquisitionColor(typeRaw);
  const mainPct = max > 0 ? (main / max) * 100 : 0;
  const accPct = max > 0 ? (acc / max) * 100 : 0;
  const showTypeMarker = main <= 0 && acc <= 0;

  return (
    <div className="flex items-center gap-3">
      <div className="w-44 shrink-0 min-w-0">
        <div className={`text-[11px] truncate ${current ? 'text-gold' : 'text-light'}`} title={label}>
          {label}
        </div>
        {description && (
          <div className="text-[9px] truncate" style={{ color: COLORS.light }} title={description}>
            {description}
          </div>
        )}
        <div className="text-[9px] font-mono truncate" style={{ color: mainColor }} title={typeRaw}>
          {typeRaw || '(unspecified)'}
        </div>
      </div>
      <div className="flex-1 h-5 bg-black/30 flex relative overflow-hidden">
        <div className="h-full" style={{ width: `${mainPct}%`, background: mainColor }} title={`${typeRaw}: ${fmtUsd(main)}`} />
        <div className="h-full" style={{ width: `${accPct}%`, background: COLORS.teal }} title={`Accessories ${fmtUsd(acc)}`} />
        {showTypeMarker && (
          <div
            className="absolute left-0 top-0 h-full"
            style={{ width: 3, background: mainColor }}
            title={`${typeRaw}: ${fmtUsd(main)}`}
          />
        )}
      </div>
      <div className="w-24 shrink-0 text-right text-[11px] font-mono text-light">{fmtUsd(main + acc)}</div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// TAB 5 — Labor
// ─────────────────────────────────────────────────────────────────────────────

const LaborTab: React.FC<{ labor: LaborRow[] }> = ({ labor }) => {
  const [search, setSearch] = useState('');
  const [projId, setProjId] = useState('');
  const [type, setType] = useState('All');
  const [phase, setPhase] = useState('All');

  const types = useMemo(() => ['All', ...Array.from(new Set(labor.map((l) => l.type).filter(Boolean))).sort()], [labor]);
  const phases = useMemo(() => ['All', ...Array.from(new Set(labor.map((l) => l.phase).filter(Boolean))).sort()], [labor]);

  const filtered = useMemo(() => {
    let df = labor;
    if (search) df = df.filter((l) => l.function.toLowerCase().indexOf(search.toLowerCase()) !== -1);
    if (projId) df = df.filter((l) => l.oppId.toLowerCase().indexOf(projId.toLowerCase()) !== -1);
    if (type !== 'All') df = df.filter((l) => l.type === type);
    if (phase !== 'All') df = df.filter((l) => l.phase === phase);
    return df;
  }, [labor, search, projId, type, phase]);

  const hh = filtered.map((l) => l.total_hh || 0).filter((v) => v > 0);
  const rates = filtered.map((l) => l.cost_rate || 0).filter((v) => v > 0);

  if (labor.length === 0) {
    return <p className="text-sm text-muted">No labor data available for this BID.</p>;
  }

  return (
    <div className="space-y-4">
      <div style={autoGrid(190)}>
        <Field label="Search function">
          <input className={INPUT_CLS} value={search} onChange={(e) => setSearch(e.target.value)} />
        </Field>
        <Field label="Filter by Project ID">
          <input className={INPUT_CLS} value={projId} onChange={(e) => setProjId(e.target.value)} />
        </Field>
        <Field label="Type">
          <select className={INPUT_CLS} value={type} onChange={(e) => setType(e.target.value)}>
            {types.map((t) => (<option key={t} value={t}>{t}</option>))}
          </select>
        </Field>
        <Field label="Phase">
          <select className={INPUT_CLS} value={phase} onChange={(e) => setPhase(e.target.value)}>
            {phases.map((p) => (<option key={p} value={p}>{p}</option>))}
          </select>
        </Field>
      </div>

      <StatGrid>
        <Stat label="Records" value={fmtNum(filtered.length)} />
        <Stat label="Total HH" value={hh.length ? fmtNum(hh.reduce((a, b) => a + b, 0)) : '—'} />
        <Stat label="Avg HH/Role" value={hh.length ? fmtNum(mean(hh), 1) : '—'} />
        <Stat label="Avg Rate" value={rates.length ? fmtUsd(mean(rates)) : '—'} />
      </StatGrid>

      <div className="border border-border rounded-none overflow-x-auto">
        <div style={{ minWidth: LABOR_MINW }}>
        <div style={tableGrid(LABOR_COLS, LABOR_MINW)} className="px-3 py-2 bg-deep/95 border-b border-border text-[9px] uppercase tracking-widest text-muted font-mono">
          <div>Function</div><div>Type</div><div>Phase</div><div>HH/Day</div><div>People</div><div>Days</div><div>Util.</div><div>Total HH</div><div>Rate</div><div>Curr.</div><div>BID</div>
        </div>
        <div className="max-h-[480px] overflow-y-auto">
          {filtered.slice(0, 400).map((l, i) => (
            <div key={i} style={{ ...tableGrid(LABOR_COLS, LABOR_MINW), alignItems: 'flex-start' }} className="px-3 py-1.5 border-b border-border-light text-[10px] text-light">
              <div style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }} title={l.function}>{l.function || '—'}</div>
              <div className="text-muted" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }}>{l.type || '—'}</div>
              <div className="text-muted" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }}>{l.phase || '—'}</div>
              <div className="font-mono">{l.hh_per_day ?? '—'}</div>
              <div className="font-mono">{l.people_qty ?? '—'}</div>
              <div className="font-mono">{l.days ?? '—'}</div>
              <div className="font-mono">{l.utilization ?? '—'}</div>
              <div className="font-mono text-gold">{l.total_hh ?? '—'}</div>
              <div className="font-mono">{l.cost_rate ?? '—'}</div>
              <div className="text-muted">{l.currency_original || '—'}</div>
              <div className="text-muted font-mono truncate">{l.oppId}</div>
            </div>
          ))}
        </div>
        </div>
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Root component
// ─────────────────────────────────────────────────────────────────────────────

type MainTab = 'bid' | 'history' | 'labor';

export const PriceHistory: React.FC = () => {
  const toast = useToast();
  const [tab, setTab] = useState<MainTab>('bid');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [cost, setCost] = useState<BenchItem[]>([]);
  const [opps, setOpps] = useState<OppInfo[]>([]);
  const [labor, setLabor] = useState<LaborRow[]>([]);
  const [supplyMap, setSupplyMap] = useState<Map<string, SupplyInfo>>(() => new Map());
  const [supplyRows, setSupplyRows] = useState<Array<Record<string, unknown>>>([]);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        setLoading(true);
        setError(null);
        const [ds, supplyRows] = await Promise.all([
          ApiClient.getBenchmarkDataset(),
          ApiClient.getSupplyIndex().catch(() => [] as Array<Record<string, unknown>>),
        ]);
        if (cancelled) return;
        setCost(normalizeCostRows(ds.cost));
        setOpps(normalizeOpportunities(ds.opportunities));
        setLabor(normalizeLaborRows(ds.labor));
        setSupplyRows(supplyRows);
        setSupplyMap(buildSupplyMap(supplyRows));
      } catch (err) {
        if (cancelled) return;
        const message = err instanceof Error ? err.message : 'Failed to load benchmark data';
        setError(message);
        toast.error(message);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const oppTitles = useMemo(() => buildOppTitleMap(opps), [opps]);

  const tabs: Array<{ key: MainTab; label: string }> = [
    { key: 'bid', label: 'Bid Ranking' },
    { key: 'history', label: 'Item History' },
    { key: 'labor', label: 'Labor' },
  ];

  return (
    <div className="space-y-6">
      <div className={TAB_ROW}>
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={tabCls(tab === t.key)}
          >
            {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <Loading />
      ) : error ? (
        <div className="text-red-400 text-sm border border-red-500/40 bg-red-500/5 p-4">{error}</div>
      ) : (
        <>
          {tab === 'bid' && <BidRankingTab cost={cost} opps={opps} oppTitles={oppTitles} />}
          {tab === 'history' && (
            <HistoryTab cost={cost} opps={opps} oppTitles={oppTitles} supplyMap={supplyMap} supplyRows={supplyRows} />
          )}
          {tab === 'labor' && <LaborTab labor={labor} />}
        </>
      )}
    </div>
  );
};
