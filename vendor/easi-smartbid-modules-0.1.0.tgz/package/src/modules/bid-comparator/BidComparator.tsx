import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ApiClient } from '../../adapters/ApiClient';
import { useToast, EmptyState } from '../../shared/ui';
import { BTN_LINK, BTN_PRIMARY, TAB_ROW, chipCls, tabCls } from '../../shared/ui/buttonClasses';
import { exportToXlsx } from '../../shared/utils/exporters';
import {
  ComparisonResult,
  CtrItem,
  MatchedItem,
  compareCtr,
  normalizeCtrItems,
} from '../../shared/utils/ctrComparator';

// ─────────────────────────────────────────────────────────────────────────────
// Shared styles / helpers (container-based layout, mirrors Modules 04/05/07)
// ─────────────────────────────────────────────────────────────────────────────

const INPUT_CLS =
  'w-full bg-surface border border-border rounded-none p-2.5 text-sm text-light placeholder-muted focus:border-steel outline-none';

const COLORS = {
  gold: '#ffc72c',
  teal: '#0097a9',
  steel: '#5b7f95',
  muted: '#5b7f95',
  green: '#1D9E75',
  red: '#E24B4A',
  amber: '#EF9F27',
  blue: '#3B8BD4',
  light: '#0d2430',
};

const autoGrid = (min: number): React.CSSProperties => ({
  display: 'grid',
  gap: '0.75rem',
  gridTemplateColumns: `repeat(auto-fit, minmax(${min}px, 1fr))`,
});

const StatGrid: React.FC<{ children: React.ReactNode; min?: number }> = ({ children, min = 140 }) => (
  <div style={autoGrid(min)}>{children}</div>
);

const Stat: React.FC<{ label: string; value: React.ReactNode; hint?: string; color?: string }> = ({
  label,
  value,
  hint,
  color,
}) => (
  <div
    className="rounded-none p-3 min-w-0"
    style={{
      background: '#ffffff',
      border: '1px solid #dfe6ec',
      borderRadius: 8,
      boxShadow: '0 1px 2px rgba(0,38,62,0.05), 0 4px 12px rgba(0,38,62,0.05)',
      borderTop: `2px solid ${color || COLORS.steel}`,
    }}
  >
    <div className="text-[10px] uppercase tracking-widest font-mono truncate" style={{ color: COLORS.muted }} title={label}>
      {label}
    </div>
    <div className="mt-1.5 font-mono font-semibold truncate" style={{ color: color || COLORS.light, fontSize: '1.05rem', lineHeight: 1.2 }}>
      {value}
    </div>
    {hint && (
      <div className="text-[10px] mt-0.5 truncate" style={{ color: COLORS.muted }}>
        {hint}
      </div>
    )}
  </div>
);

const fmtUsd = (n: number): string => `${n < 0 ? '-' : ''}$${Math.abs(Math.round(n)).toLocaleString('en-US')}`;
const fmtPct = (p: number): string => `${p >= 0 ? '+' : ''}${(p * 100).toFixed(1)}%`;
const varianceColor = (v: number | null): string =>
  v === null ? COLORS.muted : v > 0.1 ? COLORS.red : v < -0.05 ? COLORS.green : COLORS.amber;
const pctIcon = (p: number): string => (p > 0.15 ? '🔴' : p > 0.05 ? '🟡' : p < -0.05 ? '🟢' : '⚪');

// Table grid helpers (horizontal scroll + shared column templates)
const tableGrid = (cols: string, minWidth: number): React.CSSProperties => ({
  display: 'grid',
  gridTemplateColumns: cols,
  gap: '0.5rem',
  minWidth,
});

// Searchable single BID selector (combobox).
const BidSelect: React.FC<{
  value: string;
  onChange: (id: string) => void;
  bidIds: string[];
  oppTitles: Map<string, string>;
  placeholder?: string;
}> = ({ value, onChange, bidIds, oppTitles, placeholder = 'Select a BID…' }) => {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return undefined;
    const onDocClick = (e: MouseEvent): void => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', onDocClick);
    return () => document.removeEventListener('mousedown', onDocClick);
  }, [open]);

  const label = (id: string): string => `${id} — ${(oppTitles.get(id) || '').slice(0, 40)}`;
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return bidIds;
    return bidIds.filter((id) => label(id).toLowerCase().indexOf(q) !== -1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bidIds, oppTitles, query]);

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={() => {
          setOpen((o) => !o);
          setQuery('');
        }}
        className={`${INPUT_CLS} flex items-center justify-between text-left`}
      >
        <span className="truncate">{value ? label(value) : placeholder}</span>
        <span className="text-muted ml-2 shrink-0">▾</span>
      </button>
      {open && (
        <div className="absolute z-30 mt-1 w-full border border-border rounded-none" style={{ background: '#ffffff', boxShadow: '0 8px 24px rgba(0,38,62,0.12)' }}>
          <div className="p-2 border-b border-border">
            <input autoFocus className={INPUT_CLS} value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search BID or project…" />
          </div>
          <div className="max-h-60 overflow-y-auto">
            {filtered.length === 0 ? (
              <div className="px-3 py-2 text-xs text-muted">No BID found.</div>
            ) : (
              filtered.map((id) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => {
                    onChange(id);
                    setOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 text-xs truncate transition ${id === value ? 'bg-navy/60 text-gold' : 'text-light hover:bg-navy/40'}`}
                  title={label(id)}
                >
                  {label(id)}
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};

// Searchable multi BID selector (dropdown + checkbox list + chips).
const MultiBidSelect: React.FC<{
  values: string[];
  onToggle: (id: string) => void;
  onClear: () => void;
  bidIds: string[];
  oppTitles: Map<string, string>;
}> = ({ values, onToggle, onClear, bidIds, oppTitles }) => {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return undefined;
    const onDocClick = (e: MouseEvent): void => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', onDocClick);
    return () => document.removeEventListener('mousedown', onDocClick);
  }, [open]);

  const label = (id: string): string => `${id} — ${(oppTitles.get(id) || '').slice(0, 40)}`;
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return bidIds;
    return bidIds.filter((id) => label(id).toLowerCase().indexOf(q) !== -1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bidIds, oppTitles, query]);

  return (
    <div className="space-y-2">
      <div className="relative" ref={ref}>
        <button
          type="button"
          onClick={() => {
            setOpen((o) => !o);
            setQuery('');
          }}
          className={`${INPUT_CLS} flex items-center justify-between text-left`}
        >
          <span className="truncate" style={{ color: values.length ? COLORS.light : COLORS.muted }}>
            {values.length ? `${values.length} historical bid(s) selected` : 'Select historical BIDs…'}
          </span>
          <span className="ml-2 shrink-0" style={{ color: COLORS.muted }}>▾</span>
        </button>
        {open && (
          <div className="absolute z-30 mt-1 w-full border border-border rounded-none" style={{ background: '#ffffff', boxShadow: '0 8px 24px rgba(0,38,62,0.12)' }}>
            <div className="p-2 border-b border-border">
              <input autoFocus className={INPUT_CLS} value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search historical BIDs…" />
            </div>
            <div className="max-h-64 overflow-y-auto py-1">
              {filtered.length === 0 ? (
                <div className="px-3 py-2 text-xs" style={{ color: COLORS.muted }}>No BID found.</div>
              ) : (
                filtered.map((id) => {
                  const on = values.indexOf(id) !== -1;
                  return (
                    <label
                      key={id}
                      className="flex items-center gap-2 px-3 py-2 text-xs cursor-pointer transition"
                      style={{ background: on ? 'rgba(0,151,169,0.18)' : 'transparent', color: on ? COLORS.teal : COLORS.light }}
                      onMouseEnter={(e) => {
                        if (!on) (e.currentTarget as HTMLElement).style.background = 'rgba(91,127,149,0.18)';
                      }}
                      onMouseLeave={(e) => {
                        if (!on) (e.currentTarget as HTMLElement).style.background = 'transparent';
                      }}
                      title={label(id)}
                    >
                      <input type="checkbox" checked={on} onChange={() => onToggle(id)} className="accent-teal shrink-0" />
                      <span className="truncate">{label(id)}</span>
                    </label>
                  );
                })
              )}
            </div>
          </div>
        )}
      </div>

      {values.length > 0 && (
        <div className="flex flex-wrap gap-1.5 items-center">
          {values.map((id) => (
            <span
              key={id}
              className="inline-flex items-center gap-1 px-2 py-0.5 text-xs font-mono border"
              style={{ background: 'rgba(0,151,169,0.15)', borderColor: 'rgba(0,151,169,0.5)', color: COLORS.teal }}
              title={label(id)}
            >
              <span className="truncate" style={{ maxWidth: 220 }}>{label(id)}</span>
              <button type="button" onClick={() => onToggle(id)} className="shrink-0" style={{ color: COLORS.teal }} title="Remove">
                ✕
              </button>
            </span>
          ))}
          <button type="button" onClick={onClear} className={`ml-1 ${BTN_LINK}`}>
            Clear all
          </button>
        </div>
      )}
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Tabs
// ─────────────────────────────────────────────────────────────────────────────
type TabKey = 'exec' | 'changes' | 'scope' | 'full' | 'export';
const TABS: { key: TabKey; label: string }[] = [
  { key: 'exec', label: 'Executive View' },
  { key: 'changes', label: 'Price Changes' },
  { key: 'scope', label: 'Scope Changes' },
  { key: 'full', label: 'Full Comparison' },
  { key: 'export', label: 'Export' },
];

const CHILD_MODELS = new Set(['certif_cap', 'transit_ope', 'certif. (cap)', 'transit (ope)']);

// ── Executive view ────────────────────────────────────────────────────────────
const InsightRow: React.FC<{ children: React.ReactNode; color: string; bg: string }> = ({ children, color, bg }) => (
  <div className="text-xs px-3 py-2 my-1" style={{ background: bg, borderLeft: `3px solid ${color}` }}>
    {children}
  </div>
);

const ExecutiveView: React.FC<{ result: ComparisonResult }> = ({ result }) => {
  const increased = useMemo(
    () =>
      result.matched
        .filter((m) => m.priceDeltaPct > 0.05)
        .sort((a, b) => Math.abs(b.unitPriceNew - b.unitPriceHist) - Math.abs(a.unitPriceNew - a.unitPriceHist)),
    [result]
  );
  const decreased = useMemo(
    () =>
      result.matched
        .filter((m) => m.priceDeltaPct < -0.05)
        .sort((a, b) => Math.abs(b.unitPriceNew - b.unitPriceHist) - Math.abs(a.unitPriceNew - a.unitPriceHist)),
    [result]
  );
  const modelChanges = useMemo(
    () =>
      result.matched.filter(
        (m) =>
          m.pricingModelNew &&
          m.pricingModelHist &&
          m.pricingModelNew.toLowerCase() !== m.pricingModelHist.toLowerCase() &&
          !CHILD_MODELS.has(m.pricingModelNew.toLowerCase()) &&
          !CHILD_MODELS.has(m.pricingModelHist.toLowerCase())
      ),
    [result]
  );
  const newSorted = useMemo(() => [...result.newItems].sort((a, b) => b.unitPrice - a.unitPrice), [result]);
  const newCost = useMemo(() => result.newItems.reduce((s, n) => s + n.unitPrice, 0), [result]);
  const missCost = useMemo(() => result.missing.reduce((s, m) => s + m.unitPrice, 0), [result]);

  return (
    <div className="space-y-4">
      <p className="text-sm font-semibold text-light">Key insights for decision-making</p>

      {increased.length > 0 && (
        <div>
          <p className="text-xs text-red-400 font-semibold mb-1">Biggest cost increases vs previous bid</p>
          {increased.slice(0, 5).map((m, i) => (
            <InsightRow key={i} color={COLORS.red} bg="rgba(162,45,45,0.12)">
              <span className="text-light font-semibold">{m.description.slice(0, 60)}</span>{' '}
              <span className="font-mono" style={{ color: COLORS.red }}>{fmtPct(m.priceDeltaPct)}</span>{' '}
              <span className="text-muted text-[10px]">({fmtUsd(m.unitPriceHist)} → {fmtUsd(m.unitPriceNew)}, Δ {fmtUsd(m.priceDeltaUsd)})</span>
            </InsightRow>
          ))}
        </div>
      )}

      {decreased.length > 0 && (
        <div>
          <p className="text-xs text-green-400 font-semibold mb-1">Biggest cost savings vs previous bid</p>
          {decreased.slice(0, 5).map((m, i) => (
            <InsightRow key={i} color={COLORS.green} bg="rgba(29,158,117,0.1)">
              <span className="text-light font-semibold">{m.description.slice(0, 60)}</span>{' '}
              <span className="font-mono" style={{ color: COLORS.green }}>{fmtPct(m.priceDeltaPct)}</span>{' '}
              <span className="text-muted text-[10px]">({fmtUsd(m.unitPriceHist)} → {fmtUsd(m.unitPriceNew)}, Δ {fmtUsd(m.priceDeltaUsd)})</span>
            </InsightRow>
          ))}
        </div>
      )}

      {modelChanges.length > 0 && (
        <div>
          <p className="text-xs text-amber-400 font-semibold mb-1">Pricing model changes (commercial strategy shifted)</p>
          {modelChanges.map((m, i) => (
            <InsightRow key={i} color={COLORS.amber} bg="rgba(239,159,39,0.1)">
              <span className="text-light font-semibold">{m.description.slice(0, 55)}</span> — was{' '}
              <span className="text-light">{m.pricingModelHist}</span>, now <span className="text-light">{m.pricingModelNew}</span>
            </InsightRow>
          ))}
        </div>
      )}

      {result.newItems.length > 0 && (
        <div>
          <p className="text-xs font-semibold mb-1" style={{ color: COLORS.blue }}>
            New scope items (not in previous bid) — {fmtUsd(newCost)} total
          </p>
          {newSorted.slice(0, 6).map((n, i) => (
            <InsightRow key={i} color={COLORS.blue} bg="rgba(0,55,90,0.2)">
              <span className="text-light">{n.description.slice(0, 65)}</span>{' '}
              <span className="font-mono" style={{ color: COLORS.gold }}>{fmtUsd(n.unitPrice)}</span>
            </InsightRow>
          ))}
        </div>
      )}

      {result.missing.length > 0 && (
        <div>
          <p className="text-xs font-semibold mb-1" style={{ color: COLORS.amber }}>
            Items in previous bid but NOT in new CTR — {fmtUsd(missCost)} potential gap
          </p>
          {result.missing.slice(0, 5).map((m, i) => (
            <InsightRow key={i} color={COLORS.amber} bg="rgba(200,80,0,0.08)">
              <span className="text-light">{m.description.slice(0, 65)}</span>{' '}
              <span className="font-mono" style={{ color: COLORS.amber }}>{fmtUsd(m.unitPrice)} (historical)</span>
            </InsightRow>
          ))}
        </div>
      )}

      {increased.length === 0 && decreased.length === 0 && modelChanges.length === 0 && result.newItems.length === 0 && result.missing.length === 0 && (
        <EmptyState title="No notable changes" description="Matched items are priced within ±5% and scope is identical." />
      )}
    </div>
  );
};

// ── Price changes ─────────────────────────────────────────────────────────────
type ChangeFilter = 'all' | 'inc' | 'dec' | 'model';
const CHANGE_COLS = '2.4fr 1.1fr 1fr 1fr 1fr 0.8fr 1fr 1fr';
const CHANGE_MINW = 860;

const PriceChanges: React.FC<{ result: ComparisonResult }> = ({ result }) => {
  const [filter, setFilter] = useState<ChangeFilter>('all');
  const rows = useMemo(() => {
    const sorted = [...result.matched].sort((a, b) => Math.abs(b.priceDeltaPct) - Math.abs(a.priceDeltaPct));
    if (filter === 'inc') return sorted.filter((m) => m.priceDeltaUsd > 0);
    if (filter === 'dec') return sorted.filter((m) => m.priceDeltaUsd < 0);
    if (filter === 'model') return sorted.filter((m) => (m.pricingModelHist || '') !== (m.pricingModelNew || ''));
    return sorted;
  }, [result, filter]);

  if (result.matched.length === 0) return <EmptyState title="No matched items" description="Nothing matched between the CTRs." />;

  const filters: { k: ChangeFilter; label: string }[] = [
    { k: 'all', label: 'All' },
    { k: 'inc', label: 'Increases' },
    { k: 'dec', label: 'Decreases' },
    { k: 'model', label: 'Model changes' },
  ];

  return (
    <div className="space-y-3">
      <div className={TAB_ROW}>
        {filters.map((f) => (
          <button
            key={f.k}
            onClick={() => setFilter(f.k)}
            className={chipCls(filter === f.k)}
          >
            {f.label}
          </button>
        ))}
      </div>
      <div className="overflow-x-auto border border-border">
        <div style={tableGrid(CHANGE_COLS, CHANGE_MINW)} className="px-3 py-2 text-[10px] uppercase tracking-widest font-mono text-muted border-b border-border">
          <span>Description</span>
          <span>Category</span>
          <span className="text-right">Historical</span>
          <span className="text-right">New</span>
          <span className="text-right">Delta $</span>
          <span className="text-right">Delta %</span>
          <span>Model old</span>
          <span>Model new</span>
        </div>
        {rows.map((m, i) => (
          <div key={i} style={tableGrid(CHANGE_COLS, CHANGE_MINW)} className="px-3 py-2 text-xs border-b border-border/40 items-start">
            <span className="text-light" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }} title={m.description}>{m.description}</span>
            <span className="text-muted" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }} title={m.category}>{m.category || '—'}</span>
            <span className="text-right font-mono text-muted">{fmtUsd(m.unitPriceHist)}</span>
            <span className="text-right font-mono text-light">{fmtUsd(m.unitPriceNew)}</span>
            <span className="text-right font-mono" style={{ color: m.priceDeltaUsd > 0 ? COLORS.red : m.priceDeltaUsd < 0 ? COLORS.green : COLORS.muted }}>{fmtUsd(m.priceDeltaUsd)}</span>
            <span className="text-right font-mono" style={{ color: m.priceDeltaPct > 0 ? COLORS.red : m.priceDeltaPct < 0 ? COLORS.green : COLORS.muted }}>{fmtPct(m.priceDeltaPct)}</span>
            <span className="text-muted" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }}>{m.pricingModelHist || '—'}</span>
            <span className="text-muted" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }}>{m.pricingModelNew || '—'}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

// ── Scope changes ─────────────────────────────────────────────────────────────
const SCOPE_COLS = '2.4fr 1fr 1fr 1fr';
const SCOPE_MINW = 460;

const ScopeChanges: React.FC<{ result: ComparisonResult }> = ({ result }) => (
  <div style={autoGrid(460)}>
    <div className="space-y-2">
      <p className="text-xs font-semibold" style={{ color: COLORS.blue }}>New items — not in previous bid ({result.newItems.length})</p>
      {result.newItems.length === 0 ? (
        <div className="text-xs text-green-400">No new items — scope is identical.</div>
      ) : (
        <div className="overflow-x-auto border border-border">
          <div style={tableGrid(SCOPE_COLS, SCOPE_MINW)} className="px-3 py-2 text-[10px] uppercase tracking-widest font-mono text-muted border-b border-border">
            <span>Description</span>
            <span>PN</span>
            <span className="text-right">Price</span>
            <span>Model</span>
          </div>
          {result.newItems.map((n, i) => (
            <div key={i} style={tableGrid(SCOPE_COLS, SCOPE_MINW)} className="px-3 py-2 text-xs border-b border-border/40 items-start">
              <span className="text-light" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }} title={n.description}>{n.description}</span>
              <span className="text-muted font-mono" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }}>{n.pn || '—'}</span>
              <span className="text-right font-mono text-gold">{fmtUsd(n.unitPrice)}</span>
              <span className="text-muted" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }}>{n.pricingModel || '—'}</span>
            </div>
          ))}
        </div>
      )}
    </div>

    <div className="space-y-2">
      <p className="text-xs font-semibold" style={{ color: COLORS.amber }}>Removed items — were in previous bid ({result.missing.length})</p>
      {result.missing.length === 0 ? (
        <div className="text-xs text-green-400">Nothing removed — scope is identical.</div>
      ) : (
        <div className="overflow-x-auto border border-border">
          <div style={tableGrid(SCOPE_COLS, SCOPE_MINW)} className="px-3 py-2 text-[10px] uppercase tracking-widest font-mono text-muted border-b border-border">
            <span>Description</span>
            <span>PN</span>
            <span className="text-right">Historical</span>
            <span>Model</span>
          </div>
          {result.missing.map((m, i) => (
            <div key={i} style={tableGrid(SCOPE_COLS, SCOPE_MINW)} className="px-3 py-2 text-xs border-b border-border/40 items-start">
              <span className="text-light" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }} title={m.description}>{m.description}</span>
              <span className="text-muted font-mono" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }}>{m.pn || '—'}</span>
              <span className="text-right font-mono text-muted">{fmtUsd(m.unitPrice)}</span>
              <span className="text-muted" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }}>{m.pricingModel || '—'}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  </div>
);

// ── Full comparison ───────────────────────────────────────────────────────────
const FULL_COLS = '1fr 2.4fr 1fr 1fr 1fr 1fr 1.4fr';
const FULL_MINW = 900;

const FullComparison: React.FC<{ result: ComparisonResult }> = ({ result }) => {
  const rows = useMemo(() => {
    const out: React.ReactNode[] = [];
    result.matched.forEach((m, i) => {
      const modelStr =
        m.pricingModelNew && m.pricingModelHist && m.pricingModelNew !== m.pricingModelHist
          ? `${m.pricingModelHist} → ${m.pricingModelNew}`
          : m.pricingModelNew || '—';
      out.push(
        <div key={`m${i}`} style={tableGrid(FULL_COLS, FULL_MINW)} className="px-3 py-2 text-xs border-b border-border/40 items-start">
          <span className="text-green-400">✅ Matched</span>
          <span className="text-light" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }} title={m.description}>{m.description}</span>
          <span className="text-muted font-mono" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }}>{m.pn || '—'}</span>
          <span className="text-right font-mono text-muted">{fmtUsd(m.unitPriceHist)}</span>
          <span className="text-right font-mono text-light">{fmtUsd(m.unitPriceNew)}</span>
          <span className="font-mono" style={{ color: m.priceDeltaPct > 0 ? COLORS.red : m.priceDeltaPct < 0 ? COLORS.green : COLORS.muted }}>{pctIcon(m.priceDeltaPct)} {fmtPct(m.priceDeltaPct)}</span>
          <span className="text-muted" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }} title={modelStr}>{modelStr}</span>
        </div>
      );
    });
    result.newItems.forEach((n, i) => {
      out.push(
        <div key={`n${i}`} style={tableGrid(FULL_COLS, FULL_MINW)} className="px-3 py-2 text-xs border-b border-border/40 items-start">
          <span style={{ color: COLORS.blue }}>🆕 New item</span>
          <span className="text-light" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }} title={n.description}>{n.description}</span>
          <span className="text-muted font-mono" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }}>{n.pn || '—'}</span>
          <span className="text-right font-mono text-muted">—</span>
          <span className="text-right font-mono text-light">{fmtUsd(n.unitPrice)}</span>
          <span className="font-mono" style={{ color: COLORS.blue }}>new</span>
          <span className="text-muted" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }}>{n.pricingModel || '—'}</span>
        </div>
      );
    });
    result.missing.forEach((ms, i) => {
      out.push(
        <div key={`x${i}`} style={tableGrid(FULL_COLS, FULL_MINW)} className="px-3 py-2 text-xs border-b border-border/40 items-start">
          <span style={{ color: COLORS.amber }}>⚠️ Removed</span>
          <span className="text-light" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }} title={ms.description}>{ms.description}</span>
          <span className="text-muted font-mono" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }}>{ms.pn || '—'}</span>
          <span className="text-right font-mono text-muted">{fmtUsd(ms.unitPrice)}</span>
          <span className="text-right font-mono text-muted">—</span>
          <span className="font-mono" style={{ color: COLORS.amber }}>removed</span>
          <span className="text-muted" style={{ whiteSpace: 'normal', overflowWrap: 'anywhere' }}>{ms.pricingModel || '—'}</span>
        </div>
      );
    });
    return out;
  }, [result]);

  if (rows.length === 0) return <EmptyState title="No items to display" description="Run a comparison first." />;

  return (
    <div className="overflow-x-auto border border-border">
      <div style={tableGrid(FULL_COLS, FULL_MINW)} className="px-3 py-2 text-[10px] uppercase tracking-widest font-mono text-muted border-b border-border">
        <span>Status</span>
        <span>Description</span>
        <span>PN</span>
        <span className="text-right">Hist.</span>
        <span className="text-right">New</span>
        <span>Delta</span>
        <span>Model</span>
      </div>
      {rows}
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Page
// ─────────────────────────────────────────────────────────────────────────────
export const BidComparator: React.FC = () => {
  const toast = useToast();

  const [loadingData, setLoadingData] = useState(true);
  const [dataError, setDataError] = useState<string | null>(null);
  const [allCost, setAllCost] = useState<CtrItem[]>([]);
  const [oppTitles, setOppTitles] = useState<Map<string, string>>(new Map());

  const [newBid, setNewBid] = useState('');
  const [histBids, setHistBids] = useState<string[]>([]);
  const [threshold, setThreshold] = useState(75); // percent, mirrors Python default
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<ComparisonResult | null>(null);
  const [tab, setTab] = useState<TabKey>('exec');

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        setLoadingData(true);
        setDataError(null);
        const [cost, opps] = await Promise.all([ApiClient.getCostElementsRaw(), ApiClient.getOpportunitiesRaw()]);
        if (cancelled) return;
        setAllCost(normalizeCtrItems(cost));
        const titles = new Map<string, string>();
        for (const o of opps || []) {
          const id = String(o.opportunity_id ?? '').trim();
          if (id) titles.set(id, String(o.title ?? o.project ?? '').trim());
        }
        setOppTitles(titles);
      } catch (err) {
        if (!cancelled) setDataError(err instanceof Error ? err.message : 'Failed to load data');
      } finally {
        if (!cancelled) setLoadingData(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const bidIds = useMemo(() => {
    const set = new Set<string>();
    for (const c of allCost) if (c.oppId) set.add(c.oppId);
    return Array.from(set).sort().reverse();
  }, [allCost]);

  const histOptions = useMemo(() => bidIds.filter((id) => id !== newBid), [bidIds, newBid]);
  const newCount = useMemo(() => (newBid ? allCost.filter((c) => c.oppId === newBid).length : 0), [allCost, newBid]);

  const toggleHist = (id: string): void => setHistBids((prev) => (prev.indexOf(id) !== -1 ? prev.filter((x) => x !== id) : [...prev, id]));

  const handleCompare = (): void => {
    if (!newBid) {
      toast.error('Select the new CTR first');
      return;
    }
    if (histBids.length === 0) {
      toast.error('Select at least one historical CTR');
      return;
    }
    setRunning(true);
    try {
      const newCost = allCost.filter((c) => c.oppId === newBid);
      const histSet = new Set(histBids);
      const histCost = allCost.filter((c) => histSet.has(c.oppId));
      const res = compareCtr(newCost, histCost, newBid, histBids, threshold / 100);
      setResult(res);
      setTab('exec');
      toast.success('Comparison complete');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Comparison failed');
    } finally {
      setRunning(false);
    }
  };

  const handleExport = (): void => {
    if (!result) return;
    const rows: Record<string, string | number>[] = [];
    result.matched.forEach((m) =>
      rows.push({
        Status: 'Matched',
        Description: m.description,
        PN: m.pn,
        Category: m.category,
        Historical: Math.round(m.unitPriceHist),
        New: Math.round(m.unitPriceNew),
        DeltaUSD: Math.round(m.priceDeltaUsd),
        DeltaPct: fmtPct(m.priceDeltaPct),
        ModelHistorical: m.pricingModelHist,
        ModelNew: m.pricingModelNew,
      })
    );
    result.newItems.forEach((n) =>
      rows.push({ Status: 'New', Description: n.description, PN: n.pn, Category: n.category, Historical: '', New: Math.round(n.unitPrice), DeltaUSD: '', DeltaPct: '', ModelHistorical: '', ModelNew: n.pricingModel })
    );
    result.missing.forEach((m) =>
      rows.push({ Status: 'Removed', Description: m.description, PN: m.pn, Category: m.category, Historical: Math.round(m.unitPrice), New: '', DeltaUSD: '', DeltaPct: '', ModelHistorical: m.pricingModel, ModelNew: '' })
    );
    exportToXlsx(rows, `CTR_Comparison_${newBid.replace(/[\\/]/g, '_')}`, 'Comparison');
    toast.success('Comparison exported');
  };

  const variance = result?.priceVariancePct ?? null;
  const incCount = useMemo(() => (result ? result.matched.filter((m) => m.priceDeltaPct > 0.05).length : 0), [result]);
  const decCount = useMemo(() => (result ? result.matched.filter((m) => m.priceDeltaPct < -0.05).length : 0), [result]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <p className="text-xs uppercase tracking-widest text-gold opacity-85">Module 08</p>
        <h1 className="text-2xl font-semibold text-light mt-2">CTR Comparator</h1>
      </div>

      {/* Info */}
      <div className="p-4 bg-surface border border-border text-sm text-muted">
        Compare a new CTR against one or more historical bids. See where you saved, where you spent more, and what changed in
        scope. Item matching uses exact part numbers and description similarity.
      </div>

      {dataError && <div className="text-red-500 text-sm">{dataError}</div>}
      {loadingData ? (
        <div className="text-sm text-muted">Loading CTR history…</div>
      ) : (
        <>
          {/* Step 1 */}
          <div className="space-y-3">
            <div className="text-xs uppercase tracking-widest text-muted font-mono border-b border-border pb-1">
              Step 1 — New CTR (the bid you're quoting now)
            </div>
            <div style={autoGrid(260)}>
              <div>
                <label className="block text-xs uppercase tracking-widest text-muted mb-1.5 font-mono">New CTR (from history)</label>
                <BidSelect value={newBid} onChange={setNewBid} bidIds={bidIds} oppTitles={oppTitles} />
              </div>
              <div>
                <label className="block text-xs uppercase tracking-widest text-muted mb-1.5 font-mono">Fuzzy threshold — {threshold}%</label>
                <input type="range" min={50} max={95} step={5} value={threshold} onChange={(e) => setThreshold(Number(e.target.value))} className="w-full accent-gold" />
                <div className="text-[10px] text-muted mt-1">Minimum description similarity to match items across CTRs.</div>
              </div>
            </div>
            {newBid && <div className="text-xs text-teal">Loaded {newBid} — {newCount} cost item(s).</div>}
          </div>

          {/* Step 2 */}
          {newBid && (
            <div className="space-y-3">
              <div className="text-xs uppercase tracking-widest text-muted font-mono border-b border-border pb-1">
                Step 2 — Historical CTR(s) (previous similar bids)
              </div>
              <MultiBidSelect values={histBids} onToggle={toggleHist} onClear={() => setHistBids([])} bidIds={histOptions} oppTitles={oppTitles} />
              {histBids.length > 0 && <div className="text-xs text-muted">{histBids.length} historical bid(s) selected as baseline.</div>}
            </div>
          )}

          {/* Step 3 */}
          {newBid && histBids.length > 0 && (
            <button
              onClick={handleCompare}
              disabled={running}
              className={BTN_PRIMARY}
            >
              {running ? 'Comparing…' : 'Compare now'}
            </button>
          )}

          {/* Results */}
          {result && (
            <div className="space-y-5">
              {/* Decision summary headline */}
              <div style={{ background: '#ffffff', border: '1px solid #dfe6ec', borderTop: `3px solid ${varianceColor(variance)}` }} className="p-4">
                <div className="text-[10px] uppercase tracking-widest font-mono mb-2" style={{ color: COLORS.muted }}>
                  {result.oppNew} vs {result.oppsHist.join(', ')}
                </div>
                <div style={autoGrid(220)} className="items-center">
                  <div>
                    <div className="font-mono font-medium" style={{ color: varianceColor(variance), fontSize: '1.75rem' }}>
                      {variance === null ? '—' : fmtPct(variance)}
                    </div>
                    <div className="text-[11px]" style={{ color: COLORS.muted }}>Total cost variance</div>
                  </div>
                  <div>
                    <div className="text-xs" style={{ color: COLORS.light }}>
                      New total: <strong style={{ color: COLORS.gold }}>{fmtUsd(result.totalNewUsd)}</strong> · Historical:{' '}
                      <strong style={{ color: COLORS.muted }}>{fmtUsd(result.totalHistUsd)}</strong>
                    </div>
                    <div className="text-[11px] mt-1" style={{ color: COLORS.muted }}>
                      {result.matched.length} matched · {result.newItems.length} new scope · {result.missing.length} removed
                    </div>
                  </div>
                </div>
              </div>

              {/* Quick metrics */}
              <StatGrid min={140}>
                <Stat label="Matched items" value={result.matched.length} />
                <Stat label="Price increases" value={incCount} color={COLORS.red} hint="> +5%" />
                <Stat label="Price decreases" value={decCount} color={COLORS.green} hint="< -5%" />
                <Stat label="New scope items" value={result.newItems.length} color={COLORS.blue} />
                <Stat label="Removed items" value={result.missing.length} color={COLORS.amber} />
              </StatGrid>

              {/* Tabs */}
              <div className={TAB_ROW}>
                {TABS.map((t) => (
                  <button
                    key={t.key}
                    onClick={() => setTab(t.key)}
                    className={tabCls(tab === t.key)}
                  >
                    {t.label}
                  </button>
                ))}
              </div>

              <div>
                {tab === 'exec' && <ExecutiveView result={result} />}
                {tab === 'changes' && <PriceChanges result={result} />}
                {tab === 'scope' && <ScopeChanges result={result} />}
                {tab === 'full' && <FullComparison result={result} />}
                {tab === 'export' && (
                  <div className="space-y-3">
                    <p className="text-sm text-muted">Export the full comparison (matched, new and removed items) to Excel.</p>
                    <StatGrid min={140}>
                      <Stat label="Cost items (new)" value={newCount} />
                      <Stat label="Matched" value={result.matched.length} />
                      <Stat label="New" value={result.newItems.length} color={COLORS.blue} />
                      <Stat label="Removed" value={result.missing.length} color={COLORS.amber} />
                    </StatGrid>
                    <button onClick={handleExport} className={BTN_PRIMARY}>
                      Generate Excel
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};
