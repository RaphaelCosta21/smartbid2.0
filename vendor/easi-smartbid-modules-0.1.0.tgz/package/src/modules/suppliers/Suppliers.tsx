import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ApiClient } from '../../adapters/ApiClient';
import { useToast, Loading, ErrorState, EmptyState } from '../../shared/ui';
import { exportToXlsx } from '../../shared/utils/exporters';
import type { QuoteListItem } from '../../shared/types';
import {
  DEFAULT_CATEGORIES,
  Supplier,
  SupplierContact,
  Quotation,
  listSuppliers,
  createSupplier,
  updateSupplier,
  deleteSupplier,
  addQuotation,
  updateQuotation,
  removeQuotation,
  getStats,
  newQuotationId,
  findByName,
  isQuoteItemImported,
  search as searchCatalog,
} from '../../shared/utils/supplierStore';

// ─────────────────────────────────────────────────────────────────────────────
// Shared styles / helpers (mirrors Monte Carlo / other modules)
// ─────────────────────────────────────────────────────────────────────────────
const COLORS = {
  gold: '#ffc72c',
  teal: '#0097a9',
  steel: '#5b7f95',
  muted: '#5b7f95',
  green: '#1D9E75',
  red: '#E24B4A',
  amber: '#EF9F27',
  light: '#0d2430',
};

const CARD: React.CSSProperties = { background: '#ffffff', border: '1px solid #dfe6ec', borderRadius: 12, boxShadow: '0 1px 2px rgba(0,38,62,0.05), 0 4px 12px rgba(0,38,62,0.05)' };
const PANEL: React.CSSProperties = { background: '#f4f7f9', border: '1px solid #eaeff3', borderRadius: 8 };
const INPUT: React.CSSProperties = {
  width: '100%',
  background: '#ffffff',
  border: '1px solid #dfe6ec',
  color: COLORS.light,
  padding: '0.5rem 0.6rem',
  fontSize: '0.8rem',
  borderRadius: 8,
  outline: 'none',
};

const autoGrid = (min: number): React.CSSProperties => ({
  display: 'grid',
  gap: '0.75rem',
  gridTemplateColumns: `repeat(auto-fit, minmax(${min}px, 1fr))`,
});

// Accepted file types for a quotation upload (read by the cloud flow).
const QUOTE_UPLOAD_ACCEPT = '.pdf,.xlsx,.xls,.docx,.doc,.png,.jpg,.jpeg,.csv';

const fmtMoney = (n: number | null | undefined, ccy?: string): string => {
  if (n === null || n === undefined || !Number.isFinite(n)) return '—';
  return `${ccy ? ccy + ' ' : ''}${Math.round(n).toLocaleString('en-US')}`;
};

const Stat: React.FC<{ label: string; value: React.ReactNode; color?: string }> = ({ label, value, color }) => (
  <div className="p-3 min-w-0" style={{ ...CARD, borderTop: `2px solid ${color || COLORS.steel}` }}>
    <div className="text-[10px] uppercase tracking-widest font-mono truncate" style={{ color: COLORS.muted }}>
      {label}
    </div>
    <div className="mt-1.5 font-mono font-semibold truncate" style={{ color: color || COLORS.light, fontSize: '1.15rem' }}>
      {value}
    </div>
  </div>
);

const Label: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <label className="block text-[10px] uppercase tracking-widest font-mono mb-1" style={{ color: COLORS.muted }}>
    {children}
  </label>
);

const Btn: React.FC<{
  children: React.ReactNode;
  onClick?: () => void;
  kind?: 'primary' | 'ghost' | 'danger';
  disabled?: boolean;
  small?: boolean;
}> = ({ children, onClick, kind = 'ghost', disabled, small }) => {
  const styles: Record<string, React.CSSProperties> = {
    primary: { background: COLORS.gold, color: '#01141f', border: '1px solid ' + COLORS.gold },
    ghost: { background: 'transparent', color: COLORS.light, border: '1px solid rgba(91,127,149,0.4)' },
    danger: { background: 'transparent', color: COLORS.red, border: '1px solid rgba(226,75,74,0.5)' },
  };
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="font-mono uppercase tracking-widest transition"
      style={{
        ...styles[kind],
        padding: small ? '0.3rem 0.6rem' : '0.5rem 0.9rem',
        fontSize: small ? '0.65rem' : '0.72rem',
        opacity: disabled ? 0.45 : 1,
        cursor: disabled ? 'not-allowed' : 'pointer',
      }}
    >
      {children}
    </button>
  );
};

const Chip: React.FC<{ children: React.ReactNode; color?: string }> = ({ children, color }) => (
  <span
    className="inline-block font-mono"
    style={{
      fontSize: '0.62rem',
      padding: '0.1rem 0.45rem',
      color: color || COLORS.teal,
      border: `1px solid ${color || COLORS.teal}55`,
      background: (color || COLORS.teal) + '14',
    }}
  >
    {children}
  </span>
);

// Multi-select of categories (chips toggle) + custom add.
const CategoryPicker: React.FC<{
  selected: string[];
  onChange: (cats: string[]) => void;
  extra?: string[];
}> = ({ selected, onChange, extra = [] }) => {
  const [custom, setCustom] = useState('');
  const all = useMemo(() => {
    const set = new Set<string>([...DEFAULT_CATEGORIES, ...extra, ...selected]);
    return Array.from(set);
  }, [extra, selected]);
  const toggle = (c: string): void =>
    onChange(selected.indexOf(c) !== -1 ? selected.filter((x) => x !== c) : [...selected, c]);
  return (
    <div>
      <div className="flex flex-wrap gap-1.5">
        {all.map((c) => {
          const on = selected.indexOf(c) !== -1;
          return (
            <button
              key={c}
              type="button"
              onClick={() => toggle(c)}
              className="font-mono transition"
              style={{
                fontSize: '0.65rem',
                padding: '0.2rem 0.55rem',
                color: on ? '#01141f' : COLORS.light,
                background: on ? COLORS.teal : 'transparent',
                border: `1px solid ${on ? COLORS.teal : 'rgba(91,127,149,0.4)'}`,
              }}
            >
              {c}
            </button>
          );
        })}
      </div>
      <div className="flex gap-2 mt-2">
        <input
          style={INPUT}
          placeholder="New category…"
          value={custom}
          onChange={(e) => setCustom(e.target.value)}
        />
        <Btn
          small
          onClick={() => {
            const v = custom.trim();
            if (v && selected.indexOf(v) === -1) onChange([...selected, v]);
            setCustom('');
          }}
        >
          Add
        </Btn>
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Add / Edit supplier form
// ─────────────────────────────────────────────────────────────────────────────
interface SupplierFormValue {
  name: string;
  categories: string[];
  country: string;
  contacts: SupplierContact[];
  notes: string;
}

const emptyForm = (): SupplierFormValue => ({
  name: '',
  categories: [],
  country: '',
  contacts: [{ name: '', email: '', phone: '' }],
  notes: '',
});

const SupplierForm: React.FC<{
  value: SupplierFormValue;
  onChange: (v: SupplierFormValue) => void;
  onSubmit: () => void;
  onCancel?: () => void;
  submitLabel: string;
}> = ({ value, onChange, onSubmit, onCancel, submitLabel }) => {
  const set = (patch: Partial<SupplierFormValue>): void => onChange({ ...value, ...patch });
  const setContact = (i: number, patch: Partial<SupplierContact>): void => {
    const contacts = value.contacts.map((c, idx) => (idx === i ? { ...c, ...patch } : c));
    set({ contacts });
  };
  return (
    <div className="p-4 space-y-4" style={PANEL}>
      <div style={autoGrid(220)}>
        <div>
          <Label>Supplier name *</Label>
          <input style={INPUT} value={value.name} onChange={(e) => set({ name: e.target.value })} />
        </div>
        <div>
          <Label>Country</Label>
          <input style={INPUT} value={value.country} onChange={(e) => set({ country: e.target.value })} />
        </div>
      </div>

      <div>
        <Label>Categories</Label>
        <CategoryPicker selected={value.categories} onChange={(categories) => set({ categories })} />
      </div>

      <div>
        <Label>Contacts</Label>
        <div className="space-y-2">
          {value.contacts.map((c, i) => (
            <div key={i} style={autoGrid(160)}>
              <input style={INPUT} placeholder="Name" value={c.name} onChange={(e) => setContact(i, { name: e.target.value })} />
              <input style={INPUT} placeholder="Email" value={c.email} onChange={(e) => setContact(i, { email: e.target.value })} />
              <div className="flex gap-2">
                <input style={INPUT} placeholder="Phone" value={c.phone || ''} onChange={(e) => setContact(i, { phone: e.target.value })} />
                {value.contacts.length > 1 && (
                  <Btn small kind="danger" onClick={() => set({ contacts: value.contacts.filter((_, idx) => idx !== i) })}>
                    ✕
                  </Btn>
                )}
              </div>
            </div>
          ))}
          <Btn small onClick={() => set({ contacts: [...value.contacts, { name: '', email: '', phone: '' }] })}>
            + Add contact
          </Btn>
        </div>
      </div>

      <div>
        <Label>Notes</Label>
        <textarea style={{ ...INPUT, minHeight: 60, resize: 'vertical' }} value={value.notes} onChange={(e) => set({ notes: e.target.value })} />
      </div>

      <div className="flex gap-2">
        <Btn kind="primary" disabled={!value.name.trim()} onClick={onSubmit}>
          {submitLabel}
        </Btn>
        {onCancel && <Btn onClick={onCancel}>Cancel</Btn>}
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Supplier card (catalog)
// ─────────────────────────────────────────────────────────────────────────────
const SupplierCard: React.FC<{
  supplier: Supplier;
  onChanged: () => void;
}> = ({ supplier, onChanged }) => {
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState<SupplierFormValue>(() => ({
    name: supplier.name,
    categories: supplier.categories,
    country: supplier.country,
    contacts: supplier.contacts.length ? supplier.contacts : [{ name: '', email: '', phone: '' }],
    notes: supplier.notes,
  }));

  const saveEdit = (): void => {
    updateSupplier(supplier.supplier_id, {
      name: form.name.trim(),
      categories: form.categories,
      country: form.country,
      contacts: form.contacts.filter((c) => c.name || c.email || c.phone),
      notes: form.notes,
    });
    setEditing(false);
    toast.notify('Supplier updated', 'success');
    onChanged();
  };

  const doDelete = (): void => {
    if (!window.confirm(`Remove supplier "${supplier.name}"?`)) return;
    deleteSupplier(supplier.supplier_id);
    toast.notify('Supplier removed', 'info');
    onChanged();
  };

  return (
    <div style={CARD}>
      <div className="p-3 flex items-start justify-between gap-3">
        <button type="button" className="text-left min-w-0 flex-1" onClick={() => setOpen((o) => !o)}>
          <p className="font-semibold truncate" style={{ color: COLORS.light }}>
            {open ? '▾ ' : '▸ '}
            {supplier.name || '(no name)'}
          </p>
          <div className="flex flex-wrap gap-1 mt-1.5">
            {supplier.categories.length ? (
              supplier.categories.map((c) => <Chip key={c}>{c}</Chip>)
            ) : (
              <span className="text-[11px]" style={{ color: COLORS.muted }}>
                No categories
              </span>
            )}
          </div>
          <p className="text-[11px] mt-1.5" style={{ color: COLORS.muted }}>
            {supplier.country || 'Country n/a'} · {supplier.quotations.length} quotation
            {supplier.quotations.length === 1 ? '' : 's'} · {supplier.pns_supplied.length} PN
          </p>
        </button>
        <div className="flex flex-col gap-1.5 shrink-0">
          <Btn small onClick={() => setEditing((e) => !e)}>
            ✎ Edit
          </Btn>
          <Btn small kind="danger" onClick={doDelete}>
            ✕ Remove
          </Btn>
        </div>
      </div>

      {editing && (
        <div className="px-3 pb-3">
          <SupplierForm value={form} onChange={setForm} onSubmit={saveEdit} onCancel={() => setEditing(false)} submitLabel="Save changes" />
        </div>
      )}

      {open && !editing && (
        <div className="px-3 pb-3 space-y-3">
          {supplier.contacts.length > 0 && (
            <div style={PANEL} className="p-2.5">
              <Label>Contacts</Label>
              {supplier.contacts.map((c, i) => (
                <p key={i} className="text-[12px]" style={{ color: COLORS.light }}>
                  {c.name}
                  {c.email ? ` · ${c.email}` : ''}
                  {c.phone ? ` · ${c.phone}` : ''}
                </p>
              ))}
            </div>
          )}
          {supplier.notes && (
            <p className="text-[12px]" style={{ color: COLORS.muted }}>
              {supplier.notes}
            </p>
          )}
          <QuotationTable supplier={supplier} onChanged={onChanged} />
        </div>
      )}
    </div>
  );
};

// Editable quotation table for a supplier (fix AI-mapped fields here too).
const QUOTE_COLS = '1fr 1.6fr 0.7fr 0.9fr 0.7fr 0.8fr 0.9fr';
const QuotationTable: React.FC<{ supplier: Supplier; onChanged: () => void }> = ({ supplier, onChanged }) => {
  const toast = useToast();
  const [editId, setEditId] = useState<string | null>(null);
  const [draft, setDraft] = useState<Partial<Quotation>>({});
  const uploadRef = useRef<HTMLInputElement>(null);
  const [showUpload, setShowUpload] = useState(false);
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);

  const doUpload = async (): Promise<void> => {
    if (!uploadFile) return;
    if (!ApiClient.isQuotesUploadConfigured()) {
      toast.notify('The quotation upload folder is not configured in the web part settings.', 'error');
      return;
    }
    try {
      setUploadStatus('Uploading…');
      await ApiClient.uploadQuoteDocument(uploadFile);
      setUploadFile(null);
      setUploadStatus(null);
      setShowUpload(false);
      toast.notify(
        'Quotation uploaded. The flow is reading it now — it will appear in the Quotations tab to link to this supplier.',
        'success'
      );
    } catch (err) {
      toast.notify(err instanceof Error ? err.message : 'Upload failed', 'error');
      setUploadStatus(null);
    }
  };

  const addNew = (): void => {
    const blank: Quotation = {
      id: newQuotationId(),
      quote_number: '',
      date: new Date().toISOString().slice(0, 10),
      opportunity_id: '',
      item_type: 'Sale',
      pn: '',
      description: '',
      unit_price: 0,
      currency: 'USD',
    };
    addQuotation(supplier.supplier_id, blank);
    setEditId(blank.id);
    setDraft({ ...blank });
    onChanged();
  };

  const startEdit = (q: Quotation): void => {
    setEditId(q.id);
    setDraft({ ...q });
  };
  const saveEdit = (): void => {
    if (editId) {
      updateQuotation(supplier.supplier_id, editId, {
        pn: draft.pn,
        description: draft.description,
        unit_price: Number(draft.unit_price) || 0,
        currency: draft.currency,
        quantity: draft.quantity === undefined ? undefined : Number(draft.quantity),
        lead_time_days: draft.lead_time_days === undefined ? undefined : Number(draft.lead_time_days),
        item_type: draft.item_type,
      });
    }
    setEditId(null);
    onChanged();
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between gap-2">
        <Label>Quotations ({supplier.quotations.length})</Label>
        <div className="flex gap-2">
          <Btn small onClick={() => setShowUpload((v) => !v)}>⤒ Upload quotation</Btn>
          <Btn small onClick={addNew}>+ Add quotation</Btn>
        </div>
      </div>
      {showUpload && (
        <div style={PANEL} className="p-3 space-y-2">
          <Label>Let the flow read a quotation file (PDF, Excel, Word, image or CSV)</Label>
          <div
            onClick={() => uploadRef.current?.click()}
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              setUploadFile(e.dataTransfer.files?.[0] || null);
            }}
            style={{
              border: '2px dashed #dfe6ec',
              background: '#ffffff',
              borderRadius: 8,
              padding: '1.25rem',
              textAlign: 'center',
              cursor: 'pointer',
            }}
          >
            <input
              ref={uploadRef}
              type="file"
              accept={QUOTE_UPLOAD_ACCEPT}
              style={{ display: 'none' }}
              onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
            />
            <p className="text-[12px]" style={{ color: uploadFile ? COLORS.light : COLORS.muted }}>
              {uploadFile ? uploadFile.name : 'Click or drop a quotation file here'}
            </p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Btn kind="primary" disabled={!uploadFile || !!uploadStatus} onClick={() => void doUpload()}>
              {uploadStatus ? 'Processing…' : '⤒ Upload & process'}
            </Btn>
            <Btn onClick={() => { setShowUpload(false); setUploadFile(null); }}>Cancel</Btn>
            {uploadStatus && (
              <span className="text-[11px]" style={{ color: COLORS.muted }}>
                {uploadStatus}
              </span>
            )}
          </div>
          <p className="text-[11px]" style={{ color: COLORS.muted }}>
            The extracted lines appear in the Quotations tab, where you can review them and link them to this supplier.
          </p>
        </div>
      )}
      {supplier.quotations.length === 0 ? (
        <p className="text-[11px]" style={{ color: COLORS.muted }}>
          No quotations linked yet. Add one with the button above, or import from the Quotations tab (EASI - QUOTES).
        </p>
      ) : (
    <div className="overflow-x-auto" style={PANEL}>
      <div style={{ minWidth: 640 }} className="p-2">
        <div style={{ display: 'grid', gridTemplateColumns: QUOTE_COLS, gap: '0.4rem' }} className="pb-1.5 mb-1.5 border-b border-white/10">
          {['PN', 'Description', 'Qty', 'Unit price', 'Ccy', 'Quote', ''].map((h, i) => (
            <div key={i} className="text-[9px] uppercase tracking-widest font-mono" style={{ color: COLORS.muted }}>
              {h}
            </div>
          ))}
        </div>
        {supplier.quotations.map((q) => {
          const isEdit = editId === q.id;
          return (
            <div key={q.id} style={{ display: 'grid', gridTemplateColumns: QUOTE_COLS, gap: '0.4rem', alignItems: 'flex-start' }} className="py-1">
              {isEdit ? (
                <>
                  <input style={{ ...INPUT, padding: '0.25rem 0.4rem' }} value={draft.pn || ''} onChange={(e) => setDraft({ ...draft, pn: e.target.value })} />
                  <input style={{ ...INPUT, padding: '0.25rem 0.4rem' }} value={draft.description || ''} onChange={(e) => setDraft({ ...draft, description: e.target.value })} />
                  <input style={{ ...INPUT, padding: '0.25rem 0.4rem' }} value={draft.quantity ?? ''} onChange={(e) => setDraft({ ...draft, quantity: e.target.value === '' ? undefined : Number(e.target.value) })} />
                  <input style={{ ...INPUT, padding: '0.25rem 0.4rem' }} value={draft.unit_price ?? ''} onChange={(e) => setDraft({ ...draft, unit_price: Number(e.target.value) })} />
                  <input style={{ ...INPUT, padding: '0.25rem 0.4rem' }} value={draft.currency || ''} onChange={(e) => setDraft({ ...draft, currency: e.target.value })} />
                  <span className="text-[11px] font-mono truncate" style={{ color: COLORS.muted }}>
                    {q.quote_number}
                  </span>
                  <button type="button" onClick={saveEdit} title="Save" style={{ color: COLORS.gold }}>
                    ✓ Save
                  </button>
                </>
              ) : (
                <>
                  <span className="text-[11px] font-mono" style={{ color: COLORS.light, whiteSpace: 'normal', overflowWrap: 'anywhere' }} title={q.pn}>
                    {q.pn || '—'}
                  </span>
                  <span className="text-[11px]" style={{ color: COLORS.light, whiteSpace: 'normal', overflowWrap: 'anywhere' }} title={q.description}>
                    {q.description || '—'}
                  </span>
                  <span className="text-[11px] font-mono" style={{ color: COLORS.muted }}>
                    {q.quantity ?? '—'}
                  </span>
                  <span className="text-[11px] font-mono" style={{ color: COLORS.light }}>
                    {fmtMoney(q.unit_price, q.currency)}
                  </span>
                  <span className="text-[11px] font-mono" style={{ color: COLORS.muted }}>
                    {q.currency || '—'}
                  </span>
                  <span className="text-[11px] font-mono" style={{ color: COLORS.muted, whiteSpace: 'normal', overflowWrap: 'anywhere' }} title={q.quote_number}>
                    {q.quote_number || '—'}
                  </span>
                  <div className="flex gap-2">
                    <button type="button" onClick={() => startEdit(q)} title="Edit" style={{ color: COLORS.teal }}>
                      ✎
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        removeQuotation(supplier.supplier_id, q.id);
                        onChanged();
                      }}
                      title="Remove"
                      style={{ color: COLORS.red }}
                    >
                      ✕
                    </button>
                  </div>
                </>
              )}
            </div>
          );
        })}
      </div>
    </div>
      )}
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Quotations tab — read EASI - QUOTES list, edit fields, link to a supplier
// ─────────────────────────────────────────────────────────────────────────────
interface QuoteGroup {
  key: string;
  quoteNumber: string;
  supplier: string;
  supplierCountry: string;
  reference: string;
  project: string;
  paymentTerms: string;
  date: string;
  currency: string;
  sourceFile: string;
  items: QuoteListItem[];
}

function groupQuotes(rows: QuoteListItem[]): QuoteGroup[] {
  const map = new Map<string, QuoteGroup>();
  rows.forEach((r) => {
    const key = `${r.quoteNumber}##${r.supplier}`;
    let g = map.get(key);
    if (!g) {
      g = {
        key,
        quoteNumber: r.quoteNumber,
        supplier: r.supplier,
        supplierCountry: r.supplierCountry,
        reference: r.reference,
        project: r.project,
        paymentTerms: r.paymentTerms,
        date: r.quoteDate,
        currency: r.currency,
        sourceFile: r.sourceFile,
        items: [],
      };
      map.set(key, g);
    }
    g.items.push(r);
  });
  return Array.from(map.values());
}

interface EditableLine {
  source_item_id: number;
  item_type: string;
  pn: string;
  description: string;
  quantity: string;
  unit_price: string;
  currency: string;
  lead_time_days: string;
}

const LINE_COLS = '0.8fr 1fr 1.6fr 0.7fr 0.9fr 0.7fr 0.8fr';

const QuoteReviewCard: React.FC<{
  group: QuoteGroup;
  suppliers: Supplier[];
  onImported: () => void;
}> = ({ group, suppliers, onImported }) => {
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const alreadyImported = group.items.every((it) => isQuoteItemImported(it.id));

  const [supplierName, setSupplierName] = useState(group.supplier);
  const [country, setCountry] = useState(group.supplierCountry);
  const [reference, setReference] = useState(group.reference || group.project);
  const [targetId, setTargetId] = useState<string>(''); // '' = create new from name
  const [quoteNumber, setQuoteNumber] = useState(group.quoteNumber);
  const [quoteDate, setQuoteDate] = useState(group.date);
  const [lines, setLines] = useState<EditableLine[]>(() =>
    group.items.map((it) => ({
      source_item_id: it.id,
      item_type: it.itemType,
      pn: it.productCode,
      description: it.description,
      quantity: it.quantity !== null ? String(it.quantity) : '',
      unit_price: it.unitPrice !== null ? String(it.unitPrice) : '',
      currency: it.currency || group.currency,
      lead_time_days: it.leadTimeDays !== null ? String(it.leadTimeDays) : '',
    }))
  );

  // Pre-select an existing supplier matching the extracted name.
  useEffect(() => {
    const match = findByName(group.supplier);
    if (match) setTargetId(match.supplier_id);
  }, [group.supplier]);

  const setLine = (i: number, patch: Partial<EditableLine>): void =>
    setLines((prev) => prev.map((l, idx) => (idx === i ? { ...l, ...patch } : l)));

  const total = lines.reduce((s, l) => s + (parseFloat(l.unit_price) || 0) * (parseFloat(l.quantity) || 1), 0);

  const doImport = (): void => {
    let supplierId = targetId;
    if (!supplierId) {
      const created = createSupplier({ name: supplierName.trim() || group.supplier || 'Unknown supplier', country });
      supplierId = created.supplier_id;
    } else if (country) {
      updateSupplier(supplierId, { country });
    }
    let added = 0;
    lines.forEach((l) => {
      if (isQuoteItemImported(l.source_item_id)) return;
      const q: Quotation = {
        id: newQuotationId(),
        quote_number: quoteNumber,
        date: quoteDate,
        opportunity_id: reference,
        item_type: l.item_type,
        pn: l.pn.trim(),
        description: l.description.trim(),
        quantity: l.quantity === '' ? undefined : Number(l.quantity),
        unit_price: Number(l.unit_price) || 0,
        currency: l.currency,
        lead_time_days: l.lead_time_days === '' ? undefined : Number(l.lead_time_days),
        source_file: group.sourceFile,
        source_item_id: l.source_item_id,
      };
      addQuotation(supplierId, q);
      added++;
    });
    toast.notify(added > 0 ? `${added} item(s) linked to supplier` : 'Nothing new to import', added > 0 ? 'success' : 'info');
    onImported();
  };

  const removeFromCatalog = (): void => {
    if (!window.confirm('Remove this quotation from the local catalog? (The EASI - QUOTES list is not affected.)')) return;
    const ids = new Set(group.items.map((it) => it.id));
    let removed = 0;
    suppliers.forEach((s) => {
      s.quotations
        .filter((q) => q.source_item_id !== undefined && ids.has(q.source_item_id))
        .forEach((q) => {
          removeQuotation(s.supplier_id, q.id);
          removed++;
        });
    });
    toast.notify(removed > 0 ? `${removed} quotation line(s) removed from catalog` : 'Nothing to remove', 'info');
    onImported();
  };

  return (
    <div style={CARD}>
      <div className="p-3 flex items-start justify-between gap-3">
        <button type="button" className="text-left min-w-0 flex-1" onClick={() => setOpen((o) => !o)}>
          <p className="font-semibold truncate" style={{ color: COLORS.light }}>
            {open ? '▾ ' : '▸ '}
            {group.supplier || '(no supplier)'}
          </p>
          <p className="text-[11px] mt-1" style={{ color: COLORS.muted }}>
            Quote {quoteNumber || '—'} · {quoteDate || 'no date'} · {group.items.length} item
            {group.items.length === 1 ? '' : 's'} · {fmtMoney(total, group.currency)}
          </p>
        </button>
        <div className="shrink-0">
          {alreadyImported ? <Chip color={COLORS.green}>Imported</Chip> : <Chip color={COLORS.amber}>Pending</Chip>}
        </div>
      </div>

      {open && (
        <div className="px-3 pb-3 space-y-3">
          <div style={autoGrid(200)}>
            <div>
              <Label>Quote number</Label>
              <input style={INPUT} value={quoteNumber} onChange={(e) => setQuoteNumber(e.target.value)} />
            </div>
            <div>
              <Label>Date</Label>
              <input type="date" style={INPUT} value={quoteDate} onChange={(e) => setQuoteDate(e.target.value)} />
            </div>
            <div>
              <Label>Supplier name</Label>
              <input style={INPUT} value={supplierName} onChange={(e) => setSupplierName(e.target.value)} />
            </div>
            <div>
              <Label>Country</Label>
              <input style={INPUT} value={country} onChange={(e) => setCountry(e.target.value)} />
            </div>
            <div>
              <Label>Reference / Opportunity</Label>
              <input style={INPUT} value={reference} onChange={(e) => setReference(e.target.value)} />
            </div>
            <div>
              <Label>Link to catalog</Label>
              <select style={{ ...INPUT, background: '#ffffff' }} value={targetId} onChange={(e) => setTargetId(e.target.value)}>
                <option value="" style={{ background: '#ffffff' }}>
                  ＋ Create new supplier
                </option>
                {suppliers.map((s) => (
                  <option key={s.supplier_id} value={s.supplier_id} style={{ background: '#ffffff' }}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Editable line items */}
          <div className="overflow-x-auto" style={PANEL}>
            <div style={{ minWidth: 720 }} className="p-2">
              <div
                style={{ display: 'grid', gridTemplateColumns: LINE_COLS, gap: '0.4rem' }}
                className="pb-1.5 mb-1.5 border-b border-white/10"
              >
                {['Type', 'PN', 'Description', 'Qty', 'Unit price', 'Ccy', 'Lead (d)'].map((h, i) => (
                  <div key={i} className="text-[9px] uppercase tracking-widest font-mono" style={{ color: COLORS.muted }}>
                    {h}
                  </div>
                ))}
              </div>
              {lines.map((l, i) => {
                const imported = isQuoteItemImported(l.source_item_id);
                return (
                  <div
                    key={l.source_item_id}
                    style={{ display: 'grid', gridTemplateColumns: LINE_COLS, gap: '0.4rem', opacity: imported ? 0.55 : 1 }}
                    className="py-1"
                  >
                    <input style={{ ...INPUT, padding: '0.25rem 0.4rem' }} value={l.item_type} onChange={(e) => setLine(i, { item_type: e.target.value })} />
                    <input style={{ ...INPUT, padding: '0.25rem 0.4rem' }} value={l.pn} onChange={(e) => setLine(i, { pn: e.target.value })} />
                    <input style={{ ...INPUT, padding: '0.25rem 0.4rem' }} value={l.description} onChange={(e) => setLine(i, { description: e.target.value })} />
                    <input style={{ ...INPUT, padding: '0.25rem 0.4rem' }} value={l.quantity} onChange={(e) => setLine(i, { quantity: e.target.value })} />
                    <input style={{ ...INPUT, padding: '0.25rem 0.4rem' }} value={l.unit_price} onChange={(e) => setLine(i, { unit_price: e.target.value })} />
                    <input style={{ ...INPUT, padding: '0.25rem 0.4rem' }} value={l.currency} onChange={(e) => setLine(i, { currency: e.target.value })} />
                    <input style={{ ...INPUT, padding: '0.25rem 0.4rem' }} value={l.lead_time_days} onChange={(e) => setLine(i, { lead_time_days: e.target.value })} />
                  </div>
                );
              })}
            </div>
          </div>

          <div className="flex items-center justify-between gap-2 flex-wrap">
            {group.sourceFile ? (
              <a href={group.sourceFile} target="_blank" rel="noreferrer" className="text-[11px] underline" style={{ color: COLORS.teal }}>
                Source document ↗
              </a>
            ) : (
              <span />
            )}
            <div className="flex gap-2">
              <Btn kind="danger" onClick={removeFromCatalog}>
                ✕ Delete quotation
              </Btn>
              <Btn kind="primary" onClick={doImport}>
                {alreadyImported ? 'Re-check import' : 'Save to catalog'}
              </Btn>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Page
// ─────────────────────────────────────────────────────────────────────────────
type Tab = 'catalog' | 'add' | 'quotes';

export const Suppliers: React.FC = () => {
  const toast = useToast();
  const [tab, setTab] = useState<Tab>('catalog');
  const [refreshKey, setRefreshKey] = useState(0);
  const refresh = useCallback(() => setRefreshKey((k) => k + 1), []);

  const suppliers = useMemo(() => listSuppliers(), [refreshKey]);
  const stats = useMemo(() => getStats(), [refreshKey]);

  // Catalog search
  const [query, setQuery] = useState('');
  const filtered = useMemo(() => (query.trim() ? searchCatalog(query) : suppliers), [query, suppliers]);

  // Add form
  const [form, setForm] = useState<SupplierFormValue>(emptyForm);
  const submitAdd = (): void => {
    createSupplier({
      name: form.name.trim(),
      categories: form.categories,
      country: form.country,
      contacts: form.contacts.filter((c) => c.name || c.email || c.phone),
      notes: form.notes,
    });
    setForm(emptyForm());
    toast.notify('Supplier added', 'success');
    setTab('catalog');
    refresh();
  };

  // Quotes list
  const [quotesLoading, setQuotesLoading] = useState(false);
  const [quotesError, setQuotesError] = useState<string | null>(null);
  const [quoteGroups, setQuoteGroups] = useState<QuoteGroup[]>([]);
  const [showUpload, setShowUpload] = useState(false);
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);
  const uploadInputRef = useRef<HTMLInputElement>(null);
  const loadQuotes = useCallback(async () => {
    if (!ApiClient.isQuotesStoreConfigured()) {
      setQuotesError('The EASI - QUOTES list is not configured in the web part settings.');
      return;
    }
    try {
      setQuotesLoading(true);
      setQuotesError(null);
      const rows = await ApiClient.listQuotes();
      setQuoteGroups(groupQuotes(rows));
    } catch (err) {
      setQuotesError(err instanceof Error ? err.message : 'Failed to load quotations');
    } finally {
      setQuotesLoading(false);
    }
  }, []);

  const doUpload = async (): Promise<void> => {
    if (!uploadFile) return;
    if (!ApiClient.isQuotesUploadConfigured()) {
      toast.notify('The quotation upload folder is not configured in the web part settings.', 'error');
      return;
    }
    const chosen = uploadFile;
    try {
      setUploadStatus('Uploading…');
      await ApiClient.uploadQuoteDocument(chosen);
      toast.notify('Quotation uploaded. The flow is reading it now.', 'success');
      setUploadFile(null);
      // Poll the EASI - QUOTES list until the new lines appear (stops early),
      // waiting up to ~2 min since the AI extraction can take a while.
      const baseline = quoteGroups.length;
      const maxAttempts = 24; // 24 × 5s ≈ 2 min
      let appeared = false;
      for (let attempt = 0; attempt < maxAttempts && !appeared; attempt++) {
        setUploadStatus(`Waiting for the flow to process the quotation… (${attempt + 1}/${maxAttempts})`);
        await new Promise((r) => setTimeout(r, 5000));
        try {
          const rows = await ApiClient.listQuotes();
          const groups = groupQuotes(rows);
          setQuoteGroups(groups);
          if (groups.length > baseline) appeared = true;
        } catch {
          /* keep polling */
        }
      }
      setUploadStatus(null);
      setShowUpload(false);
      toast.notify(
        appeared
          ? 'New quotation loaded.'
          : 'Still processing — use ↻ Reload to check again in a moment.',
        appeared ? 'success' : 'info'
      );
    } catch (err) {
      toast.notify(err instanceof Error ? err.message : 'Upload failed', 'error');
      setUploadStatus(null);
    }
  };

  useEffect(() => {
    // Recarrega da lista sempre que a aba de cotações é aberta, para que itens
    // já excluídos da EASI - QUOTES não fiquem em cache no estado do React.
    if (tab === 'quotes') void loadQuotes();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  const exportCatalog = (): void => {
    const out: Array<Record<string, string | number>> = [];
    suppliers.forEach((s) => {
      if (s.quotations.length) {
        s.quotations.forEach((q) => {
          out.push({
            Supplier: s.name,
            Country: s.country,
            Categories: s.categories.join('; '),
            Quote: q.quote_number,
            Date: q.date,
            PN: q.pn,
            Description: q.description,
            Quantity: q.quantity ?? '',
            UnitPrice: q.unit_price,
            Currency: q.currency,
            LeadTimeDays: q.lead_time_days ?? '',
            Reference: q.opportunity_id,
          });
        });
      } else {
        out.push({
          Supplier: s.name,
          Country: s.country,
          Categories: s.categories.join('; '),
          Quote: '',
          Date: '',
          PN: '',
          Description: '',
          Quantity: '',
          UnitPrice: '',
          Currency: '',
          LeadTimeDays: '',
          Reference: '',
        });
      }
    });
    if (out.length === 0) {
      toast.notify('Nothing to export yet', 'info');
      return;
    }
    exportToXlsx(out, 'supplier_catalog', 'Suppliers');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <p className="text-xs uppercase tracking-widest opacity-85" style={{ color: COLORS.gold }}>
          Module 08
        </p>
        <h1 className="text-2xl font-semibold mt-2" style={{ color: COLORS.light }}>
          Supplier Management
        </h1>
        <p className="text-sm mt-1" style={{ color: COLORS.muted }}>
          Supplier catalog linked to items/services, fed by quotations extracted into the EASI - QUOTES list.
        </p>
      </div>

      {/* Stats */}
      <div style={autoGrid(150)}>
        <Stat label="Suppliers" value={stats.total_suppliers} color={COLORS.gold} />
        <Stat label="Quotations" value={stats.total_quotations} color={COLORS.teal} />
        <Stat label="Categories" value={stats.unique_categories} color={COLORS.green} />
        <Stat label="Part numbers" value={stats.unique_pns} color={COLORS.amber} />
      </div>

      {/* Tabs */}
      <div className="flex gap-0 border-b" style={{ borderColor: 'rgba(91,127,149,0.28)' }}>
        {(
          [
            ['catalog', 'Catalog'],
            ['add', 'Add Supplier'],
            ['quotes', 'Quotations'],
          ] as [Tab, string][]
        ).map(([t, lbl]) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className="px-4 py-2 text-xs uppercase tracking-widest font-mono transition"
            style={{
              color: tab === t ? COLORS.gold : COLORS.muted,
              borderBottom: `2px solid ${tab === t ? COLORS.gold : 'transparent'}`,
            }}
          >
            {lbl}
          </button>
        ))}
      </div>

      {/* Catalog */}
      {tab === 'catalog' && (
        <div className="space-y-3">
          <div className="flex gap-2 flex-wrap items-center justify-between">
            <input
              style={{ ...INPUT, maxWidth: 360 }}
              placeholder="Search name, category, PN, contact…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <Btn onClick={exportCatalog}>⤓ Export</Btn>
          </div>
          {filtered.length === 0 ? (
            <EmptyState title="No suppliers yet" description="Add a supplier or import quotations from the EASI - QUOTES list." />
          ) : (
            <div className="space-y-2">
              {filtered.map((s) => (
                <SupplierCard key={s.supplier_id} supplier={s} onChanged={refresh} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Add */}
      {tab === 'add' && <SupplierForm value={form} onChange={setForm} onSubmit={submitAdd} submitLabel="Add supplier" />}

      {/* Quotations */}
      {tab === 'quotes' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <p className="text-[12px]" style={{ color: COLORS.muted }}>
              Upload a quotation file — the flow reads it and populates the EASI - QUOTES list. Then review the fields and link each quote to a supplier.
            </p>
            <div className="flex gap-2">
              <Btn kind="primary" onClick={() => setShowUpload((v) => !v)}>+ New quotation</Btn>
              <Btn onClick={() => void loadQuotes()}>↻ Reload</Btn>
            </div>
          </div>

          {showUpload && (
            <div style={PANEL} className="p-4 space-y-3">
              <Label>Quotation file (PDF, Excel, Word, image or CSV)</Label>
              <div
                onClick={() => uploadInputRef.current?.click()}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  setUploadFile(e.dataTransfer.files?.[0] || null);
                }}
                style={{
                  border: '2px dashed #dfe6ec',
                  background: '#ffffff',
                  borderRadius: 8,
                  padding: '1.5rem',
                  textAlign: 'center',
                  cursor: 'pointer',
                }}
              >
                <input
                  ref={uploadInputRef}
                  type="file"
                  accept={QUOTE_UPLOAD_ACCEPT}
                  style={{ display: 'none' }}
                  onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
                />
                <p className="text-[12px]" style={{ color: uploadFile ? COLORS.light : COLORS.muted }}>
                  {uploadFile ? uploadFile.name : 'Click or drop a quotation file here'}
                </p>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <Btn kind="primary" disabled={!uploadFile || !!uploadStatus} onClick={() => void doUpload()}>
                  {uploadStatus ? 'Processing…' : '⤒ Upload & process'}
                </Btn>
                <Btn onClick={() => { setShowUpload(false); setUploadFile(null); }}>Cancel</Btn>
                {uploadStatus && (
                  <span className="text-[11px]" style={{ color: COLORS.muted }}>
                    {uploadStatus}
                  </span>
                )}
              </div>
            </div>
          )}

          {quotesLoading ? (
            <Loading label="Loading quotations…" />
          ) : quotesError ? (
            <ErrorState message={quotesError} onRetry={() => void loadQuotes()} />
          ) : quoteGroups.length === 0 ? (
            <EmptyState title="No quotations found" description="Upload a quotation with “+ New quotation” so the flow populates the EASI - QUOTES list." />
          ) : (
            <div className="space-y-2">
              {quoteGroups.map((g) => (
                <QuoteReviewCard key={g.key} group={g} suppliers={suppliers} onImported={refresh} />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
