import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ApiClient } from '../../adapters/ApiClient';
import { Loading, useToast } from '../../shared/ui';
import { BTN_ICON, BTN_SMALL, chipCls } from '../../shared/ui/buttonClasses';
import {
  BenchItem,
  OppInfo,
  LaborRow,
  acquisitionColor,
  buildHierarchy,
  buildOppTitleMap,
  fmtNum,
  fmtUsd,
  getAccessoryTag,
  getAcquisitionBreakdown,
  getFullCostHistory,
  isAccessory,
  isMainType,
  isValidPn,
  isZeroType,
  median,
  normalizeCostRows,
  normalizeLaborRows,
  normalizeTextKey,
  normalizeOpportunities,
  normalizeType,
} from '../../shared/utils/benchmark';
import { buildSupplyMap, pnKey, type SupplyInfo } from '../../shared/utils/aiSearch';

// ─────────────────────────────────────────────────────────────────────────────
// Design tokens (light MOC/PCMS theme, aligned with the rest of EASI)
// ─────────────────────────────────────────────────────────────────────────────

const COLORS = {
  gold: '#ffc72c',
  teal: '#0097a9',
  steel: '#5b7f95',
  muted: '#5b7f95',
  green: '#009b77',
  red: '#E24B4A',
  navy: '#00263e',
  light: '#0d2430',
  surface: '#ffffff',
  border: '#dfe6ec',
};

const CARD_STYLE: React.CSSProperties = {
  background: COLORS.surface,
  border: `1px solid ${COLORS.border}`,
  borderRadius: 10,
  boxShadow: '0 1px 2px rgba(0,38,62,0.05), 0 4px 12px rgba(0,38,62,0.05)',
};

const autoGrid = (min: number): React.CSSProperties => ({
  display: 'grid',
  gap: '0.9rem',
  gridTemplateColumns: `repeat(auto-fit, minmax(${min}px, 1fr))`,
});

const INPUT_CLS = 'w-full bg-white border rounded-md p-2.5 text-sm outline-none';

/** Default USD→BRL PTAX seen on the current commercial dashboards. */
const DEFAULT_PTAX = 6.3;

function fmtBrl(v: number | null | undefined): string {
  if (v === null || v === undefined || !Number.isFinite(v)) return '—';
  return 'R$ ' + Math.round(v).toLocaleString('pt-BR');
}

function fmtPct(v: number | null | undefined, digits = 1): string {
  if (v === null || v === undefined || !Number.isFinite(v)) return '—';
  const sign = v > 0 ? '+' : '';
  return `${sign}${v.toFixed(digits)}%`;
}

/** Tolerant opportunity-id comparison (trim + case-insensitive). */
function sameOpp(a: string, b: string): boolean {
  return (a || '').trim().toLowerCase() === (b || '').trim().toLowerCase();
}

// ─────────────────────────────────────────────────────────────────────────────
// Cost accounting helpers
// ─────────────────────────────────────────────────────────────────────────────

/** Priced value of a single line (unit price × quantity), ignoring zero-cost. */
function lineValue(it: BenchItem): number {
  if (isZeroType(it.typeRaw)) return 0;
  return (it.unitPrice || 0) * (it.quantity || 1);
}

/** Detects CAPEX/OPEX from the `(cap)`/`(ope)` suffix used in the source data. */
function isCapexLine(typeRaw: string): boolean {
  const t = normalizeType(typeRaw);
  return t.indexOf('(cap)') !== -1 || t.indexOf('purchase') !== -1 || t.indexOf('afe global') !== -1;
}
function isOpexLine(typeRaw: string): boolean {
  const t = normalizeType(typeRaw);
  return (
    t.indexOf('(ope)') !== -1 ||
    t.indexOf('rental') !== -1 ||
    t.indexOf('day rate') !== -1 ||
    t.indexOf('consum') !== -1 ||
    t.indexOf('call out') !== -1
  );
}

function isDayRateLine(typeRaw: string): boolean {
  return normalizeType(typeRaw).indexOf('day rate') !== -1;
}

function adjustBidItemsForProjectDays(items: BenchItem[], projectDays: number): BenchItem[] {
  const days = Number.isFinite(projectDays) && projectDays > 0 ? projectDays : 1;
  return items.map((it) =>
    isDayRateLine(it.typeRaw)
      ? {
          ...it,
          unitPrice: (it.unitPrice || 0) * days,
          unitPriceFin: (it.unitPriceFin || 0) * days,
        }
      : it
  );
}

interface BidStats {
  capex: number;
  opex: number;
  total: number;
  itemCount: number;
  mainCount: number;
  zeroCount: number;
  tbdCount: number;
}

function computeBidStats(items: BenchItem[]): BidStats {
  let capex = 0;
  let opex = 0;
  let mainCount = 0;
  let zeroCount = 0;
  let tbdCount = 0;
  for (const it of items) {
    const v = lineValue(it);
    if (isCapexLine(it.typeRaw)) capex += v;
    else if (isOpexLine(it.typeRaw)) opex += v;
    else capex += v; // any other priced line rolls into CAPEX by convention
    if (isMainType(it.typeRaw)) {
      mainCount += 1;
      if (v <= 0) zeroCount += 1;
    }
    if (isMainType(it.typeRaw) && !isValidPn(it.pn)) tbdCount += 1;
  }
  return { capex, opex, total: capex + opex, itemCount: items.length, mainCount, zeroCount, tbdCount };
}

/** A top-level equipment/service line with its accessories rolled in. */
interface TopItem {
  row: BenchItem;
  fullCost: number;
  mainCost: number;
  accessoriesCost: number;
  nAccessories: number;
  accessories: BenchItem[];
}

function topItemKey(item: TopItem): string {
  return `${item.row.index}-${normalizeTextKey(item.row.pn || item.row.description)}`;
}

function buildTopItems(items: BenchItem[]): TopItem[] {
  const nodes = buildHierarchy(items);
  const out: TopItem[] = [];
  for (const node of nodes) {
    const main = lineValue(node.row);
    const accessoriesCost = node.children.reduce((s, c) => s + lineValue(c), 0);
    const fullCost = main + accessoriesCost;
    // Keep any node that carries cost — this includes zero-priced equipment
    // (e.g. "in house") whose paid accessories still drive real cost, and
    // stand-alone OPEX/accessory lines when a bid has no main equipment.
    if (fullCost <= 0) continue;
    out.push({
      row: node.row,
      fullCost,
      mainCost: main,
      accessoriesCost,
      nAccessories: node.children.length,
      accessories: node.children,
    });
  }
  return out.sort((a, b) => b.fullCost - a.fullCost);
}

// ─────────────────────────────────────────────────────────────────────────────
// Small presentational primitives
// ─────────────────────────────────────────────────────────────────────────────

const SectionHeader: React.FC<{ eyebrow: string; title: string; hint?: string }> = ({ eyebrow, title, hint }) => (
  <div className="mb-4">
    <p className="text-[11px] uppercase tracking-widest font-mono" style={{ color: COLORS.gold }}>
      {eyebrow}
    </p>
    <h2 className="text-xl font-semibold mt-1" style={{ color: COLORS.light }}>
      {title}
    </h2>
    {hint && (
      <p className="text-sm mt-1" style={{ color: COLORS.muted }}>
        {hint}
      </p>
    )}
  </div>
);

const KpiCard: React.FC<{
  label: string;
  value: React.ReactNode;
  sub?: React.ReactNode;
  accent?: string;
}> = ({ label, value, sub, accent = COLORS.steel }) => (
  <div className="p-4 min-w-0" style={{ ...CARD_STYLE, borderTop: `3px solid ${accent}` }}>
    <div className="text-[10px] uppercase tracking-widest font-mono truncate" style={{ color: COLORS.muted }}>
      {label}
    </div>
    <div className="mt-1.5 font-mono font-semibold" style={{ color: COLORS.light, fontSize: '1.35rem', lineHeight: 1.15 }}>
      {value}
    </div>
    {sub && (
      <div className="text-[11px] mt-1" style={{ color: COLORS.muted }}>
        {sub}
      </div>
    )}
  </div>
);

const ParetoChart: React.FC<{
  data: Array<{ key: string; label: string; value: number; pct: number; rank: number }>;
  onSelect?: (key: string) => void;
  selectedKey?: string | null;
}> = ({ data, onSelect, selectedKey }) => {
  const [zoom, setZoom] = useState(1);
  if (!data.length) return null;
  const H = 440;
  const padTop = 24;
  const padBottom = 92;
  const padL = 16;
  const padR = 16;
  const colW = Math.round(56 * zoom);
  const W = Math.max(data.length * colW + padL + padR, 560);
  const plotH = H - padTop - padBottom;
  const maxVal = Math.max(...data.map((d) => d.value)) || 1;
  const x = (i: number): number => padL + i * colW + colW / 2;
  const yVal = (v: number): number => padTop + plotH * (1 - v / maxVal);
  const yPct = (p: number): number => padTop + plotH * (1 - p / 100);
  const barW = Math.min(colW * 0.6, 44);
  const labelFont = zoom >= 1.4 ? 11 : 9;
  const showValues = colW >= 62;
  const linePts = data.map((d, i) => `${x(i)},${yPct(d.pct)}`).join(' ');
  const zoomOut = (): void => setZoom((z) => Math.max(0.6, +(z - 0.35).toFixed(2)));
  const zoomIn = (): void => setZoom((z) => Math.min(4, +(z + 0.35).toFixed(2)));
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-xs font-medium mr-1" style={{ color: COLORS.muted }}>Zoom</span>
        <button type="button" onClick={zoomOut} className={BTN_ICON} aria-label="Zoom out">−</button>
        <button type="button" onClick={zoomIn} className={BTN_ICON} aria-label="Zoom in">+</button>
        <button
          type="button"
          onClick={() => setZoom(1)}
          className={BTN_SMALL}
        >
          Reset
        </button>
        <span className="text-[10px] ml-1" style={{ color: COLORS.muted }}>
          Clique na barra para ir ao card correspondente
        </span>
      </div>
      <div className="overflow-x-auto p-1 rounded-lg" style={{ ...CARD_STYLE, boxShadow: 'none' }}>
        <svg width={W} height={H} role="img" aria-label="Pareto chart">
          <line x1={padL} x2={W - padR} y1={yPct(80)} y2={yPct(80)} stroke={COLORS.red} strokeDasharray="4 4" strokeWidth={1} />
          <text x={padL + 2} y={yPct(80) - 4} fontSize={9} fill={COLORS.red}>80%</text>
          {data.map((d, i) => {
            const bh = plotH * (d.value / maxVal);
            const color = d.pct <= 80 ? COLORS.gold : COLORS.steel;
            return (
              <g key={d.key} style={{ cursor: onSelect ? 'pointer' : 'default' }} onClick={() => onSelect?.(d.key)}>
                <title>{`#${d.rank} ${d.label}\nCusto: ${fmtUsd(d.value)}\nAcumulado: ${d.pct.toFixed(1)}%`}</title>
                <rect
                  x={x(i) - barW / 2}
                  y={yVal(d.value)}
                  width={barW}
                  height={bh}
                  fill={color}
                  rx={2}
                  stroke={selectedKey === d.key ? COLORS.teal : 'none'}
                  strokeWidth={selectedKey === d.key ? 3 : 0}
                />
                {showValues && (
                  <text x={x(i)} y={yVal(d.value) - 4} fontSize={labelFont} fill="#33464f" textAnchor="middle">
                    {fmtUsd(d.value)}
                  </text>
                )}
                <text
                  x={x(i)}
                  y={H - padBottom + 18}
                  fontSize={10}
                  fill="#33464f"
                  textAnchor="middle"
                >
                  #{d.rank}
                </text>
              </g>
            );
          })}
          <polyline points={linePts} fill="none" stroke={COLORS.red} strokeWidth={1.5} />
          {data.map((d, i) => (
            <circle key={i} cx={x(i)} cy={yPct(d.pct)} r={4} fill={COLORS.red}>
              <title>{`${d.label}\nAcumulado: ${d.pct.toFixed(1)}%\nCusto: ${fmtUsd(d.value)}`}</title>
            </circle>
          ))}
        </svg>
      </div>
    </div>
  );
};

/** Delta badge — green when cheaper than history, red when more expensive. */
const DeltaBadge: React.FC<{ pct: number | null }> = ({ pct }) => {
  if (pct === null || !Number.isFinite(pct)) {
    return (
      <span
        className="inline-block px-2 py-0.5 rounded-full text-[11px] font-mono"
        style={{ background: '#eef2f5', color: COLORS.muted }}
      >
        sem histórico
      </span>
    );
  }
  const worse = pct > 0.5;
  const better = pct < -0.5;
  const color = worse ? COLORS.red : better ? COLORS.green : COLORS.steel;
  const arrow = worse ? '▲' : better ? '▼' : '≈';
  return (
    <span
      className="inline-block px-2 py-0.5 rounded-full text-[11px] font-mono font-semibold"
      style={{ background: `${color}1a`, color }}
    >
      {arrow} {fmtPct(pct)} vs. histórico
    </span>
  );
};

// Horizontal proportion bar (single value against a max).
const Meter: React.FC<{ value: number; max: number; color: string; height?: number }> = ({
  value,
  max,
  color,
  height = 8,
}) => {
  const pct = max > 0 ? Math.max(2, Math.min(100, (value / max) * 100)) : 0;
  return (
    <div style={{ height, background: '#eef2f5', borderRadius: 999, overflow: 'hidden' }}>
      <div style={{ width: `${pct}%`, height: '100%', background: color, borderRadius: 999 }} />
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// BID selector (searchable combobox)
// ─────────────────────────────────────────────────────────────────────────────

const BidSelect: React.FC<{
  value: string;
  onChange: (id: string) => void;
  bidIds: string[];
  oppTitles: Map<string, string>;
}> = ({ value, onChange, bidIds, oppTitles }) => {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return undefined;
    const onDocClick = (e: MouseEvent): void => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', onDocClick);
    return () => document.removeEventListener('mousedown', onDocClick);
  }, [open]);

  const label = (id: string): string => `${id} — ${(oppTitles.get(id) || '').slice(0, 48)}`;

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return bidIds;
    return bidIds.filter((id) => label(id).toLowerCase().indexOf(q) !== -1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bidIds, oppTitles, query]);

  const inputCls =
    'w-full bg-white border rounded-md p-2.5 text-sm outline-none';

  return (
    <div className="relative" ref={ref} style={{ maxWidth: 520 }}>
      <button
        type="button"
        onClick={() => {
          setOpen((o) => !o);
          setQuery('');
        }}
        className={`${inputCls} flex items-center justify-between text-left`}
        style={{ borderColor: COLORS.border, color: COLORS.light }}
      >
        <span className="truncate">{value ? label(value) : 'Selecione um BID…'}</span>
        <span className="ml-2 shrink-0" style={{ color: COLORS.muted }}>
          ▾
        </span>
      </button>
      {open && (
        <div
          className="absolute z-30 mt-1 w-full border rounded-md"
          style={{ background: '#fff', borderColor: COLORS.border, boxShadow: '0 8px 24px rgba(0,38,62,0.12)' }}
        >
          <div className="p-2 border-b" style={{ borderColor: COLORS.border }}>
            <input
              autoFocus
              className={inputCls}
              style={{ borderColor: COLORS.border, color: COLORS.light }}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar BID ou projeto…"
            />
          </div>
          <div className="max-h-60 overflow-y-auto">
            {filtered.length === 0 ? (
              <div className="px-3 py-2 text-xs" style={{ color: COLORS.muted }}>
                Nenhum BID encontrado.
              </div>
            ) : (
              filtered.map((id) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => {
                    onChange(id);
                    setOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 text-xs truncate transition hover:bg-[#eef2f5]"
                  style={{ color: id === value ? COLORS.teal : COLORS.light, fontWeight: id === value ? 600 : 400 }}
                  title={label(id)}
                >
                  {label(id)}
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Section: Hero + KPIs
// ─────────────────────────────────────────────────────────────────────────────

const HeroSection: React.FC<{
  oppId: string;
  title: string;
  stats: BidStats;
  ptax: number;
}> = ({ oppId, title, stats, ptax }) => {
  const readiness = stats.mainCount
    ? Math.round(((stats.mainCount - stats.zeroCount - stats.tbdCount) / stats.mainCount) * 100)
    : 0;
  const readyColor = readiness >= 80 ? COLORS.green : readiness >= 50 ? COLORS.gold : COLORS.red;

  return (
    <div className="space-y-4">
      <div
        className="p-6 sm:p-8"
        style={{
          background: `linear-gradient(135deg, ${COLORS.navy} 0%, #0a3a5c 100%)`,
          borderRadius: 12,
          color: '#fff',
        }}
      >
        <p className="text-[11px] uppercase tracking-widest font-mono" style={{ color: COLORS.gold }}>
          Resumo Executivo · BID {oppId}
        </p>
        <h1 className="text-2xl sm:text-3xl font-semibold mt-2">{title || 'Proposta'}</h1>
        <div className="mt-5" style={autoGrid(180)}>
          <div>
            <div className="text-[11px] uppercase tracking-widest font-mono" style={{ color: 'rgba(255,255,255,0.6)' }}>
              Valor Total
            </div>
            <div className="text-2xl font-mono font-bold mt-1" style={{ color: COLORS.gold }}>
              {fmtUsd(stats.total)}
            </div>
            <div className="text-[11px] font-mono mt-0.5" style={{ color: 'rgba(255,255,255,0.75)' }}>
              {fmtBrl(stats.total * ptax)}
            </div>
          </div>
          <div>
            <div className="text-[11px] uppercase tracking-widest font-mono" style={{ color: 'rgba(255,255,255,0.6)' }}>
              CAPEX
            </div>
            <div className="text-xl font-mono font-semibold mt-1">{fmtUsd(stats.capex)}</div>
          </div>
          <div>
            <div className="text-[11px] uppercase tracking-widest font-mono" style={{ color: 'rgba(255,255,255,0.6)' }}>
              OPEX
            </div>
            <div className="text-xl font-mono font-semibold mt-1">{fmtUsd(stats.opex)}</div>
          </div>
          <div>
            <div className="text-[11px] uppercase tracking-widest font-mono" style={{ color: 'rgba(255,255,255,0.6)' }}>
              Prontidão do BID
            </div>
            <div className="text-xl font-mono font-semibold mt-1" style={{ color: readyColor }}>
              {readiness}%
            </div>
            <div className="text-[11px] mt-0.5" style={{ color: 'rgba(255,255,255,0.75)' }}>
              {stats.tbdCount} sem PN · {stats.zeroCount} sem custo
            </div>
          </div>
        </div>
      </div>

      <div style={autoGrid(160)}>
        <KpiCard label="Itens no escopo" value={fmtNum(stats.itemCount)} accent={COLORS.teal} />
        <KpiCard label="Itens principais" value={fmtNum(stats.mainCount)} accent={COLORS.teal} />
        <KpiCard
          label="Split CAPEX / OPEX"
          value={`${stats.total ? Math.round((stats.capex / stats.total) * 100) : 0}% / ${
            stats.total ? Math.round((stats.opex / stats.total) * 100) : 0
          }%`}
          accent={COLORS.gold}
        />
        <KpiCard label="PTAX aplicado" value={`R$ ${ptax.toFixed(2)}`} sub="USD → BRL" accent={COLORS.steel} />
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Section: Top items with historical comparison + why-chosen
// ─────────────────────────────────────────────────────────────────────────────

const TopItemCard: React.FC<{
  rank: number;
  item: TopItem;
  shareOfTotal: number;
  maxCost: number;
  allCost: BenchItem[];
  oppId: string;
  oppTitles: Map<string, string>;
  supply?: SupplyInfo;
  highlighted?: boolean;
}> = ({ rank, item, shareOfTotal, maxCost, allCost, oppId, oppTitles, supply, highlighted }) => {
  const { row } = item;
  const [showHistory, setShowHistory] = useState(false);
  const useDescription = !isValidPn(row.pn);

  const history = useMemo(
    () => getFullCostHistory(allCost, row.pn, row.description, oppId, useDescription, row.etText),
    [allCost, row.pn, row.description, row.etText, oppId, useDescription]
  );
  const breakdown = useMemo(
    () => getAcquisitionBreakdown(allCost, row.pn, row.description, useDescription, row.etText),
    [allCost, row.pn, row.description, row.etText, useDescription]
  );

  const historicalMedian = useMemo(() => {
    const vals = history.map((h) => h.totalFullCost).filter((v) => v > 0);
    return median(vals);
  }, [history]);

  const delta =
    historicalMedian && historicalMedian > 0 ? ((item.fullCost - historicalMedian) / historicalMedian) * 100 : null;

  const priorBids = history
    .map((h) => ({ id: h.oppId, project: oppTitles.get(h.oppId) || '' }))
    .slice(0, 6);

  const dominant = breakdown[0];

  // The equipment line itself has no cost — the value comes only from its
  // accessories (maintenance, transit…). Flag it so it doesn't read as the
  // equipment price.
  const accessoryOnly = item.mainCost <= 0 && item.accessoriesCost > 0;
  const historyMax = Math.max(item.fullCost, ...history.map((h) => h.totalFullCost), 1);

  return (
    <div className="p-5 scroll-mt-24" style={{ ...CARD_STYLE, borderColor: highlighted ? `${COLORS.teal}` : COLORS.border, boxShadow: highlighted ? '0 0 0 2px rgba(0,151,169,0.25), 0 4px 12px rgba(0,38,62,0.05)' : CARD_STYLE.boxShadow }}>
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div className="min-w-0" style={{ flex: '1 1 260px' }}>
          <div className="text-[11px] font-mono" style={{ color: COLORS.muted }}>
            #{rank} · {row.category || '—'} · {isValidPn(row.pn) ? `PN ${row.pn}` : 'PN a definir'}
          </div>
          <div className="font-semibold mt-0.5" style={{ color: COLORS.light }}>
            {row.description || '(sem descrição)'}
          </div>
          <div className="text-[11px] font-mono mt-1" style={{ color: COLORS.teal }}>
            {row.typeRaw || '—'}
          </div>
        </div>
        <div className="text-right shrink-0">
          <div className="text-xl font-mono font-bold" style={{ color: COLORS.light }}>
            {fmtUsd(item.fullCost)}
          </div>
          <div className="text-[10px] font-mono" style={{ color: COLORS.muted }}>
            {accessoryOnly
              ? 'custo de acessório/serviço'
              : item.accessoriesCost > 0
              ? 'equip. + acessórios'
              : 'custo do item'}
          </div>
          <div className="text-[11px] font-mono" style={{ color: COLORS.muted }}>
            {shareOfTotal.toFixed(1)}% do total
          </div>
        </div>
      </div>

      {/* Accessory-only warning: the equipment itself has no own cost */}
      {accessoryOnly && (
        <div
          className="mt-3 px-2.5 py-1.5 rounded-md text-[12px] flex items-start gap-1.5"
          style={{ background: `${COLORS.gold}18`, border: `1px solid ${COLORS.gold}66`, color: COLORS.light }}
        >
          <span aria-hidden>⚠</span>
          <span>
            Este valor é de <strong>acessório/serviço</strong> (ex.: manutenção), não do equipamento — o
            equipamento está como <span className="font-mono">{row.typeRaw || 'sem custo próprio'}</span>.
          </span>
        </div>
      )}

      <div className="mt-3">
        <Meter value={item.fullCost} max={maxCost} color={accessoryOnly ? COLORS.steel : COLORS.gold} />
      </div>

      {/* Cost decomposition: equipment vs. accessories */}
      {item.accessoriesCost > 0 && (
        <div className="mt-2">
          {!accessoryOnly && (
            <div className="text-[11px] font-mono mb-1" style={{ color: COLORS.muted }}>
              Equipamento {fmtUsd(item.mainCost)} · Acessórios {fmtUsd(item.accessoriesCost)}
            </div>
          )}
          <div className="flex flex-wrap gap-1.5">
            {item.accessories
              .filter((a) => lineValue(a) > 0)
              .map((a, i) => {
                const tag = getAccessoryTag(a.typeRaw);
                return (
                  <span
                    key={`${a.index}-${i}`}
                    className="inline-block px-2 py-0.5 rounded text-[11px] font-mono"
                    style={{ background: `${tag.color}22`, color: COLORS.light }}
                    title={a.description || a.typeRaw}
                  >
                    {tag.label} {fmtUsd(lineValue(a))}
                  </span>
                );
              })}
          </div>
        </div>
      )}

      <div className="mt-3 flex items-center gap-2 flex-wrap">
        <DeltaBadge pct={delta} />
        {historicalMedian !== null && (
          <span className="text-[11px] font-mono" style={{ color: COLORS.muted }}>
            mediana histórica {fmtUsd(historicalMedian)} · {history.length} bid(s)
          </span>
        )}
        <button
          type="button"
          onClick={() => setShowHistory((v) => !v)}
          className={BTN_SMALL}
        >
          {showHistory ? 'Close' : 'Full history'}
        </button>
      </div>

      {showHistory && history.length > 0 && (
        <div className="mt-3 pt-3 border-t space-y-2" style={{ borderColor: COLORS.border }}>
          <div className="text-[10px] uppercase tracking-widest font-mono" style={{ color: COLORS.muted }}>
            History by bid
          </div>
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <div className="w-44 shrink-0 min-w-0 text-[11px] font-medium" style={{ color: COLORS.light }}>
                THIS BID
              </div>
              <div className="flex-1 h-5 bg-[#eef2f5] overflow-hidden rounded">
                <div className="h-full inline-block" style={{ width: `${(item.mainCost / historyMax) * 100}%`, background: acquisitionColor(row.typeRaw) }} />
                <div className="h-full inline-block" style={{ width: `${(item.accessoriesCost / historyMax) * 100}%`, background: COLORS.teal }} />
              </div>
              <div className="w-24 shrink-0 text-right text-[11px] font-mono" style={{ color: COLORS.light }}>{fmtUsd(item.fullCost)}</div>
            </div>
            {history.map((h, idx) => (
              <div key={`${h.oppId}-${idx}`} className="flex items-center gap-3">
                <div className="w-44 shrink-0 min-w-0">
                  <div className="text-[11px] truncate" style={{ color: COLORS.light }} title={`${h.oppId} — ${oppTitles.get(h.oppId) || ''}`}>
                    {h.oppId} — {(oppTitles.get(h.oppId) || '').slice(0, 24)}
                  </div>
                  <div className="text-[9px] font-mono truncate" style={{ color: acquisitionColor(h.typeRaw) }}>
                    {h.typeRaw}
                  </div>
                </div>
                <div className="flex-1 h-5 bg-[#eef2f5] overflow-hidden rounded">
                  <div className="h-full inline-block" style={{ width: `${(h.mainPrice / historyMax) * 100}%`, background: acquisitionColor(h.typeRaw) }} />
                  <div className="h-full inline-block" style={{ width: `${(h.totalAccessoriesCost / historyMax) * 100}%`, background: COLORS.teal }} />
                </div>
                <div className="w-24 shrink-0 text-right text-[11px] font-mono" style={{ color: COLORS.light }}>{fmtUsd(h.totalFullCost)}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Why chosen: premises + how it was historically acquired */}
      {(row.premisses || dominant) && (
        <div className="mt-3 pt-3 border-t" style={{ borderColor: COLORS.border }}>
          {row.premisses && (
            <p className="text-[13px]" style={{ color: COLORS.light }}>
              <span className="font-mono text-[10px] uppercase tracking-widest" style={{ color: COLORS.muted }}>
                Justificativa ·{' '}
              </span>
              {row.premisses}
            </p>
          )}
          {dominant && (
            <p className="text-[12px] mt-2" style={{ color: COLORS.muted }}>
              Historicamente ofertado como{' '}
              <span style={{ color: dominant.color, fontWeight: 600 }}>{dominant.type}</span> em{' '}
              {dominant.pct.toFixed(0)}% dos casos
              {breakdown.length > 1 && ` (${breakdown.length} formas diferentes registradas)`}.
            </p>
          )}
        </div>
      )}

      {/* When we used it before */}
      {priorBids.length > 0 && (
        <div className="mt-3">
          <div className="text-[10px] uppercase tracking-widest font-mono mb-1" style={{ color: COLORS.muted }}>
            Usado anteriormente em
          </div>
          <div className="flex flex-wrap gap-1.5">
            {priorBids.map((b) => (
              <span
                key={b.id}
                className="inline-block px-2 py-0.5 rounded text-[11px] font-mono"
                style={{ background: '#eef2f5', color: COLORS.light }}
                title={b.project}
              >
                {b.id}
                {b.project ? ` · ${b.project.slice(0, 24)}` : ''}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* ERP / inventory signal */}
      {supply && (
        <div
          className="mt-3 p-2.5 rounded-md text-[12px]"
          style={{ background: supply.inStock ? `${COLORS.green}12` : '#eef2f5', color: COLORS.light }}
        >
          <span className="font-mono text-[10px] uppercase tracking-widest" style={{ color: COLORS.muted }}>
            Estoque (ERP) ·{' '}
          </span>
          {supply.qtyOnHand > 0
            ? `${fmtNum(supply.qtyOnHand)} em estoque · custo médio ${fmtUsd(supply.avgCostUsd)}`
            : 'sem saldo em estoque'}
          {supply.leadTimeDays !== undefined && ` · lead time ${supply.leadTimeDays}d`}
          {supply.vendorName ? ` · ${supply.vendorName}` : ''}
        </div>
      )}
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Section: Cost composition (CAPEX/OPEX + acquisition mix)
// ─────────────────────────────────────────────────────────────────────────────

const CompositionSection: React.FC<{ items: BenchItem[]; stats: BidStats }> = ({ items, stats }) => {
  const mix = useMemo(() => {
    const m = new Map<string, number>();
    for (const it of items) {
      const v = lineValue(it);
      if (v <= 0 || isAccessory(it.typeRaw)) continue;
      const key = normalizeType(it.typeRaw) || '(indefinido)';
      m.set(key, (m.get(key) || 0) + v);
    }
    const arr = Array.from(m.entries()).map(([type, value]) => ({ type, value }));
    arr.sort((a, b) => b.value - a.value);
    return arr;
  }, [items]);

  const total = mix.reduce((s, x) => s + x.value, 0) || 1;
  const maxV = mix.length ? mix[0].value : 1;

  return (
    <div className="p-5" style={CARD_STYLE}>
      <div className="grid gap-5" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))' }}>
        <div>
          <div className="text-[10px] uppercase tracking-widest font-mono mb-3" style={{ color: COLORS.muted }}>
            CAPEX vs. OPEX
          </div>
          <div className="flex h-4 rounded-full overflow-hidden" style={{ background: '#eef2f5' }}>
            <div style={{ width: `${(stats.capex / (stats.total || 1)) * 100}%`, background: COLORS.gold }} />
            <div style={{ width: `${(stats.opex / (stats.total || 1)) * 100}%`, background: COLORS.teal }} />
          </div>
          <div className="flex justify-between mt-2 text-[12px] font-mono">
            <span style={{ color: COLORS.light }}>
              <span style={{ color: COLORS.gold }}>■</span> CAPEX {fmtUsd(stats.capex)}
            </span>
            <span style={{ color: COLORS.light }}>
              <span style={{ color: COLORS.teal }}>■</span> OPEX {fmtUsd(stats.opex)}
            </span>
          </div>
        </div>

        <div>
          <div className="text-[10px] uppercase tracking-widest font-mono mb-3" style={{ color: COLORS.muted }}>
            Composição por tipo de aquisição
          </div>
          <div className="space-y-2">
            {mix.slice(0, 6).map((x) => (
              <div key={x.type}>
                <div className="flex justify-between text-[11px] font-mono mb-0.5">
                  <span style={{ color: COLORS.light }}>{x.type}</span>
                  <span style={{ color: COLORS.muted }}>
                    {fmtUsd(x.value)} · {((x.value / total) * 100).toFixed(0)}%
                  </span>
                </div>
                <Meter value={x.value} max={maxV} color={COLORS.steel} height={6} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Section: Acquisition mix BY ITEM COUNT (how many in house / purchase / day rate…)
// ─────────────────────────────────────────────────────────────────────────────

interface AcqGroup {
  type: string;
  count: number;
  pct: number;
  value: number;
  color: string;
  items: BenchItem[];
}

const AcquisitionMixSection: React.FC<{ items: BenchItem[] }> = ({ items }) => {
  const [expanded, setExpanded] = useState<string | null>(null);

  const groups = useMemo<AcqGroup[]>(() => {
    // Only acquisition-type (main) lines count here — accessories (transit,
    // mobiliz., certif.) are not acquisition decisions.
    const main = items.filter((it) => !isAccessory(it.typeRaw));
    const m = new Map<string, BenchItem[]>();
    for (const it of main) {
      const key = normalizeType(it.typeRaw) || '(indefinido)';
      const arr = m.get(key);
      if (arr) arr.push(it);
      else m.set(key, [it]);
    }
    const totalCount = main.length || 1;
    return Array.from(m.entries())
      .map(([type, list]) => ({
        type,
        count: list.length,
        pct: (list.length / totalCount) * 100,
        value: list.reduce((s, it) => s + lineValue(it), 0),
        color: acquisitionColor(type),
        items: list,
      }))
      .sort((a, b) => b.count - a.count);
  }, [items]);

  const totalCount = groups.reduce((s, g) => s + g.count, 0);

  if (totalCount === 0) {
    return (
      <div className="p-5 text-sm" style={{ ...CARD_STYLE, color: COLORS.muted }}>
        Sem itens de aquisição para este BID.
      </div>
    );
  }

  return (
    <div className="p-5" style={CARD_STYLE}>
      {/* 100% stacked bar across all acquisition types */}
      <div className="flex h-4 rounded-full overflow-hidden mb-4" style={{ background: '#eef2f5' }}>
        {groups.map((g) => (
          <div
            key={g.type}
            style={{ width: `${g.pct}%`, background: g.color }}
            title={`${g.type}: ${g.count} item(ns) · ${g.pct.toFixed(1)}%`}
          />
        ))}
      </div>

      <div className="space-y-2">
        {groups.map((g) => {
          const open = expanded === g.type;
          return (
            <div key={g.type} className="border rounded-md" style={{ borderColor: COLORS.border }}>
              <button
                type="button"
                onClick={() => setExpanded(open ? null : g.type)}
                className="w-full flex items-center gap-3 px-3 py-2.5 text-left"
              >
                <span
                  className="inline-block shrink-0 rounded-sm"
                  style={{ width: 12, height: 12, background: g.color }}
                />
                <span className="font-mono text-[13px] font-semibold min-w-0 truncate" style={{ color: COLORS.light }}>
                  {g.type}
                </span>
                <span className="ml-auto shrink-0 flex items-center gap-3">
                  <span className="font-mono text-[13px] font-bold" style={{ color: COLORS.light }}>
                    {g.pct.toFixed(1)}%
                  </span>
                  <span
                    className="font-mono text-[11px] px-2 py-0.5 rounded-full"
                    style={{ background: '#eef2f5', color: COLORS.muted }}
                  >
                    {g.count} {g.count === 1 ? 'item' : 'itens'}
                  </span>
                  <span className="text-[11px]" style={{ color: COLORS.muted }}>
                    {open ? '▲' : '▼'}
                  </span>
                </span>
              </button>

              {open && (
                <div className="px-3 pb-3">
                  <div className="border-t pt-2 space-y-1" style={{ borderColor: COLORS.border }}>
                    {g.value > 0 && (
                      <div className="text-[11px] font-mono mb-1" style={{ color: COLORS.muted }}>
                        Valor somado do grupo: {fmtUsd(g.value)}
                      </div>
                    )}
                    {g.items.map((it, i) => (
                      <div
                        key={`${it.index}-${i}`}
                        className="flex items-center justify-between gap-3 text-[12px] py-1 border-b last:border-b-0"
                        style={{ borderColor: '#f0f3f6' }}
                      >
                        <span className="min-w-0 truncate" style={{ color: COLORS.light }} title={it.description}>
                          {it.description || '(sem descrição)'}
                          {isValidPn(it.pn) && (
                            <span className="font-mono ml-1" style={{ color: COLORS.muted }}>
                              · {it.pn}
                            </span>
                          )}
                        </span>
                        <span className="shrink-0 font-mono" style={{ color: COLORS.muted }}>
                          {lineValue(it) > 0 ? fmtUsd(lineValue(it)) : '—'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Section: Effort / hours summary
// ─────────────────────────────────────────────────────────────────────────────

const HoursSection: React.FC<{ labor: LaborRow[] }> = ({ labor }) => {
  const byPhase = useMemo(() => {
    const m = new Map<string, number>();
    for (const r of labor) {
      const hh = r.total_hh || 0;
      if (hh <= 0) continue;
      const key = r.phase || '(sem fase)';
      m.set(key, (m.get(key) || 0) + hh);
    }
    return Array.from(m.entries())
      .map(([phase, hh]) => ({ phase, hh }))
      .sort((a, b) => b.hh - a.hh);
  }, [labor]);

  const totalHh = byPhase.reduce((s, x) => s + x.hh, 0);
  const maxHh = byPhase.length ? byPhase[0].hh : 1;
  const peopleset = new Set(labor.map((r) => r.function).filter(Boolean));

  if (totalHh <= 0) {
    return (
      <div className="p-5 text-sm" style={{ ...CARD_STYLE, color: COLORS.muted }}>
        Sem dados de mão de obra (Labor) para este BID.
      </div>
    );
  }

  return (
    <div className="p-5" style={CARD_STYLE}>
      <div style={autoGrid(150)} className="mb-4">
        <KpiCard label="Total de horas" value={`${fmtNum(totalHh)} hh`} accent={COLORS.teal} />
        <KpiCard label="Funções distintas" value={fmtNum(peopleset.size)} accent={COLORS.steel} />
        <KpiCard label="Fases" value={fmtNum(byPhase.length)} accent={COLORS.steel} />
      </div>
      <div className="space-y-2">
        {byPhase.map((x) => (
          <div key={x.phase}>
            <div className="flex justify-between text-[12px] font-mono mb-0.5">
              <span style={{ color: COLORS.light }}>{x.phase}</span>
              <span style={{ color: COLORS.muted }}>
                {fmtNum(x.hh)} hh · {((x.hh / totalHh) * 100).toFixed(0)}%
              </span>
            </div>
            <Meter value={x.hh} max={maxHh} color={COLORS.teal} height={7} />
          </div>
        ))}
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Section: FX sensitivity
// ─────────────────────────────────────────────────────────────────────────────

const FxSection: React.FC<{
  totalUsd: number;
  ptax: number;
  onPtax: (v: number) => void;
}> = ({ totalUsd, ptax, onPtax }) => {
  const scenarios = [ptax - 0.5, ptax, ptax + 0.5].map((p) => ({ p, brl: totalUsd * p }));
  return (
    <div className="p-5" style={CARD_STYLE}>
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="text-[13px]" style={{ color: COLORS.light }}>
          Impacto cambial sobre o valor total (<span className="font-mono">{fmtUsd(totalUsd)}</span>)
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[12px] font-mono" style={{ color: COLORS.muted }}>
            PTAX R$ {ptax.toFixed(2)}
          </span>
          <input
            type="range"
            min={4.5}
            max={7.5}
            step={0.05}
            value={ptax}
            onChange={(e) => onPtax(parseFloat(e.target.value))}
            style={{ accentColor: COLORS.teal, width: 200 }}
          />
        </div>
      </div>
      <div className="mt-4" style={autoGrid(160)}>
        {scenarios.map((s, i) => (
          <div
            key={s.p}
            className="p-3 text-center rounded-md"
            style={{
              background: i === 1 ? `${COLORS.teal}12` : '#eef2f5',
              border: i === 1 ? `1px solid ${COLORS.teal}55` : `1px solid ${COLORS.border}`,
            }}
          >
            <div className="text-[11px] font-mono" style={{ color: COLORS.muted }}>
              R$ {s.p.toFixed(2)}
            </div>
            <div className="text-lg font-mono font-semibold mt-0.5" style={{ color: COLORS.light }}>
              {fmtBrl(s.brl)}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const ParetoSection: React.FC<{
  items: TopItem[];
  selectedCategory: string;
  onCategory: (category: string) => void;
  minValue: number;
  onMinValue: (value: number) => void;
  onSelectItem: (key: string) => void;
  selectedItemKey: string | null;
}> = ({ items, selectedCategory, onCategory, minValue, onMinValue, onSelectItem, selectedItemKey }) => {
  const categories = useMemo(
    () => ['All', ...Array.from(new Set(items.map((c) => c.row.category).filter(Boolean))).sort()],
    [items]
  );

  const rows = useMemo(() => {
    const src = items
      .map((it, index) => ({ key: topItemKey(it), label: it.row.description, total: it.fullCost, rank: index + 1 }))
      .filter((r) => r.total >= minValue)
      .filter((r) => r.total > 0)
      ;
    const grandTotal = src.reduce((s, r) => s + r.total, 0);
    let cum = 0;
    return src.map((r) => {
      cum += r.total;
      return { ...r, value: r.total, pct: grandTotal > 0 ? (cum / grandTotal) * 100 : 0 };
    });
  }, [items]);

  const n80 = rows.filter((d) => d.pct <= 80).length;
  const total = rows.reduce((s, r) => s + r.value, 0);

  return (
    <section>
      <SectionHeader
        eyebrow="Pareto"
        title="Priorize os itens que mais pesam no bid"
        hint="Filtre por categoria e veja os cards abaixo responderem ao mesmo recorte."
      />
      <div className="flex flex-wrap gap-1.5 mb-3">
        {categories.map((category) => {
          const active = selectedCategory === category;
          return (
            <button
              key={category}
              type="button"
              onClick={() => onCategory(category)}
              className={chipCls(active)}
            >
              {category}
            </button>
          );
        })}
      </div>
      <div className="mb-3" style={{ maxWidth: 220 }}>
        <label className="block text-[10px] uppercase tracking-widest font-mono mb-1.5" style={{ color: COLORS.muted }}>
          Valor minimo (USD)
        </label>
        <input
          type="number"
          min={0}
          step={100}
          className={INPUT_CLS}
          style={{ borderColor: COLORS.border, color: COLORS.light }}
          value={minValue}
          onChange={(e) => onMinValue(Math.max(0, parseInt(e.target.value || '0', 10) || 0))}
        />
      </div>
      {rows.length === 0 ? (
        <div className="p-5 text-sm" style={{ ...CARD_STYLE, color: COLORS.muted }}>
          Nenhum item com custo neste recorte.
        </div>
      ) : (
        <div className="space-y-3">
          <ParetoChart data={rows} onSelect={onSelectItem} selectedKey={selectedItemKey} />
          {n80 > 0 && (
            <div className="p-3 text-xs rounded-md" style={{ background: '#eef2f5', color: COLORS.light, borderLeft: `3px solid ${COLORS.gold}` }}>
              <strong>{n80} item(ns)</strong> representam 80% do custo deste recorte ({fmtUsd(rows.slice(0, n80).reduce((s, d) => s + d.value, 0))} de {fmtUsd(total)}).
            </div>
          )}
        </div>
      )}
    </section>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Root page
// ─────────────────────────────────────────────────────────────────────────────

export const BidPresentation: React.FC = () => {
  const toast = useToast();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [cost, setCost] = useState<BenchItem[]>([]);
  const [opps, setOpps] = useState<OppInfo[]>([]);
  const [labor, setLabor] = useState<LaborRow[]>([]);
  const [supplyMap, setSupplyMap] = useState<Map<string, SupplyInfo>>(() => new Map());
  const [selBid, setSelBid] = useState('');
  const [projectDays, setProjectDays] = useState(1);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [minValueFilter, setMinValueFilter] = useState(0);
  const [selectedItemKey, setSelectedItemKey] = useState<string | null>(null);
  const [ptax, setPtax] = useState(DEFAULT_PTAX);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        setLoading(true);
        setError(null);
        const [ds, supplyRows] = await Promise.all([
          ApiClient.getBenchmarkDataset(),
          ApiClient.getSupplyIndex().catch(() => [] as Array<Record<string, unknown>>),
        ]);
        if (cancelled) return;
        setCost(normalizeCostRows(ds.cost));
        setOpps(normalizeOpportunities(ds.opportunities));
        setLabor(normalizeLaborRows(ds.labor));
        setSupplyMap(buildSupplyMap(supplyRows));
      } catch (err) {
        if (cancelled) return;
        const message = err instanceof Error ? err.message : 'Falha ao carregar os dados do BID';
        setError(message);
        toast.error(message);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const oppTitles = useMemo(() => buildOppTitleMap(opps), [opps]);

  const bidIds = useMemo(() => {
    const ids = new Set<string>();
    for (const o of opps) if (o.oppId) ids.add(o.oppId);
    for (const it of cost) if (it.oppId) ids.add(it.oppId);
    return Array.from(ids).sort();
  }, [opps, cost]);

  useEffect(() => {
    if (!selBid && bidIds.length) setSelBid(bidIds[0]);
  }, [bidIds, selBid]);

  useEffect(() => {
    setSelectedCategory('All');
    setMinValueFilter(0);
    setSelectedItemKey(null);
  }, [selBid]);

  const bidItems = useMemo(() => cost.filter((it) => sameOpp(it.oppId, selBid)), [cost, selBid]);
  const adjustedBidItems = useMemo(() => adjustBidItemsForProjectDays(bidItems, projectDays), [bidItems, projectDays]);
  const categoryFilteredBidItems = useMemo(
    () => (selectedCategory === 'All' ? adjustedBidItems : adjustedBidItems.filter((it) => (it.category || 'Other') === selectedCategory)),
    [adjustedBidItems, selectedCategory]
  );
  const categoryTopItems = useMemo(() => buildTopItems(categoryFilteredBidItems), [categoryFilteredBidItems]);
  const valueFilteredTopItems = useMemo(
    () => categoryTopItems.filter((it) => it.fullCost >= minValueFilter),
    [categoryTopItems, minValueFilter]
  );
  const bidLabor = useMemo(() => labor.filter((r) => sameOpp(r.oppId, selBid)), [labor, selBid]);
  const stats = useMemo(() => computeBidStats(adjustedBidItems), [adjustedBidItems]);
  const topItems = valueFilteredTopItems;
  const maxCost = topItems.length ? topItems[0].fullCost : 1;

  useEffect(() => {
    if (!selectedItemKey) return;
    const el = document.getElementById(`bid-item-${selectedItemKey}`);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, [selectedItemKey]);

  return (
    <div className="space-y-6">
      {loading ? (
        <Loading />
      ) : error ? (
        <div
          className="text-sm p-4 rounded-md"
          style={{ color: COLORS.red, border: `1px solid ${COLORS.red}55`, background: `${COLORS.red}0d` }}
        >
          {error}
        </div>
      ) : bidIds.length === 0 ? (
        <div className="text-sm p-4" style={{ color: COLORS.muted }}>
          Nenhum BID encontrado na base.
        </div>
      ) : (
        <>
          <div className="flex items-end gap-3 flex-wrap">
            <div>
              <div className="text-[10px] uppercase tracking-widest font-mono mb-1.5" style={{ color: COLORS.muted }}>
                BID
              </div>
              <BidSelect value={selBid} onChange={setSelBid} bidIds={bidIds} oppTitles={oppTitles} />
            </div>
            <div style={{ minWidth: 180 }}>
              <div className="text-[10px] uppercase tracking-widest font-mono mb-1.5" style={{ color: COLORS.muted }}>
                Dias do projeto
              </div>
              <input
                type="number"
                min={1}
                step={1}
                className={INPUT_CLS}
                style={{ borderColor: COLORS.border, color: COLORS.light }}
                value={projectDays}
                onChange={(e) => setProjectDays(Math.max(1, parseInt(e.target.value || '1', 10) || 1))}
              />
              <div className="text-[10px] mt-1" style={{ color: COLORS.muted }}>
                Itens com <span className="font-mono">day rate</span> usam este multiplicador.
              </div>
            </div>
          </div>

          {bidItems.length === 0 && (
            <div
              className="text-[13px] p-3 rounded-md"
              style={{ background: `${COLORS.gold}14`, border: `1px solid ${COLORS.gold}55`, color: COLORS.light }}
            >
              Este BID ainda não tem itens de custo detalhados na lista do SMART BID — a apresentação é exibida com o que
              houver disponível.
            </div>
          )}

          <HeroSection oppId={selBid} title={oppTitles.get(selBid) || ''} stats={stats} ptax={ptax} />

          {adjustedBidItems.length > 0 && (
            <ParetoSection
              items={categoryTopItems}
              selectedCategory={selectedCategory}
              onCategory={setSelectedCategory}
              minValue={minValueFilter}
              onMinValue={setMinValueFilter}
              onSelectItem={setSelectedItemKey}
              selectedItemKey={selectedItemKey}
            />
          )}

          <section>
            <SectionHeader
              eyebrow="Principais itens"
              title="Onde está o valor da proposta"
              hint={
                selectedCategory === 'All'
                  ? `Itens ordenados por preço, respeitando o filtro minimo de ${fmtUsd(minValueFilter)}.`
                  : `Itens ordenados por preço na categoria ${selectedCategory}, respeitando o filtro minimo de ${fmtUsd(minValueFilter)}.`
              }
            />
            {topItems.length === 0 ? (
              <div className="p-5 text-sm" style={{ ...CARD_STYLE, color: COLORS.muted }}>
                Nenhum item atende ao recorte atual de categoria e valor.
              </div>
            ) : (
              <div style={autoGrid(340)}>
                  {topItems.map((item, index) => (
                    <div key={topItemKey(item)} id={`bid-item-${topItemKey(item)}`}>
                    <TopItemCard
                      rank={index + 1}
                    item={item}
                    shareOfTotal={stats.total ? (item.fullCost / stats.total) * 100 : 0}
                    maxCost={maxCost}
                    allCost={cost}
                    oppId={selBid}
                    oppTitles={oppTitles}
                    supply={isValidPn(item.row.pn) ? supplyMap.get(pnKey(item.row.pn)) : undefined}
                      highlighted={selectedItemKey === topItemKey(item)}
                  />
                    </div>
                ))}
              </div>
            )}
          </section>

          {adjustedBidItems.length > 0 && (
            <>
              <section>
                <SectionHeader eyebrow="Composição" title="Como o custo se distribui" />
                <CompositionSection items={adjustedBidItems} stats={stats} />
              </section>

              <section>
                <SectionHeader
                  eyebrow="Mix de aquisição"
                  title="Como os itens foram contratados"
                  hint="Percentual e quantidade de itens por tipo (in house, purchase, day rate, rental…). Clique para ver os itens de cada grupo."
                />
                <AcquisitionMixSection items={adjustedBidItems} />
              </section>
            </>
          )}

          <section>
            <SectionHeader eyebrow="Esforço" title="Resumo de horas e mão de obra" />
            <HoursSection labor={bidLabor} />
          </section>

          <section>
            <SectionHeader eyebrow="Câmbio" title="Sensibilidade cambial" />
            <FxSection totalUsd={stats.total} ptax={ptax} onPtax={setPtax} />
          </section>
        </>
      )}
    </div>
  );
};
