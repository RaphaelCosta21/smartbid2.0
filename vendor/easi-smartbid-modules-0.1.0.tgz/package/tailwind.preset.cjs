/**
 * Tailwind preset for @easi/smartbid-modules.
 *
 * Adiciona os tokens de cor usados internamente pelos módulos EASI portados.
 * Merge com o design system do SMART BID 2.0 no `tailwind.config.js` do host:
 *
 *   // tailwind.config.js
 *   const smartbidModules = require('@easi/smartbid-modules/tailwind-preset');
 *   module.exports = {
 *     presets: [smartbidModules],
 *     content: [
 *       './index.html',
 *       './src/**\/*.{ts,tsx}',
 *       './node_modules/@easi/smartbid-modules/dist/**\/*.{js,cjs,mjs}',
 *     ],
 *     // ...seu tema
 *   };
 *
 * Os módulos usam classes como `bg-teal`, `text-navy`, `border-border`, etc.
 * Se essas classes já existirem no seu tema, elas serão sobrescritas pelo seu
 * `theme.extend` — o preset só garante que classes desconhecidas resolvam.
 */
module.exports = {
  theme: {
    extend: {
      colors: {
        // Paleta EASI (light MOC/PCMS). Se preferir a paleta SMART BID (dark),
        // sobrescreva no seu tailwind.config.js.
        navy: '#00263e',
        deep: '#0d2430',
        gold: '#ffc72c',
        steel: '#5b7f95',
        muted: '#5b7f95',
        teal: '#0097a9',
        green: '#009b77',
        light: '#eef2f5',
        surface: '#ffffff',
        border: '#dfe6ec',
        'border-light': '#eaeff3',
      },
    },
  },
};
