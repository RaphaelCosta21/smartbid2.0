# @easi/smartbid-modules

Módulos portados do **EASI SPFx** (Oceaneering) para integração no **SMART BID 2.0**:

| Módulo                          | Componente          | Origem no `easi-spfx`               |
| ------------------------------- | ------------------- | ----------------------------------- |
| Catálogo de fornecedores        | `<Suppliers />`     | `pages/Suppliers.tsx`               |
| BID Comparator                  | `<BidComparator />` | `pages/CTRComparator.tsx`           |
| BID Presentation                | `<BidPresentation />` | `pages/BidPresentation.tsx`       |
| Consulta histórica de preços/modalidades | `<PriceHistory />` | `pages/PriceBenchmark.tsx`  |

**Framework-agnostic**: sem `@microsoft/sp-*`, sem SharePoint, sem Tailwind pré-compilado. O host injeta os dados via um `SmartBidDataAdapter`. Rodam em qualquer app React 17/18 (Vite, Next, CRA, SPFx).

---

## Instalação (no repo do SMART BID 2.0)

Depois de publicar o pacote em um registry privado (ou usar `npm pack` + `file:`):

```bash
npm install @easi/smartbid-modules
# ou, apontando para o tarball local:
npm install ../easi-spfx/packages/smartbid-modules/easi-smartbid-modules-0.1.0.tgz
```

Peer deps: `react` `^17 || ^18`, `react-dom` `^17 || ^18`. Dep runtime: `xlsx` (para export). Ambos já estão no stack alvo.

---

## Bootstrap (uma vez, no `main.tsx` do SMART BID 2.0)

Escolha **um** dos dois modos:

### Modo A — dev/preview com dados falsos

```tsx
// src/main.tsx
import { configureSmartBidModules, MockAdapter } from '@easi/smartbid-modules';

configureSmartBidModules({ adapter: new MockAdapter() });
```

### Modo B — produção (PnPjs → SharePoint Lists)

Implemente `SmartBidDataAdapter` contra o PnPjs do SMART BID:

```ts
// src/services/smartBidDataAdapter.ts
import type { SmartBidDataAdapter, BenchmarkDataset } from '@easi/smartbid-modules';
import { sp } from './pnp'; // sua instância PnPjs já configurada

export class PnPAdapter implements SmartBidDataAdapter {
  async getBenchmarkDataset(): Promise<BenchmarkDataset> {
    const [cost, opportunities, labor] = await Promise.all([
      sp.web.lists.getByTitle('smartbid-cost-elements').items.top(5000)(),
      sp.web.lists.getByTitle('smartbid-opportunities').items.top(2000)(),
      sp.web.lists.getByTitle('smartbid-labor-elements').items.top(5000)(),
    ]);
    return { cost, opportunities, labor };
  }

  async getSupplyIndex() {
    return sp.web.lists.getByTitle('smartbid-supply-index').items.top(50000)();
  }

  async getCostElementsRaw() { return (await this.getBenchmarkDataset()).cost; }
  async getOpportunitiesRaw() { return (await this.getBenchmarkDataset()).opportunities; }

  // Cotações (opcional — habilita a aba "Cotações" em Suppliers)
  isQuotesStoreConfigured() { return true; }
  async listQuotes() {
    const items = await sp.web.lists.getByTitle('EASI - QUOTES').items.top(2000)();
    return items.map(this.mapQuote);
  }

  isQuotesUploadConfigured() { return true; }
  async uploadQuoteDocument(file: File) {
    await sp.web.getFolderByServerRelativeUrl('/sites/.../EASI-QUOTES-INPUT')
      .files.addUsingPath(file.name, file, { Overwrite: true });
  }

  private mapQuote = (i: any) => ({ /* ... veja QuoteListItem em src/shared/types/domain.ts */ });
}
```

E no bootstrap:

```tsx
import { configureSmartBidModules } from '@easi/smartbid-modules';
import { PnPAdapter } from './services/smartBidDataAdapter';

configureSmartBidModules({ adapter: new PnPAdapter() });
```

**Formato das linhas esperadas** (para o adapter cru): colunas típicas do `DATA.xlsx` original — `unit_price`, `quantity`, `type_raw`/`pricing_model`, `category_final`, `pn`, `description`, `currency`, `premisses`, `group`, `opportunity_id`, `et_text`. Rows extras são ignoradas.

---

## Uso nas rotas do SMART BID 2.0

Registre onde fizer sentido no seu roteador. Sugestão:

```tsx
// src/router.tsx (React Router v6)
import { Suppliers, BidComparator, BidPresentation, PriceHistory } from '@easi/smartbid-modules';

const routes = [
  // ... suas rotas
  { path: '/tools/suppliers', element: <Suppliers /> },
  { path: '/tools/bid-comparator', element: <BidComparator /> },
  { path: '/tools/price-history', element: <PriceHistory /> },

  // BID Presentation dentro do BID Detail (página central), como sub-tab:
  { path: '/bid/:id/presentation', element: <BidPresentation /> },
];
```

Cada módulo é um componente React auto-contido (sem props obrigatórias); ele mesmo faz o fetch via `ApiClient` → adapter configurado.

---

## Estilização — Tailwind

Os módulos usam classes Tailwind (`bg-teal`, `text-navy`, `border-border`, etc.). Duas opções:

### Opção 1 — merge com preset (recomendado)

```js
// tailwind.config.js do SMART BID 2.0
const smartbidModulesPreset = require('@easi/smartbid-modules/tailwind-preset');

module.exports = {
  presets: [smartbidModulesPreset],
  content: [
    './index.html',
    './src/**/*.{ts,tsx}',
    // ⚠ IMPORTANTE: escanear o pacote também senão as classes são purgadas
    './node_modules/@easi/smartbid-modules/dist/**/*.{js,cjs,mjs}',
  ],
  theme: {
    extend: {
      colors: {
        // Sobrescreva se quiser aplicar a paleta dark SMART BID por cima:
        teal: '#00c9a7',       // era #0097a9 no EASI
        navy: '#0a1628',       // era #00263e
        surface: '#152238',    // era #ffffff
        border: '#1e3a5f',     // era #dfe6ec
        light: '#f1f5f9',      // era #eef2f5
      },
    },
  },
};
```

### Opção 2 — CSS pré-compilado (fallback)

Se preferir não misturar Tailwinds: descomente `build/gen-global-css.js` do repo EASI, gere um `easi-modules.css` isolado e importe uma única vez no `main.tsx`. **Não recomendado** para o SMART BID (a paleta dark ficaria conflitando).

---

## Tema Dark / Light

O código herdado do EASI usa **cores hex hardcoded via `React.CSSProperties`** em vários lugares (cards brancos, texto navy) — foi feito para a paleta light MOC/PCMS.

Para aplicar dark mode do SMART BID 2.0 sem reescrever tudo:

1. **Fase 1 (rápida):** envolva o componente em um wrapper com filtro CSS `invert(1) hue-rotate(180deg)` ou uma classe `.light-island` que restaura fundo branco. Rende o módulo como "ilha clara" no shell escuro (padrão SmartFlow em widgets legacy).
2. **Fase 2 (definitiva):** cada módulo tem seus tokens agrupados em um objeto `COLORS` no topo do arquivo. Trocar por CSS custom properties (`var(--sb-teal)`, etc.) é uma refatoração pontual. Ver comentários TODO no topo de cada `.tsx`.

---

## Estrutura do pacote

```
packages/smartbid-modules/
├── package.json                      # nome, exports, peerDeps
├── tsconfig.json
├── tsup.config.ts                    # build ESM + CJS + .d.ts
├── tailwind.preset.cjs               # tokens de cor
├── README.md                         # este arquivo
└── src/
    ├── index.ts                      # entrypoint público
    ├── adapters/
    │   ├── DataAdapter.ts            # interface SmartBidDataAdapter
    │   ├── ApiClient.ts              # fachada estática + configure()
    │   ├── MockAdapter.ts            # implementação de dev
    │   ├── mockData.ts               # sample data
    │   └── index.ts
    ├── shared/
    │   ├── types/domain.ts           # CostElement, Opportunity, QuoteListItem, ...
    │   ├── ui/                       # Card, EmptyState, ErrorState, Loading, Toast
    │   └── utils/                    # benchmark, aiSearch, ctrComparator, itemResolver, supplierStore, exporters
    └── modules/
        ├── suppliers/Suppliers.tsx
        ├── bid-comparator/BidComparator.tsx
        ├── bid-presentation/BidPresentation.tsx
        └── price-history/PriceHistory.tsx
```

---

## Build & publish

```bash
cd packages/smartbid-modules
npm install
npm run typecheck        # tsc --noEmit
npm run build            # gera dist/ com ESM + CJS + .d.ts

# Opção A — tarball local para o amigo testar:
npm pack                 # gera easi-smartbid-modules-0.1.0.tgz

# Opção B — publicar em registry privado (Azure Artifacts / GH Packages):
npm publish --registry=https://pkgs.dev.azure.com/oceaneering/_packaging/xxx/npm/registry/
```

---

## Fluxo de trabalho enquanto você não tem o repo do SMART BID 2.0

1. **Agora**: continue evoluindo os módulos aqui no `easi-spfx` normalmente (é a "fonte da verdade"). Toda mudança que quiser levar pro SMART BID, você propaga para `packages/smartbid-modules/src/...` (uma script de sync pode ser criada — hoje é cópia manual).
2. **Quando ganhar acesso ao GitHub do SMART BID 2.0**:
   - Rode `npm pack` no pacote, envie o `.tgz` pro amigo e ele faz `npm install ./easi-smartbid-modules-0.1.0.tgz`.
   - Ou publique no Azure Artifacts (org Oceaneering) — mais durável.
   - Ou vira **git submodule** apontando pra este repo em `apps/smartbid/packages/smartbid-modules`.

---

## Checklist de sanidade após integração

- [ ] `configureSmartBidModules({ adapter })` roda **antes** do primeiro render das rotas.
- [ ] `tailwind.config.js` do host tem `./node_modules/@easi/smartbid-modules/dist/**/*.{js,cjs,mjs}` no `content`.
- [ ] Rota do SMART BID envolve os componentes com `<ToastProvider>` (ou reuse o Toast provider do host). Cada módulo chama `useToast()`.
- [ ] `xlsx` está instalado (para export de tabelas).
- [ ] Se o dark mode "acender" cores brancas legadas dentro dos módulos, aplicar wrapper `.light-island` como paliativo (ver seção Tema).

---

## Limitações conhecidas

- **Charts hand-rolled**: EASI usa SVG puro (sem Recharts). Mantido assim para reduzir dependência. Pode ser trocado depois.
- **Persistência local**: `Suppliers` usa `localStorage` para o catálogo. Migrar para lista SharePoint requer estender o `SmartBidDataAdapter` com métodos `listSuppliers/createSupplier/...` (roadmap).
- **Suppliers → cotações**: só habilita se o adapter implementar `listQuotes()`/`uploadQuoteDocument()`. Sem eles, a aba mostra empty state.
- **Sem PT-BR strings extras**: os textos das UIs seguem o original (EN misturado com PT em alguns rótulos). Localização é follow-up.
